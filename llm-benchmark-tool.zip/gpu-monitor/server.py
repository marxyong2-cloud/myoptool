#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MTT S5000 显卡监控服务（mthreads-gmi Web Dashboard）

纯 Python 标准库实现，无第三方依赖。后台线程周期采样 mthreads-gmi，
浏览器访问 http://<服务器IP>:8080 查看实时看板。

用法: python3 server.py [--host 0.0.0.0] [--port 8080] [--interval 2]
"""
import argparse
import collections
import json
import os
import re
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

GMI = "mthreads-gmi"
HISTORY_MAX = 1800          # 采样点数（2s 间隔 ≈ 1 小时）
TOPO_REFRESH = 60           # 拓扑刷新周期（秒）
SUBPROC_TIMEOUT = 6

# ---------------- 状态 ----------------
LOCK = threading.Lock()
SNAPSHOT = {"ok": False}
HISTORY = collections.deque(maxlen=HISTORY_MAX)
TOPO = {"text": "", "numa": {}, "cpu_aff": {}, "ts": 0}


def run(cmd):
    """运行命令返回 stdout，失败返回 None"""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=SUBPROC_TIMEOUT)
        if p.returncode == 0:
            return p.stdout
        return None
    except Exception:
        return None


def norm_keys(obj):
    """递归去掉 dict key 的首尾空白（gmi JSON 存在 "Power Draw " 这类 key）"""
    if isinstance(obj, dict):
        return {k.strip(): norm_keys(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [norm_keys(x) for x in obj]
    return obj


def num(s, dflt=0.0):
    """从 "81920MiB" / "39C" / "401.79W" / "1750MHz" / "0%" 中取数值"""
    if s is None:
        return dflt
    m = re.search(r"-?\d+(?:\.\d+)?", str(s))
    return float(m.group()) if m else dflt


def collect_gpus(detail):
    gpus = []
    for g in detail.get("GPU", []):
        pci = g.get("PCI", {}) or {}
        link = pci.get("GPU Link Info", {}) or {}
        gen = link.get("PCIe Generation", {}) or {}
        width = link.get("Link Width", {}) or {}
        mem = g.get("FB Memory Usage", {}) or {}
        util = g.get("Utilization", {}) or {}
        power = g.get("Power Readings", {}) or {}
        clocks = g.get("Clocks", {}) or {}
        ecc = g.get("ECC Mode", {}) or {}
        gpus.append({
            "index": int(num(g.get("Index", "0"))),
            "name": g.get("Product Name", "?"),
            "uuid": g.get("GPU UUID", ""),
            "serial": g.get("Serial Number", ""),
            "bios": g.get("MTBios Version", ""),
            "bus_id": pci.get("Bus ID", ""),
            "slot": pci.get("Slot ID(Name)", ""),
            "pcie_gen": "%s x %s" % (gen.get("Current", "?"), width.get("Current", "?")),
            "pcie_gen_max": "%s x %s" % (gen.get("Max", "?"), width.get("Max", "?")),
            "mem_used_mib": int(num(mem.get("Used"))),
            "mem_total_mib": int(num(mem.get("Total"))),
            "mem_free_mib": int(num(mem.get("Free"))),
            "util_gpu": num(util.get("Gpu")),
            "util_mem": num(util.get("Memory")),
            "util_enc": num(util.get("Encoder")),
            "util_dec": num(util.get("Decoder")),
            "temp_c": num(g.get("Temperature", {}).get("GPU Current Temp")),
            "power_w": num(power.get("Power Draw")),
            "power_limit_w": num(power.get("Current Power Limit")),
            "sm_clock_mhz": num(clocks.get("Graphics")),
            "mem_clock_mhz": num(clocks.get("Memory")),
            "ecc_edc": ecc.get("EDC", "?"),
            "ecc_on_die": ecc.get("On-die", "?"),
            "perf_state": g.get("Performance State", "N/A"),
        })
    return gpus


def collect_processes(summary_text, pm_text):
    """融合两处进程信息：
    1) `mthreads-gmi`（汇总输出）Processes 段：GPU / PID / 进程名 / 显存占用
       格式: "0    1691207    /tmp/app    2083MiB"
    2) `mthreads-gmi -pm`：GPU / PID / memUtil / gpuUtil
       格式: "  0   1691207        2%        0%"
    """
    procs = {}
    in_proc = False
    for line in (summary_text or "").splitlines():
        if "Processes:" in line:
            in_proc = True
            continue
        if not in_proc:
            continue
        t = line.strip()
        if not t or set(t) <= set("+-"):
            continue
        low = t.lower()
        if ("no running process" in low or "pid" in low or "usage" in low
                or "process name" in low):
            continue   # 空态提示与表头
        m = re.match(r"^(\d+)\s+(\d+)\s+(.+?)\s+(\d+)\s*MiB\s*$", t)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            procs[key] = {"gpu": key[0], "pid": key[1],
                          "name": m.group(3).strip(),
                          "mem_mib": int(m.group(4)),
                          "gpu_util": None, "mem_util": None}
    for line in (pm_text or "").splitlines():
        m = re.match(r"^\s*(\d+)\s+(\d+)\s+(\d+)\s*%\s+(\d+)\s*%\s*$", line)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            e = procs.setdefault(key, {"gpu": key[0], "pid": key[1],
                                       "name": "?", "mem_mib": None,
                                       "gpu_util": None, "mem_util": None})
            e["mem_util"] = int(m.group(3))
            e["gpu_util"] = int(m.group(4))
    # -pm 会列出进程附着的全部 GPU；名称缺失时经 /proc 补全
    names = {}
    for e in procs.values():
        if e["name"] != "?":
            names[e["pid"]] = e["name"]
    for e in procs.values():
        if e["name"] == "?" and e["pid"] in names:
            e["name"] = names[e["pid"]]
    return sorted(procs.values(), key=lambda p: (p["gpu"], p["pid"]))


def parse_topo(text):
    """从 topo -m 矩阵提取每个 GPU 的 NUMA 节点与 CPU 亲和"""
    numa, cpu_aff = {}, {}
    for line in (text or "").splitlines():
        if not line.startswith("GPU"):
            continue
        m = re.match(r"^(GPU\d+)\s+.*?(\d+(?:-\d+)?(?:,\d+(?:-\d+)*)*)\s+(\d+)\s*$", line)
        if m:
            cpu_aff[m.group(1)] = m.group(2)
            numa[m.group(1)] = m.group(3)
    return numa, cpu_aff


def collect_snapshot():
    out = run([GMI, "-q", "--json"])
    if not out:
        return None
    try:
        detail = norm_keys(json.loads(out))
    except ValueError:
        return None
    gpus = collect_gpus(detail)
    if not gpus:
        return None
    procs = collect_processes(run([GMI]) or "", run([GMI, "-pm"]) or "")
    total_mem = sum(g["mem_total_mib"] for g in gpus)
    used_mem = sum(g["mem_used_mib"] for g in gpus)
    return {
        "ok": True,
        "ts": time.time(),
        "host": socket.gethostname(),
        "driver": detail.get("Driver Version", "?"),
        "gmi_ts": detail.get("Timestamp", ""),
        "gpu_count": len(gpus),
        "gpus": gpus,
        "processes": procs,
        "totals": {
            "mem_used_mib": used_mem,
            "mem_total_mib": total_mem,
            "power_w": round(sum(g["power_w"] for g in gpus), 1),
            "avg_util": round(sum(g["util_gpu"] for g in gpus) / len(gpus), 1),
            "max_temp_c": max(g["temp_c"] for g in gpus),
        },
    }


def append_history(snap):
    H = HISTORY
    n = snap["gpu_count"]
    u = [0.0] * n
    p = [0.0] * n
    m = [0.0] * n
    c = [0.0] * n
    for g in snap["gpus"]:
        i = g["index"]
        if 0 <= i < n:
            u[i], p[i], m[i], c[i] = (g["util_gpu"], g["power_w"],
                                      g["mem_used_mib"], g["temp_c"])
    H.append({"t": round(snap["ts"], 1), "u": u, "p": p, "m": m, "c": c})


def sampler_loop(interval):
    global SNAPSHOT
    last_topo = 0.0
    while True:
        t0 = time.time()
        try:
            snap = collect_snapshot()
            if snap:
                with LOCK:
                    SNAPSHOT = snap
                    append_history(snap)
            if time.time() - last_topo > TOPO_REFRESH:
                text = run([GMI, "topo", "-m"]) or ""
                if text:
                    numa, cpu_aff = parse_topo(text)
                    with LOCK:
                        TOPO.update({"text": text, "numa": numa,
                                     "cpu_aff": cpu_aff, "ts": time.time()})
                    last_topo = time.time()
        except Exception as e:  # 采样异常不能杀死线程
            print("[sampler] error: %r" % e, flush=True)
        cost = time.time() - t0
        time.sleep(max(0.2, interval - cost))


# ---------------- 前端页面 ----------------
PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MTT S5000 显卡监控</title>
<style>
:root{
  --bg:#0b0f17;--panel:#121826;--panel2:#0e1420;--line:#1f2937;
  --txt:#e5e9f0;--dim:#8b95a7;--acc:#38bdf8;--ok:#34d399;--warn:#fbbf24;
  --crit:#f87171;--mem:#a78bfa;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--txt);
  font-family:-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",Roboto,monospace;
  font-size:14px;padding:18px}
a{color:var(--acc);text-decoration:none}
header{display:flex;flex-wrap:wrap;align-items:center;gap:14px;margin-bottom:14px}
h1{font-size:19px;font-weight:600;letter-spacing:.5px}
h1 .badge{font-size:12px;color:var(--acc);border:1px solid var(--acc);
  border-radius:10px;padding:1px 9px;margin-left:8px;vertical-align:2px}
.meta{color:var(--dim);font-size:12.5px}
.meta b{color:var(--txt);font-weight:600}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
  gap:12px;margin-bottom:16px}
.stat{background:var(--panel);border:1px solid var(--line);border-radius:12px;
  padding:12px 14px}
.stat .k{color:var(--dim);font-size:12px;margin-bottom:5px}
.stat .v{font-size:21px;font-weight:700;font-variant-numeric:tabular-nums}
.stat .s{color:var(--dim);font-size:11.5px;margin-top:3px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(348px,1fr));gap:14px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;
  padding:14px 16px;min-width:0}
.card-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px}
.card-head .t{font-size:15.5px;font-weight:700}
.card-head .t small{color:var(--dim);font-weight:400;margin-left:6px;font-size:12px}
.dot{width:9px;height:9px;border-radius:50%;display:inline-block;margin-right:6px;
  background:var(--ok);box-shadow:0 0 6px var(--ok)}
.dot.busy{background:var(--acc);box-shadow:0 0 8px var(--acc)}
.dot.err{background:var(--crit);box-shadow:0 0 8px var(--crit)}
.main{display:flex;gap:16px;align-items:center;margin-bottom:10px}
.ring{position:relative;width:86px;height:86px;flex:none}
.ring svg{transform:rotate(-90deg)}
.ring .val{position:absolute;inset:0;display:flex;flex-direction:column;
  align-items:center;justify-content:center}
.ring .val b{font-size:17px;font-variant-numeric:tabular-nums}
.ring .val span{font-size:10px;color:var(--dim)}
.kv{flex:1;display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;min-width:0}
.kv div{display:flex;justify-content:space-between;gap:6px;font-size:12.5px;
  border-bottom:1px dashed rgba(255,255,255,.05);padding:2px 0}
.kv span{color:var(--dim);flex:none}
.kv b{font-weight:600;font-variant-numeric:tabular-nums;text-align:right;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bar{height:16px;background:var(--panel2);border-radius:8px;overflow:hidden;
  position:relative;margin:4px 0 2px}
.bar i{display:block;height:100%;border-radius:8px;transition:width .5s;
  background:linear-gradient(90deg,#6366f1,var(--mem))}
.bar .txt{position:absolute;inset:0;display:flex;align-items:center;
  justify-content:center;font-size:11px;color:#fff;text-shadow:0 1px 2px #000}
.spark{width:100%;height:46px;display:block;margin-top:8px}
.foot{display:flex;justify-content:space-between;color:var(--dim);
  font-size:11px;margin-top:6px;flex-wrap:wrap;gap:4px}
.sect{margin:20px 0 10px;display:flex;align-items:center;gap:10px}
.sect h2{font-size:15px;font-weight:600}
.sect .line{flex:1;height:1px;background:var(--line)}
table{width:100%;border-collapse:collapse;background:var(--panel);
  border:1px solid var(--line);border-radius:12px;overflow:hidden}
th,td{padding:8px 12px;text-align:left;border-bottom:1px solid var(--line);
  font-size:13px;font-variant-numeric:tabular-nums}
th{color:var(--dim);font-weight:500;background:rgba(255,255,255,.02)}
tr:last-child td{border-bottom:none}
.empty{color:var(--dim);text-align:center;padding:14px}
details{margin-top:16px}
summary{cursor:pointer;color:var(--dim);font-size:13px;padding:6px 0}
pre{background:var(--panel);border:1px solid var(--line);border-radius:12px;
  padding:12px;font-size:11.5px;overflow:auto;color:var(--dim);line-height:1.5}
#err{display:none;background:rgba(248,113,113,.12);border:1px solid var(--crit);
  color:var(--crit);border-radius:10px;padding:8px 14px;margin-bottom:12px;font-size:13px}
.controls{display:flex;align-items:center;gap:8px;color:var(--dim);font-size:12.5px}
select{background:var(--panel);color:var(--txt);border:1px solid var(--line);
  border-radius:8px;padding:3px 8px;font-size:12.5px}
footer{color:var(--dim);font-size:11.5px;text-align:center;margin-top:22px}
</style>
</head>
<body>
<header>
  <h1>MTT S5000 显卡监控<span class="badge" id="gcount">-</span></h1>
  <div class="meta">主机 <b id="host">-</b> · 驱动 <b id="drv">-</b> ·
    更新于 <b id="ts">-</b></div>
  <div style="flex:1"></div>
  <div class="controls">
    <label><input type="checkbox" id="auto" checked> 自动刷新</label>
    <select id="rate">
      <option value="1000">1s</option>
      <option value="2000" selected>2s</option>
      <option value="5000">5s</option>
      <option value="10000">10s</option>
    </select>
  </div>
</header>
<div id="err"></div>
<div class="stats" id="stats"></div>
<div class="grid" id="cards"></div>
<div class="sect"><h2>GPU 进程</h2><div class="line"></div></div>
<div id="procs"></div>
<details><summary>GPU / NIC 拓扑矩阵（mthreads-gmi topo -m）</summary>
<pre id="topo">加载中…</pre></details>
<footer>数据源 mthreads-gmi · MTT S5000 服务器 GPU 看板</footer>
<script>
"use strict";
const $=id=>document.getElementById(id);
let HIST=[], lastSummary=null, timer=null;

function fmt(n,d=0){return Number(n).toLocaleString("zh-CN",
  {minimumFractionDigits:d,maximumFractionDigits:d});}
function el(tag,cls,html){const e=document.createElement(tag);
  if(cls)e.className=cls; if(html!==undefined)e.innerHTML=html; return e;}

function statusDot(g){
  const d=el("span");
  if(g.temp_c>=85||g.mem_total_mib&&g.mem_used_mib/g.mem_total_mib>0.97){d.className="dot err";}
  else if(g.util_gpu>1||g.mem_used_mib>1024){d.className="dot busy";}
  else{d.className="dot";}
  return d;
}
function tempColor(t){return t>=85?"var(--crit)":t>=70?"var(--warn)":"var(--ok)";}
function memPct(g){return g.mem_total_mib?100*g.mem_used_mib/g.mem_total_mib:0;}
function memColor(p){return p>=95?"var(--crit)":p>=80?"var(--warn)":"var(--mem)";}

function ringSVG(pct,color){
  const r=36,c=2*Math.PI*r,off=c*(1-Math.min(pct,100)/100);
  return `<svg width="86" height="86" viewBox="0 0 86 86">
    <circle cx="43" cy="43" r="${r}" fill="none" stroke="#1c2534" stroke-width="8"/>
    <circle cx="43" cy="43" r="${r}" fill="none" stroke="${color}" stroke-width="8"
      stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${off}"
      style="transition:stroke-dashoffset .5s"/></svg>`;
}

function drawSpark(cv){
  const N=HIST.length; if(N<2)return;
  const W=cv.clientWidth||300,H=46,dpr=window.devicePixelRatio||1;
  cv.width=W*dpr;cv.height=H*dpr;
  const g=cv.getContext("2d");g.scale(dpr,dpr);g.clearRect(0,0,W,H);
  const K=Math.min(N,150),S=HIST.slice(N-K);      // 最近 150 点
  const nG=S[0].u.length;
  const gi=+cv.dataset.gpu;
  const X=i=>i/(K-1)*W;
  const line=(get,ymax,color)=>{
    g.beginPath();
    S.forEach((s,i)=>{const y=H-4-(H-10)*Math.min(get(s),ymax)/ymax;
      i?g.lineTo(X(i),y):g.moveTo(X(i),y);});
    g.strokeStyle=color;g.lineWidth=1.6;g.stroke();};
  g.strokeStyle="rgba(255,255,255,.06)";g.lineWidth=1;
  [0.25,0.5,0.75].forEach(f=>{g.beginPath();g.moveTo(0,H*f);g.lineTo(W,H*f);g.stroke();});
  line(s=>s.p[gi]||0,1000,"rgba(251,191,36,.75)");   // 功耗(0-1000W)
  line(s=>s.u[gi]||0,100,"#38bdf8");                  // 利用率 0-100
}

function render(s){
  const t=s.totals;
  $("gcount").textContent=s.gpu_count+" 卡";
  $("host").textContent=s.host;$("drv").textContent=s.driver;
  $("ts").textContent=new Date(s.ts*1000).toLocaleString("zh-CN");
  const memP=t.mem_total_mib?100*t.mem_used_mib/t.mem_total_mib:0;
  $("stats").innerHTML="";
  [["总功耗",fmt(t.power_w,0)+" W",s.gpus.length+" × S5000"],
   ["平均 GPU 利用率",fmt(t.avg_util,1)+" %",""],
   ["显存占用",fmt(t.mem_used_mib/1024,1)+" / "+fmt(t.mem_total_mib/1024,0)+" GB",
    memP.toFixed(1)+"%"],
   ["最高温度",fmt(t.max_temp_c,0)+" °C",""],
   ["GPU 进程数",String(s.processes.length),s.processes.length?"":"空闲"],
  ].forEach(([k,v,sub])=>{
    const d=el("div","stat");
    d.appendChild(el("div","k",k));d.appendChild(el("div","v",v));
    if(sub)d.appendChild(el("div","s",sub));
    $("stats").appendChild(d);});

  const cards=$("cards");cards.innerHTML="";
  s.gpus.forEach(g=>{
    const c=el("div","card");
    const head=el("div","card-head");
    const tt=el("div","t");tt.appendChild(statusDot(g));
    tt.appendChild(document.createTextNode("GPU "+g.index));
    tt.appendChild(el("small",null,g.name));
    head.appendChild(tt);
    const pl=document.createElement("span");
    pl.style.cssText="font-size:12px;color:var(--dim)";
    pl.textContent=fmt(g.power_w,0)+" / "+fmt(g.power_limit_w,0)+" W";
    head.appendChild(pl);c.appendChild(head);

    const main=el("div","main");
    const ring=el("div","ring");
    ring.innerHTML=ringSVG(g.util_gpu,"#38bdf8")+
      `<div class="val"><b>${fmt(g.util_gpu,0)}%</b><span>利用率</span></div>`;
    main.appendChild(ring);
    const kv=el("div","kv");
    [["显存",fmt(g.mem_used_mib)+" MiB"],
     ["温度",`<span style="color:${tempColor(g.temp_c)}">${fmt(g.temp_c,0)}°C</span>`],
     ["显存带宽利用",fmt(g.util_mem,0)+" %"],
     ["SM 频率",fmt(g.sm_clock_mhz,0)+" MHz"],
     ["显存频率",fmt(g.mem_clock_mhz,0)+" MHz"],
     ["PCIe",g.pcie_gen],
    ].forEach(([k,v])=>kv.appendChild(el("div",null,`<span>${k}</span><b>${v}</b>`)));
    main.appendChild(kv);c.appendChild(main);

    const mp=memPct(g);
    const bar=el("div","bar");
    bar.innerHTML=`<i style="width:${mp}%;background:linear-gradient(90deg,#6366f1,${memColor(mp)})"></i>
      <div class="txt">${fmt(g.mem_used_mib/1024,1)} / ${fmt(g.mem_total_mib/1024,0)} GB（${mp.toFixed(1)}%）</div>`;
    c.appendChild(bar);

    const cv=document.createElement("canvas");
    cv.className="spark";cv.dataset.gpu=g.index;c.appendChild(cv);

    c.appendChild(el("div","foot",
      `<span>ECC ${g.ecc_edc}/${g.ecc_on_die} · BIOS ${g.bios}</span>`+
      `<span>${g.bus_id}${g.slot?" · "+g.slot:""}</span>`+
      `<span>${g.serial?"SN "+g.serial:""}</span>`));
    cards.appendChild(c);});

  // 进程表
  const pc=$("procs");pc.innerHTML="";
  if(!s.processes.length){
    pc.appendChild(el("div","empty","当前没有占用 GPU 的进程"));
  }else{
    const tb=el("table");
    tb.innerHTML="<tr><th>GPU</th><th>PID</th><th>进程</th>"+
      "<th>GPU 利用率</th><th>显存利用率</th><th>显存占用</th></tr>"+
      s.processes.map(p=>`<tr><td>GPU ${p.gpu}</td><td>${p.pid}</td>
      <td title="${p.name}">${p.name}</td>
      <td>${p.gpu_util!=null?p.gpu_util+" %":"-"}</td>
      <td>${p.mem_util!=null?p.mem_util+" %":"-"}</td>
      <td>${p.mem_mib!=null?fmt(p.mem_mib)+" MiB":"-"}</td></tr>`).join("");
    pc.appendChild(tb);}

  requestAnimationFrame(()=>document.querySelectorAll(".spark").forEach(drawSpark));
}

async function poll(){
  try{
    const r=await fetch("/api/summary",{cache:"no-store"});
    if(!r.ok)throw new Error("HTTP "+r.status);
    const s=await r.json();lastSummary=s;
    $("err").style.display="none";
    if(s.ok)render(s);
    else throw new Error(s.error||"数据不可用");
  }catch(e){
    const d=$("err");d.style.display="block";
    d.textContent="获取数据失败："+e.message+"（mthreads-gmi 采样异常或服务重启中）";
  }
}
async function loadHist(){
  try{
    const r=await fetch("/api/history",{cache:"no-store"});
    HIST=await r.json();
  }catch(e){}
}
function schedule(){
  if(timer)clearInterval(timer);
  if($("auto").checked)timer=setInterval(poll,+$("rate").value);
}
$("auto").onchange=schedule;$("rate").onchange=schedule;
window.addEventListener("resize",()=>document.querySelectorAll(".spark").forEach(drawSpark));
(async()=>{
  await loadHist();await poll();schedule();
  setInterval(loadHist,300000);          // 5 分钟重新同步历史
})();
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    server_version = "GpuMon/1.0"

    def log_message(self, fmt, *args):  # 静默访问日志
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            body = PAGE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif path == "/api/summary":
            with LOCK:
                snap = dict(SNAPSHOT)
                topo = dict(TOPO)
            if not snap.get("ok"):
                self._json({"ok": False, "error": "尚未采集到数据（mthreads-gmi 无输出）"})
                return
            snap["numa"] = topo.get("numa", {})
            snap["cpu_aff"] = topo.get("cpu_aff", {})
            self._json(snap)
        elif path == "/api/history":
            with LOCK:
                data = list(HISTORY)
            self._json(data)
        elif path == "/api/topo":
            with LOCK:
                self._json(dict(TOPO))
        else:
            self._json({"error": "not found"}, 404)


def local_ips():
    ips = set()
    try:
        host = socket.gethostname()
    except Exception:
        return []
    for res in socket.getaddrinfo(host, None, socket.AF_INET):
        ips.add(res[4][0])
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    return sorted(ips)


def main():
    ap = argparse.ArgumentParser(description="MTT S5000 GPU 监控看板")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--interval", type=float, default=2.0,
                    help="采样间隔秒（默认 2）")
    args = ap.parse_args()

    if subprocess.run(["which", GMI], capture_output=True).returncode != 0:
        print("错误：未找到 %s，请确认 MUSA 驱动环境" % GMI)
        raise SystemExit(1)

    threading.Thread(target=sampler_loop, args=(args.interval,),
                     daemon=True).start()

    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    srv.daemon_threads = True
    print("=" * 56)
    print(" MTT S5000 显卡监控看板已启动")
    print(" 采样间隔 %.0fs · 历史 %d 点（约 1 小时）"
          % (args.interval, HISTORY_MAX))
    for ip in local_ips():
        print("   http://%s:%d" % (ip, args.port))
    print("=" * 56, flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n收到 Ctrl+C，退出。")


if __name__ == "__main__":
    main()
