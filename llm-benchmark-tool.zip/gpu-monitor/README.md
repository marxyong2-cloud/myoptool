# MTT GPU 监控服务部署包（gpu-monitor）

v1.0（2026-09-03）

一套可在 **MTT 显卡服务器**（MTT S80 / S3000 / S4000 / S5000 等）上快速部署的
GPU 实时监控看板。纯 Python 标准库实现、单文件服务、无第三方依赖，
数据源为 MUSA 驱动自带的 `mthreads-gmi`。

浏览器访问即可查看：每卡利用率 / 显存 / 温度 / 功耗 / 频率 / PCIe / ECC、
GPU 进程表（进程名、显存占用、利用率）、GPU-NIC 拓扑矩阵，
含最近 1 小时历史曲线（利用率 + 功耗迷你图）。

> 本包为 ncuprof 项目交付物：**gpu-monitor 监控服务**（本 README 的部署对象）
> + **ncuprof 剖析器源码**（见第七节，在 CUDA 服务器上构建使用）。

## 一、包内容

| 文件 / 目录 | 说明 |
|---|---|
| `server.py` | 监控服务（单文件，Python 标准库，无需 pip 安装任何包） |
| `install.sh` | 一键部署脚本（安装 systemd 服务并启动） |
| `gpu-monitor.service` | systemd 单元示例（`install.sh` 会按端口自动生成实际单元） |
| `README.md` | 本文件 |
| `ncuprof/` | ncuprof CUDA kernel 性能剖析器源码（构建说明见其自带 README） |

## 二、环境要求

- MTT 显卡服务器，已安装 MUSA 驱动（有 `mthreads-gmi` 命令）
- Python ≥ 3.7（Ubuntu 20.04+ / CentOS 8+ 系统自带版本即满足）
- root 或 sudo 权限（用于安装 systemd 服务）
- 访问页面的电脑与服务器网络互通

## 三、快速部署（推荐）

```bash
tar xzf gpu-monitor.tar.gz
cd gpu-monitor

sudo bash install.sh          # 默认 8080 端口
sudo bash install.sh 8899     # 或指定其他端口
```

脚本会自动：检查环境 → 安装到 `/opt/gpu-monitor` → 注册 systemd 服务
（开机自启、崩溃自动重启）→ 健康检查 → 打印可访问的 URL。
完成后用任意电脑浏览器打开 `http://<服务器IP>:<端口>` 即可。

重复执行 `install.sh` 即为更新/重装（会覆盖旧单元并重启服务）。

## 四、配置说明

### 1. 监听端口 / 地址 / 采样间隔

`server.py` 支持的启动参数（改 systemd 单元中的 `ExecStart` 即可调整）：

| 参数 | 默认 | 说明 |
|---|---|---|
| `--host` | `0.0.0.0` | 监听地址；`0.0.0.0` = 所有网卡可访问 |
| `--port` | `8080` | 监听端口（`install.sh` 第一个参数） |
| `--interval` | `2` | 后台采样间隔（秒）；历史缓冲 1800 点 ≈ 1 小时 |

例：改为 5 秒采样——

```bash
sudo systemctl edit --full gpu-monitor
#   ExecStart=... server.py --host 0.0.0.0 --port 8080 --interval 5
sudo systemctl restart gpu-monitor
```

历史保留点数可改 `server.py` 顶部 `HISTORY_MAX`。

### 2. 防火墙放行（外部电脑访问不了时检查）

```bash
# Ubuntu (ufw)
sudo ufw allow 8080/tcp

# CentOS/RHEL (firewalld)
sudo firewall-cmd --permanent --add-port=8080/tcp && sudo firewall-cmd --reload

# 或 iptables
sudo iptables -A INPUT -p tcp --dport 8080 -j ACCEPT
```

云服务器还需在控制台**安全组**中放行对应 TCP 端口。

### 3. 服务管理

```bash
systemctl status  gpu-monitor     # 状态
systemctl restart gpu-monitor     # 重启
systemctl stop    gpu-monitor     # 停止
journalctl -u gpu-monitor -f      # 实时日志
```

### 4. 卸载

```bash
sudo systemctl disable --now gpu-monitor
sudo rm -f  /etc/systemd/system/gpu-monitor.service
sudo rm -rf /opt/gpu-monitor
sudo systemctl daemon-reload
```

## 五、无 systemd 环境（手动运行）

```bash
python3 server.py --host 0.0.0.0 --port 8080        # 前台运行（Ctrl+C 退出）

# 后台常驻（简单方式）
nohup python3 server.py --port 8080 > gpu-monitor.log 2>&1 &
```

## 六、页面功能与 API

页面（每 2 秒自动刷新，可调 1/2/5/10s，可暂停）：

- 顶部汇总卡：总功耗 / 平均利用率 / 显存占用 / 最高温度 / GPU 进程数
- 每卡卡片：利用率圆环、显存进度条、温度、功耗（对功率上限）、SM/显存频率、
  PCIe 链路、ECC、BIOS、序列号、最近 5 分钟利用率+功耗曲线
- GPU 进程表：GPU / PID / 进程名 / GPU 利用率 / 显存利用率 / 显存占用
- 拓扑矩阵：GPU-NIC 互联与 NUMA/CPU 亲和（`mthreads-gmi topo -m`）

接口（可直接对接自家监控/告警系统）：

| 路径 | 说明 |
|---|---|
| `/api/summary` | 最新快照：主机/驱动/每卡明细/进程表/汇总统计（JSON） |
| `/api/history` | 历史采样点 `{t, u[], p[], m[], c[]}`：时间/利用率/功耗/显存/温度 |
| `/api/topo` | 拓扑矩阵原文 + 每 GPU 的 NUMA/CPU 亲和 |

## 七、ncuprof/ 源码说明

`ncuprof/` 为开源 CUDA kernel 性能剖析器（对标 NVIDIA Nsight Compute 核心
功能），适用于 **NVIDIA GPU + CUDA 11+** 的服务器：

```bash
cd ncuprof
mkdir build && cd build
cmake ..          # 检测到 CUDA 工具链时构建完整剖析器
make -j && ctest  # 无 CUDA 环境自动退化为逻辑层构建（单测 + Python 测试）
```

详细用法（`--set basic`、`-k regex:`、`-o` 报告、SQLite 导出等）见
`ncuprof/README.md` 与 `ncuprof/docs/`。

## 八、常见问题

| 现象 | 处理 |
|---|---|
| `install.sh` 报「端口已被占用」 | 换端口：`sudo bash install.sh <其他端口>` |
| 部署成功但浏览器打不开 | 服务器防火墙 / 云安全组放行端口（见第四节.2）；确认监听 `0.0.0.0` |
| 报「未找到 mthreads-gmi」 | 目标机器不是 MTT 显卡服务器，或 MUSA 驱动未安装 |
| 想改采样频率 / 历史长度 | `--interval` 参数 / `server.py` 顶部 `HISTORY_MAX`（见第四节.1） |
| 服务起不来 | `journalctl -u gpu-monitor -n 50` 查看日志 |
| 页面显示「获取数据失败」 | `mthreads-gmi -q --json` 手动执行看是否正常；驱动异常时服务会保留最后一次快照 |
