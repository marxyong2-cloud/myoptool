// ============================== 模型工作台视图(Model Use,SPA 子页) ==============================
import { computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { S, showStudioNav, loadLocalCfg, loadSessions, newSession, switchSession, saveSession, loadGw, loadLib } from "./mu-store.js";
import { api } from "./api.js";
import { hasPerm, isViewer } from "./auth.js";
import ChatView from "./mu-chat.js";
import { ChannelsView, KeysView } from "./mu-gateway.js";
import LogsView from "./mu-logs.js";
import { PromptsView, SkillsView } from "./mu-library.js";
import StudioView from "./mu-studio.js";
import DocsView from "./mu-docs.js";

const NAV = [
  { v: "chat", label: "对话", icon: "ChatDotRound" },
  { v: "channels", label: "渠道", icon: "Connection", perm: "gateway" },
  { v: "keys", label: "密钥", icon: "Key", perm: "gateway" },
  { v: "logs", label: "日志", icon: "DataLine", perm: "gateway" },
  { v: "prompts", label: "提示词", icon: "Notebook" },
  { v: "skills", label: "技能", icon: "MagicStick" },
  { v: "studio", label: "动漫工坊", icon: "Film", gated: true },
  { v: "docs", label: "接入", icon: "Guide" },
];
const VIEWS = {
  chat: ChatView, channels: ChannelsView, keys: KeysView, logs: LogsView,
  prompts: PromptsView, skills: SkillsView, studio: StudioView, docs: DocsView,
};

const ModelUseView = {
  setup() {
    const nav = computed(() => NAV.filter(n =>
      (!n.gated || (showStudioNav() && !isViewer())) && (!n.perm || hasPerm(n.perm))));
    const viewComp = computed(() => (VIEWS[S.view] && nav.value.some(n => n.v === S.view)) ? VIEWS[S.view] : ChatView);
    const activeSessions = computed(() => {
      const q = (S.sessSearch || "").trim().toLowerCase();
      return S.sessions.filter(s => !s.archived && (!q || (s.title || "").toLowerCase().includes(q))).slice().reverse();
    });
    const archivedSessions = computed(() => S.sessions.filter(s => s.archived).slice().reverse());

    // ---------- 会话列表:时间分组 + 相对时间(参考主流对话产品) ----------
    function _sessDate(s) {
      const t = new Date(String(s.created_at || "").replace(" ", "T"));
      return isNaN(t.getTime()) ? null : t;
    }
    const sessGroups = computed(() => {
      const q = (S.sessSearch || "").trim().toLowerCase();
      const list = S.sessions.filter(s => !s.archived && (!q || (s.title || "").toLowerCase().includes(q))).slice().reverse();
      const now = new Date();
      const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
      const yest = new Date(now.getTime() - 86400000);
      const groups = [["今天", []], ["昨天", []], ["近 7 天", []], ["更早", []]];
      for (const s of list) {
        const t = _sessDate(s);
        if (!t) { groups[3][1].push(s); continue; }
        if (sameDay(t, now)) groups[0][1].push(s);
        else if (sameDay(t, yest)) groups[1][1].push(s);
        else if ((now - t) / 86400000 < 7) groups[2][1].push(s);
        else groups[3][1].push(s);
      }
      return groups.filter(([, l]) => l.length).map(([label, items]) => ({ label, items }));
    });
    function relTime(s) {
      const t = _sessDate(s);
      if (!t) return "";
      const m = Math.floor((Date.now() - t.getTime()) / 60000);
      if (m < 1) return "刚刚";
      if (m < 60) return m + " 分钟前";
      const h = Math.floor(m / 60);
      if (h < 24) return h + " 小时前";
      if (h < 48) return "昨天";
      const d = Math.floor(h / 24);
      if (d < 7) return d + " 天前";
      return String(t.getMonth() + 1).padStart(2, "0") + "-" + String(t.getDate()).padStart(2, "0");
    }
    const msgCount = (s) => (s.messages || []).length;
    function sessCmd(c, s) {
      if (c === "rename") return renameSession(s);
      if (c === "archive") return archiveSession(s);
      if (c === "clear") return clearSession(s);
      if (c === "delete") return deleteSession(s);
    }
    function archCmd(c, s) {
      if (c === "restore") return restoreSession(s);
      if (c === "delete") return deleteArchived(s);
    }

    function switchView(v) {
      if (v === "studio" && !showStudioNav()) return;
      S.view = v;          // 工坊预览停止由 StudioView onDeactivated 处理
    }
    async function onNewSession() { await newSession(false); S.view = "chat"; ElMessage.success("已新建会话"); }
    function onSessionClick(s) {
      if (S.mergeMode) {
        if (S.mergeSet.has(s.id)) S.mergeSet.delete(s.id); else S.mergeSet.add(s.id);
        return;
      }
      if (switchSession(s.id)) {
        if (S.view !== "chat") switchView("chat");   // 在其它页点会话 → 自动回对话窗口
      }
    }
    async function renameSession(s) {
      try {
        const { value } = await ElMessageBox.prompt("新名称", "重命名会话", { inputValue: s.title || "" });
        s.title = (value || "").trim() || s.title;
        s._titled = true;
        await saveSession();
      } catch {}
    }
    async function archiveSession(s) {
      s.archived = true;
      await api("/api/chat/sessions/" + s.id, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: s.title || "会话", archived: true, messages: s.messages || [], project: "" }),
      });
      await loadSessions();
      ElMessage.success("已归档");
    }
    async function clearSession(s) {
      try { await ElMessageBox.confirm(`清空「${s.title}」的全部消息?会话保留`, "清空会话", { type: "warning" }); } catch { return; }
      if (s.id === S.sid) { S.history = []; await saveSession(); }
      else {
        s.messages = [];
        await api("/api/chat/sessions/" + s.id, {
          method: "PUT", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: s.title || "会话", archived: false, messages: [], project: "" }),
        });
      }
      ElMessage.success("已清空");
    }
    async function deleteSession(s) {
      try { await ElMessageBox.confirm(`删除会话「${s.title || s.id}」?不可恢复`, "删除会话", { type: "warning" }); } catch { return; }
      await api("/api/chat/sessions/" + s.id, { method: "DELETE" });
      S.sessions = S.sessions.filter(x => x.id !== s.id);
      if (S.sid === s.id) { S.sid = null; await loadSessions(); }
      ElMessage.success("已删除");
    }
    async function restoreSession(s) {
      s.archived = false;
      await api("/api/chat/sessions/" + s.id, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: s.title || "会话", archived: false, messages: s.messages || [], project: "" }),
      });
      await loadSessions();
      switchSession(s.id);
      switchView("chat");
      ElMessage.success("已恢复");
    }
    async function deleteArchived(s) {
      try { await ElMessageBox.confirm(`删除归档会话「${s.title}」?`, "删除", { type: "warning" }); } catch { return; }
      await api("/api/chat/sessions/" + s.id, { method: "DELETE" });
      S.sessions = S.sessions.filter(x => x.id !== s.id);
    }
    // 合并
    function toggleMerge() {
      S.mergeMode = !S.mergeMode;
      S.mergeSet = new Set();
    }
    async function doMerge() {
      const list = S.sessions.filter(s => S.mergeSet.has(s.id));
      if (list.length < 2) { ElMessage.warning("至少勾选 2 个会话"); return; }
      list.sort((a, b) => String(a.created_at || "").localeCompare(String(b.created_at || "")));
      const target = list[0];
      target.messages = list.flatMap(s => s.messages || []);
      target.title = target.title + " (合并" + list.length + ")";
      target._titled = true;
      try {
        await api("/api/chat/sessions/" + target.id, {
          method: "PUT", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: target.title, archived: false, messages: target.messages, project: "" }),
        });
        for (const s of list.slice(1)) await api("/api/chat/sessions/" + s.id, { method: "DELETE" });
        S.mergeMode = false; S.mergeSet = new Set();
        S.sid = target.id;
        await loadSessions();
        ElMessage.success(`已合并 ${list.length} 个会话`);
      } catch (e) { ElMessage.error("合并失败: " + e.message); }
    }
    async function clearAll() {
      try {
        await ElMessageBox.confirm("删除全部会话(含已归档)?不可恢复!", "清空全部", { type: "warning" });
      } catch { return; }
      try {
        await ElMessageBox.confirm("再次确认:真的要清空全部会话记录吗?", "二次确认", { type: "error" });
      } catch { return; }
      for (const s of S.sessions) {
        try { await api("/api/chat/sessions/" + s.id, { method: "DELETE" }); } catch {}
      }
      S.sessions = []; S.sid = null;
      await loadSessions();
      ElMessage.success("已清空全部会话");
    }

    onMounted(async () => {
      loadLocalCfg();
      try {
        await Promise.all([loadGw(), loadLib()]);
        await loadSessions();
      } catch (e) { console.error(e); ElMessage.error("初始化失败: " + e.message); }
    });

    return {
      S, nav, viewComp, activeSessions, archivedSessions,
      sessGroups, relTime, msgCount, sessCmd, archCmd,
      switchView, onNewSession, onSessionClick,
      renameSession, archiveSession, clearSession, deleteSession, restoreSession, deleteArchived,
      toggleMerge, doMerge, clearAll,
    };
  },
  template: `
  <div class="mu-view">
    <nav class="subnav">
      <button v-for="n in nav" :key="n.v" class="subnav-btn" :class="{ on: S.view === n.v }"
              @click="switchView(n.v)">
        <el-icon><component :is="n.icon"/></el-icon>{{ n.label }}
      </button>
    </nav>
    <div class="app-body">
      <aside class="mu-aside">
        <div class="aside-head">
          <span class="aside-title">会话<em>({{ activeSessions.length }})</em></span>
          <span class="grow"></span>
          <el-button size="small" type="primary" @click="onNewSession"><el-icon><Plus/></el-icon>新建会话</el-button>
          <el-tooltip content="勾选多个会话按时间顺序合并" placement="bottom">
            <el-button size="small" :type="S.mergeMode ? 'warning' : ''" @click="toggleMerge" title="合并会话">
              <el-icon><Connection/></el-icon>
            </el-button>
          </el-tooltip>
        </div>
        <el-input v-model="S.sessSearch" placeholder="搜索会话…" size="small" clearable
          prefix-icon="Search" class="aside-search"/>
        <!-- 合并模式提示条 -->
        <div v-if="S.mergeMode" class="merge-bar">
          <span style="font-size:11.5px;">已选 {{ S.mergeSet.size }} 个</span>
          <span class="grow"></span>
          <el-button size="small" type="primary" :disabled="S.mergeSet.size < 2" @click="doMerge">合并</el-button>
          <el-button size="small" @click="toggleMerge">取消</el-button>
        </div>
        <div class="sess-list">
          <div v-if="!activeSessions.length" class="sess-empty">{{ S.sessSearch ? "没有匹配的会话" : "暂无会话" }}</div>
          <template v-for="g in sessGroups" :key="g.label">
            <div class="sess-group-label">{{ g.label }}</div>
            <div v-for="s in g.items" :key="s.id" class="sess-item" :class="{ on: s.id === S.sid }">
              <el-checkbox v-if="S.mergeMode" :model-value="S.mergeSet.has(s.id)"
                @update:model-value="() => onSessionClick(s)" @click.stop/>
              <div class="sess-main" @click="onSessionClick(s)" :title="s.title + (s.created_at ? ' · ' + s.created_at : '')">
                <div class="t">{{ s.title || "未命名" }}</div>
                <div class="sub">
                  <span>{{ relTime(s) }}</span>
                  <span v-if="msgCount(s)">{{ msgCount(s) }} 条消息</span>
                </div>
              </div>
              <el-dropdown v-if="!S.mergeMode" trigger="click" @command="(c) => sessCmd(c, s)">
                <span class="sess-more" @click.stop title="更多操作"><el-icon><MoreFilled/></el-icon></span>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item command="rename"><el-icon><EditPen/></el-icon>重命名</el-dropdown-item>
                    <el-dropdown-item command="archive"><el-icon><Box/></el-icon>归档</el-dropdown-item>
                    <el-dropdown-item command="clear"><el-icon><Brush/></el-icon>清空消息</el-dropdown-item>
                    <el-dropdown-item command="delete" divided><el-icon><Delete/></el-icon>删除</el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </div>
          </template>
        </div>
        <!-- 归档区 -->
        <div class="aside-foot" style="cursor:pointer;" @click="S.archOpen = !S.archOpen">
          <span>📦 归档({{ archivedSessions.length }})</span>
          <span class="grow"></span>
          <span>{{ S.archOpen ? '▾' : '▸' }}</span>
        </div>
        <div v-if="S.archOpen && archivedSessions.length" class="arch-list">
          <div v-for="s in archivedSessions" :key="s.id" class="sess-item">
            <div class="sess-main" :title="s.title + (s.created_at ? ' · ' + s.created_at : '')">
              <div class="t">📦 {{ s.title || "未命名" }}</div>
              <div class="sub">
                <span>{{ relTime(s) }}</span>
                <span v-if="msgCount(s)">{{ msgCount(s) }} 条消息</span>
              </div>
            </div>
            <el-dropdown trigger="click" @command="(c) => archCmd(c, s)">
              <span class="sess-more" @click.stop title="更多操作"><el-icon><MoreFilled/></el-icon></span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="restore"><el-icon><RefreshLeft/></el-icon>恢复为普通会话</el-dropdown-item>
                  <el-dropdown-item command="delete" divided><el-icon><Delete/></el-icon>删除</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
        <div class="aside-foot">
          <el-button text size="small" type="danger" @click="clearAll">清空全部</el-button>
          <span class="grow"></span>
          <span class="sess-count">{{ activeSessions.length }}</span>
        </div>
      </aside>
      <main class="view-page">
        <KeepAlive><component :is="viewComp"/></KeepAlive>
      </main>
    </div>
  </div>`,
};

export default ModelUseView;
