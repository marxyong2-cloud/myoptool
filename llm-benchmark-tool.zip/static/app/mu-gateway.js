// ============================== 网关:渠道管理 + 密钥管理 ==============================
import { ref, reactive, computed, onMounted, watch } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { S, loadGw } from "./mu-store.js";
import { api, copyText } from "./api.js";
import { fmtNum } from "./fmt.js";
import { isAdmin } from "./auth.js";

const TYPE_BADGE = { chat: "💬 对话", image: "🎨 文生图", video: "🎬 视频", audio: "🎤 音频", embedding: "🔢 嵌入" };

// ---------- 渠道 ----------
export const ChannelsView = {
  setup() {
    const q = ref("");
    const dlg = ref(false);
    const probing = reactive({});
    const expanded = ref([]);
    const form = reactive({ id: "", name: "", base_url: "", api_key: "", protocol: "openai",
      types: ["chat"], models: [], priority: 0, note: "", enabled: true });
    const typeOptions = [
      { value: "chat", label: "对话" }, { value: "image", label: "文生图" },
      { value: "video", label: "视频" }, { value: "audio", label: "音频" }, { value: "embedding", label: "嵌入" },
    ];
    const modelsText = ref("");

    const list = computed(() => S.channels.filter(ch => {
      const s = q.value.trim().toLowerCase();
      if (!s) return true;
      return (ch.name || "").toLowerCase().includes(s)
        || (ch.base_url || "").toLowerCase().includes(s)
        || (ch.models || []).some(m => m.toLowerCase().includes(s));
    }));
    const modelCount = computed(() => {
      const set = new Set();
      S.channels.forEach(c => (c.models || []).forEach(m => set.add(m)));
      return set.size;
    });
    const enabledCount = computed(() => S.channels.filter(c => c.enabled !== false).length);

    function openDlg(ch) {
      form.id = ch ? ch.id : "";
      form.name = ch ? ch.name : "";
      form.base_url = ch ? ch.base_url : "";
      form.api_key = ch ? (ch.api_key || "") : "";
      form.protocol = ch ? (ch.protocol || "openai") : "openai";
      form.types = ch ? (ch.types || ["chat"]).slice() : ["chat"];
      form.priority = ch ? (ch.priority ?? 0) : 0;
      form.note = ch ? (ch.note || "") : "";
      form.enabled = ch ? ch.enabled !== false : true;
      modelsText.value = ch ? (ch.models || []).join("\n") : "";
      dlg.value = true;
    }
    let autoTimer = null;
    function onUrlInput() {
      clearTimeout(autoTimer);
      if (!/^https?:\/\/.+\..+|^https?:\/\/[\d.]+/.test(form.base_url.trim())) return;
      autoTimer = setTimeout(() => autoDetect(false), 1200);
    }
    async function autoDetect(manual) {
      const url = form.base_url.trim();
      if (!url) { if (manual) ElMessage.warning("请先填 Base URL"); return; }
      form.detectCtx = ""; form.detecting = true;
      try {
        const r = await api("/api/detect", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ api_url: url, api_key: form.api_key }),
        });
        if (r.protocol && r.protocol !== "unknown") form.protocol = r.protocol;
        if (r.models && r.models.length) modelsText.value = r.models.join("\n");
        const caps = r.capabilities || [];
        if (caps.length) {
          form.types = ["chat", "image", "video", "audio", "embedding"].filter(t => caps.includes(t));
          if (!form.types.length) form.types = ["chat"];
        }
        form.detectCtx = `✓ ${r.framework || "未知框架"} · 协议 ${r.protocol} · ${(r.models || []).length} 模型`;
      } catch (e) {
        form.detectCtx = "识别失败: " + e.message;
        if (manual) ElMessage.error("识别失败: " + e.message);
      }
      form.detecting = false;
    }
    async function save() {
      const body = {
        id: form.id, name: form.name.trim(), base_url: form.base_url.trim(),
        api_key: form.api_key, protocol: form.protocol,
        types: form.types.length ? form.types : ["chat"],
        models: modelsText.value.split("\n").map(s => s.trim()).filter(Boolean),
        priority: parseInt(form.priority, 10) || 0,
        enabled: form.enabled, note: form.note.trim(),
      };
      if (!body.name || !body.base_url) { ElMessage.warning("名称与 Base URL 必填"); return; }
      try {
        const r = await api("/api/gateway/channels", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
        });
        dlg.value = false;
        await loadGw();
        ElMessage.success(body.id ? "渠道已保存" : `渠道已添加${(r.models || []).length ? `(自动识别 ${r.models.length} 个模型)` : ""}`);
      } catch (e) { ElMessage.error(e.message); }
    }
    async function toggleCh(ch, on) {
      try {
        await api("/api/gateway/channels", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...ch, enabled: on }),
        });
        ch.enabled = on;
        ElMessage.success(on ? `✅ 已启用「${ch.name}」` : `⏸ 已停用「${ch.name}」(不再参与转发)`);
      } catch (err) { ElMessage.error(err.message); }
      await loadGw();
    }
    async function probe(ch) {
      probing[ch.id] = true;
      try {
        const r = await api(`/api/gateway/channels/${ch.id}/probe`, { method: "POST" });
        ElMessage.success(`✅ ${ch.name} · ${r.framework || r.protocol} · ${r.latency_ms}ms · ${r.models.length} 模型`);
        if (r.models && r.models.length) {
          try {
            await ElMessageBox.confirm(`检测到 ${r.models.length} 个模型,是否更新到渠道配置?`, "更新模型", { type: "info" });
            await api("/api/gateway/channels", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ ...ch, models: r.models }),
            });
          } catch {}
        }
      } catch (e) { ElMessage.error(`❌ ${ch.name}: ${e.message}`); }
      probing[ch.id] = false;
      await loadGw();
    }
    async function remove(ch) {
      try { await ElMessageBox.confirm(`删除渠道「${ch.name}」?`, "删除", { type: "warning" }); } catch { return; }
      await api("/api/gateway/channels/" + ch.id, { method: "DELETE" });
      await loadGw();
      ElMessage.success("已删除");
    }
    function latText(lat) { return lat == null ? "—" : lat < 0 ? "失败" : lat >= 1000 ? (lat / 1000).toFixed(1) + "s" : Math.round(lat) + "ms"; }
    function latType(lat) { return lat == null ? "info" : lat < 0 ? "danger" : lat < 500 ? "success" : lat < 2000 ? "warning" : "danger"; }

    onMounted(loadGw);
    return { S, q, dlg, form, probing, expanded, list, modelCount, enabledCount, typeOptions, modelsText,
      openDlg, onUrlInput, autoDetect, save, toggleCh, probe, remove, latText, latType, TYPE_BADGE, fmtNum,
      canManage: isAdmin() };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>🔌 渠道管理</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">聚合上游 API 统一对外暴露,按优先级故障转移</span>
      <span class="grow"></span>
      <el-input v-model="q" placeholder="搜索名称/地址/模型…" size="small" clearable prefix-icon="Search" style="width:220px;"/>
      <el-button v-if="canManage" type="primary" size="small" @click="openDlg(null)">＋ 添加渠道</el-button>
      <span v-else class="ms-mini-badge" title="网关由管理员统一配置,当前账号仅可查看">只读</span>
    </div>
    <div class="stat-cards">
      <div class="stat-card"><div class="k">🔗 渠道总数</div><div class="v">{{ S.channels.length }}</div></div>
      <div class="stat-card"><div class="k">✅ 已启用</div><div class="v">{{ enabledCount }}</div></div>
      <div class="stat-card"><div class="k">🧠 聚合模型数</div><div class="v">{{ modelCount }}</div></div>
      <div class="stat-card"><div class="k">📈 总调用</div><div class="v">{{ fmtNum(S.stats.total || 0) }}</div></div>
    </div>
    <el-card shadow="never">
      <el-table :data="list" row-key="id" empty-text="暂无渠道,点右上「＋ 添加渠道」把已有 HTTP API 接入网关">
        <el-table-column type="expand">
          <template #default="{ row }">
            <div style="padding:4px 8px;">
              <el-tag v-for="m in row.models" :key="m" size="small" type="info" class="model-mchip">{{ m }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="启用" width="70">
          <template #default="{ row }">
            <el-switch v-if="canManage" :model-value="row.enabled !== false" size="small"
              @update:model-value="on => toggleCh(row, on)"/>
            <el-tag v-else size="small" :type="row.enabled !== false ? 'success' : 'info'">{{ row.enabled !== false ? '启用' : '停用' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="渠道" min-width="170">
          <template #default="{ row }">
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="ch-ava">{{ (row.name || '?').trim().charAt(0).toUpperCase() }}</span>
              <div><b>{{ row.name }}</b>
                <div v-if="row.note" style="font-size:10.5px;color:var(--el-text-color-secondary);">{{ row.note }}</div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="协议/能力" width="150">
          <template #default="{ row }">
            <el-tag size="small" type="primary">{{ row.protocol || 'openai' }}</el-tag>
            <div style="margin-top:3px;">
              <el-tag v-for="t in (row.types || [])" :key="t" size="small" type="info" style="margin-right:3px;">{{ TYPE_BADGE[t] || t }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="Base URL" min-width="170" show-overflow-tooltip>
          <template #default="{ row }"><span class="mono" style="font-size:11px;">{{ row.base_url }}</span></template>
        </el-table-column>
        <el-table-column label="模型" width="110">
          <template #default="{ row }">
            <el-tag v-if="(row.models || []).length" size="small" type="warning">{{ row.models.length }} 个模型</el-tag>
            <el-tag v-else size="small" type="danger">未配置</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="priority" label="优先级" width="72"/>
        <el-table-column label="最近探测" width="100">
          <template #default="{ row }">
            <el-tag :type="latType(row.last_latency_ms)" size="small">{{ latText(row.last_latency_ms) }}</el-tag>
            <div v-if="row.last_probe_at" style="font-size:9.5px;color:var(--el-text-color-secondary);">{{ (row.last_probe_at || '').split(' ')[1] }}</div>
          </template>
        </el-table-column>
        <el-table-column label="调用量" width="86">
          <template #default="{ row }">{{ fmtNum((S.stats.by_channel || {})[row.name] || 0) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="210" fixed="right">
          <template #default="{ row }">
            <el-button size="small" :loading="probing[row.id]" @click="probe(row)">测试</el-button>
            <el-button v-if="canManage" size="small" @click="openDlg(row)">编辑</el-button>
            <el-button v-if="canManage" size="small" type="danger" plain @click="remove(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dlg" :title="form.id ? '编辑渠道' : '添加渠道'" width="560px">
      <el-form label-width="84px" label-position="left">
        <el-form-item label="名称"><el-input v-model="form.name" placeholder="如:本地 SGLang"/></el-form-item>
        <el-form-item label="Base URL">
          <el-input v-model="form.base_url" placeholder="http://127.0.0.1:30000/v1" @input="onUrlInput"/>
        </el-form-item>
        <el-form-item label="API Key">
          <div style="display:flex;gap:8px;width:100%;">
            <el-input v-model="form.api_key" type="password" show-password class="grow" @input="onUrlInput"/>
            <el-button :loading="form.detecting" @click="autoDetect(true)">识别</el-button>
          </div>
        </el-form-item>
        <el-form-item label="协议">
          <el-select v-model="form.protocol">
            <el-option value="openai" label="OpenAI"/><el-option value="anthropic" label="Anthropic"/>
            <el-option value="ollama" label="Ollama"/>
          </el-select>
        </el-form-item>
        <el-form-item label="能力类型">
          <el-checkbox-group v-model="form.types">
            <el-checkbox v-for="t in typeOptions" :key="t.value" :value="t.value">{{ t.label }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="模型列表">
          <el-input v-model="modelsText" type="textarea" :rows="4" placeholder="每行一个模型;填地址自动识别"/>
        </el-form-item>
        <el-form-item label="优先级">
          <el-input-number v-model="form.priority" :step="1"/>
          <span style="font-size:11px;color:var(--el-text-color-secondary);margin-left:8px;">越大越优先</span>
        </el-form-item>
        <el-form-item label="备注"><el-input v-model="form.note"/></el-form-item>
        <el-form-item label="启用"><el-switch v-model="form.enabled"/></el-form-item>
      </el-form>
      <div v-if="form.detectCtx" style="font-size:12px;color:var(--el-text-color-secondary);margin-bottom:8px;">{{ form.detectCtx }}</div>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>`,
};

// ---------- 密钥 ----------
export const KeysView = {
  setup() {
    const q = ref("");
    const dlg = ref(false);
    const form = reactive({ key: "", name: "", quota: 0, expires_at: "", enabled: true,
      allowed_channels: [], allowed_models: [] });
    const chSel = ref([]);
    const modelSel = ref([]);

    const list = computed(() => S.keys.filter(k => {
      const s = q.value.trim().toLowerCase();
      return !s || (k.name || "").toLowerCase().includes(s) || (k.key || "").toLowerCase().includes(s);
    }));
    const enabledCount = computed(() => S.keys.filter(k => k.enabled !== false).length);
    const totalUsed = computed(() => S.keys.reduce((a, k) => a + (k.used || 0), 0));
    const successRate = computed(() => S.stats.total ? Math.round((S.stats.success / S.stats.total) * 100) + "%" : "—");
    const modelPool = computed(() => {
      const pool = new Set();
      (chSel.value.length ? S.channels.filter(c => chSel.value.includes(c.id)) : S.channels)
        .forEach(c => (c.models || []).forEach(m => pool.add(m)));
      return [...pool].sort();
    });
    // 可选模型池变化时,清掉已不在池内的勾选(不能在 computed 里写 modelSel,否则读写同一依赖导致无限重渲染)
    watch(modelPool, pool => { modelSel.value = modelSel.value.filter(m => pool.includes(m)); });

    function openDlg(k) {
      form.key = k ? k.key : "";
      form.name = k ? (k.name || "") : "";
      form.quota = k ? (k.quota || 0) : 0;
      form.expires_at = k ? (k.expires_at || "") : "";
      form.enabled = k ? k.enabled !== false : true;
      chSel.value = ((k && k.allowed_channels) || []).slice();
      modelSel.value = ((k && k.allowed_models) || []).slice();
      dlg.value = true;
    }
    async function save() {
      const body = {
        key: form.key, name: form.name.trim() || "默认密钥",
        allowed_channels: chSel.value, allowed_models: modelSel.value,
        quota: parseInt(form.quota, 10) || 0, expires_at: form.expires_at || "",
        enabled: form.enabled,
      };
      try {
        await api("/api/gateway/keys", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
        });
        dlg.value = false;
        await loadGw();
        ElMessage.success(body.key ? "密钥已保存" : "已生成,可在列表复制完整密钥");
      } catch (e) { ElMessage.error(e.message); }
    }
    async function toggleKey(k, on) {
      try {
        await api("/api/gateway/keys", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: k.key, name: k.name, allowed_channels: k.allowed_channels || [],
            allowed_models: k.allowed_models || [], quota: k.quota || 0,
            expires_at: k.expires_at || "", enabled: on }),
        });
        ElMessage.success(on ? `✅ 已启用「${k.name}」` : `⏸ 已禁用「${k.name}」(调用立即 403)`);
      } catch (err) { ElMessage.error(err.message); }
      await loadGw();
    }
    async function remove(k) {
      try { await ElMessageBox.confirm(`删除密钥「${k.name}」?使用它的调用方将立即失效`, "删除", { type: "warning" }); } catch { return; }
      await api("/api/gateway/keys/" + encodeURIComponent(k.key), { method: "DELETE" });
      await loadGw();
      ElMessage.success("已删除");
    }
    function chName(id) { const c = S.channels.find(x => x.id === id); return c ? c.name : id; }
    function expDays(k) {
      if (!k.expires_at) return null;
      return Math.ceil((new Date(k.expires_at + "T23:59:59").getTime() - Date.now()) / 86400000);
    }

    onMounted(loadGw);
    return { S, q, dlg, form, chSel, modelSel, list, enabledCount, totalUsed, successRate, modelPool,
      openDlg, save, toggleKey, remove, chName, expDays, TYPE_BADGE, fmtNum, copyText,
      canManage: isAdmin() };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>🔑 密钥管理</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">对外分发网关密钥(配额/有效期/绑定渠道与模型)</span>
      <span class="grow"></span>
      <el-input v-model="q" placeholder="搜索名称/密钥…" size="small" clearable prefix-icon="Search" style="width:200px;"/>
      <el-button v-if="canManage" type="primary" size="small" @click="openDlg(null)">＋ 生成密钥</el-button>
      <span v-else class="ms-mini-badge" title="网关由管理员统一配置,当前账号仅可查看">只读</span>
    </div>
    <div class="stat-cards">
      <div class="stat-card"><div class="k">🔑 密钥总数</div><div class="v">{{ S.keys.length }}</div></div>
      <div class="stat-card"><div class="k">✅ 已启用</div><div class="v">{{ enabledCount }}</div></div>
      <div class="stat-card"><div class="k">📈 密钥累计调用</div><div class="v">{{ fmtNum(totalUsed) }}</div></div>
      <div class="stat-card"><div class="k">🎯 网关成功率</div><div class="v">{{ successRate }}</div></div>
    </div>
    <el-card shadow="never">
      <el-table :data="list" row-key="key" empty-text="暂无密钥,点「＋ 生成密钥」创建(可绑定渠道与其模型)">
        <el-table-column label="启用" width="70">
          <template #default="{ row }">
            <el-switch v-if="canManage" :model-value="row.enabled !== false" size="small"
              @update:model-value="on => toggleKey(row, on)"/>
            <el-tag v-else size="small" :type="row.enabled !== false ? 'success' : 'info'">{{ row.enabled !== false ? '启用' : '停用' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="密钥" width="150">
          <template #default="{ row }"><span class="mono" style="font-size:11.5px;">{{ row.key.slice(0, 7) }}…{{ row.key.slice(-4) }}</span></template>
        </el-table-column>
        <el-table-column prop="name" label="名称" min-width="100"/>
        <el-table-column label="绑定渠道" min-width="120">
          <template #default="{ row }">
            <template v-if="(row.allowed_channels || []).length">
              <el-tag v-for="c in row.allowed_channels" :key="c" size="small" type="warning" style="margin-right:3px;">{{ chName(c) }}</el-tag>
            </template>
            <el-tag v-else size="small" type="success">全部</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="允许模型" min-width="130">
          <template #default="{ row }">
            <template v-if="(row.allowed_models || []).length">
              <el-tag v-for="m in row.allowed_models.slice(0, 3)" :key="m" size="small" type="info" style="margin-right:3px;">{{ m }}</el-tag>
              <el-tag v-if="row.allowed_models.length > 3" size="small" type="info">+{{ row.allowed_models.length - 3 }}</el-tag>
            </template>
            <el-tag v-else size="small" type="success">不限</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="用量 / 配额" width="190">
          <template #default="{ row }">
            <el-progress v-if="row.quota" :percentage="Math.min(100, Math.round((row.used || 0) / row.quota * 100))"
              :status="(row.used || 0) / row.quota >= 0.9 ? 'exception' : (row.used || 0) / row.quota >= 0.7 ? 'warning' : 'success'"
              :stroke-width="14" style="flex:1;"/>
            <div style="font-size:11px;">{{ fmtNum(row.used || 0) }} / {{ row.quota ? fmtNum(row.quota) : '∞' }}</div>
          </template>
        </el-table-column>
        <el-table-column label="有效期" width="120">
          <template #default="{ row }">
            <template v-if="row.expires_at">
              <el-tag v-if="expDays(row) < 0" size="small" type="danger">已过期</el-tag>
              <template v-else>
                <div>{{ row.expires_at }}</div>
                <div style="font-size:9.5px;color:var(--el-text-color-secondary);">剩 {{ expDays(row) }} 天</div>
              </template>
            </template>
            <span v-else>永久</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="210" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="copyText(row.key, '完整密钥已复制')">复制</el-button>
            <el-button v-if="canManage" size="small" @click="openDlg(row)">编辑</el-button>
            <el-button v-if="canManage" size="small" type="danger" plain @click="remove(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dlg" :title="form.key ? '编辑密钥' : '生成密钥'" width="560px">
      <el-form label-width="84px" label-position="left">
        <el-form-item label="名称"><el-input v-model="form.name" placeholder="如:给前端同学的密钥"/></el-form-item>
        <el-form-item label="绑定渠道">
          <div style="display:flex;flex-direction:column;gap:4px;width:100%;">
            <el-empty v-if="!S.channels.length" description="暂无渠道,请先在「渠道」页添加" :image-size="50"/>
            <el-check-tag v-for="c in S.channels" :key="c.id" :checked="chSel.includes(c.id)"
              @change="v => chSel = v ? [...chSel, c.id] : chSel.filter(x => x !== c.id)">
              {{ c.name }} · {{ c.protocol }} · {{ (c.models || []).length }} 模型
            </el-check-tag>
          </div>
        </el-form-item>
        <el-form-item label="允许模型">
          <div style="display:flex;flex-wrap:wrap;gap:6px;width:100%;">
            <el-empty v-if="!modelPool.length" description="所选范围暂无模型(先给渠道配置模型)" :image-size="50"/>
            <el-tag v-for="m in modelPool" :key="m" size="small" class="model-mchip"
              :type="modelSel.includes(m) ? 'primary' : 'info'" style="cursor:pointer;"
              @click="modelSel = modelSel.includes(m) ? modelSel.filter(x => x !== m) : [...modelSel, m]">{{ m }}</el-tag>
            <div v-if="modelPool.length" style="width:100%;font-size:10.5px;color:var(--el-text-color-secondary);padding-top:4px;">
              {{ modelSel.length ? '已选 ' + modelSel.length + ' 个模型' : '未选择 = 范围内全部模型' }}
            </div>
          </div>
        </el-form-item>
        <el-form-item label="配额">
          <el-input-number v-model="form.quota" :min="0" :step="100"/>
          <span style="font-size:11px;color:var(--el-text-color-secondary);margin-left:8px;">0 = 不限</span>
        </el-form-item>
        <el-form-item label="有效期">
          <el-date-picker v-model="form.expires_at" type="date" value-format="YYYY-MM-DD" placeholder="留空 = 永久"/>
        </el-form-item>
        <el-form-item label="启用"><el-switch v-model="form.enabled"/></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>`,
};
