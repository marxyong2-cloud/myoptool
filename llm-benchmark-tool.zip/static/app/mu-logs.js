// ============================== 网关调用日志 ==============================
import { ref, computed, onMounted, onUnmounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { S, loadLogs } from "./mu-store.js";
import { api } from "./api.js";
import { fmtNum } from "./fmt.js";
import { isAdmin } from "./auth.js";

export default {
  setup() {
    const auto = ref(true);
    let timer = null;

    const rate = computed(() => S.stats.total ? Math.round((S.stats.success / S.stats.total) * 100) + "%" : "—");

    async function clearLogs() {
      try {
        await ElMessageBox.confirm("清空全部调用日志与统计(密钥用量计数归零)?", "清空确认", { type: "warning" });
      } catch { return; }
      await api("/api/gateway/logs/clear", { method: "POST" });
      await loadLogs();
      ElMessage.success("已清空");
    }
    const refresh = () => loadLogs();

    onMounted(() => {
      loadLogs();
      timer = setInterval(() => { if (S.view === "logs" && auto.value) loadLogs(); }, 8000);
    });
    onUnmounted(() => clearInterval(timer));

    return { S, auto, rate, clearLogs, refresh, fmtNum, canManage: isAdmin() };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>📊 调用日志</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">网关全部对外调用的记录与统计(8 秒自动刷新)</span>
      <span class="grow"></span>
      <el-switch v-model="auto" active-text="自动刷新" size="small"/>
      <el-button size="small" @click="refresh"><el-icon style="margin-right:4px;"><Refresh/></el-icon>刷新</el-button>
      <el-button v-if="canManage" size="small" type="danger" plain @click="clearLogs">清空日志</el-button>
    </div>
    <div class="stat-cards">
      <div class="stat-card"><div class="k">总请求</div><div class="v">{{ fmtNum(S.stats.total || 0) }}</div></div>
      <div class="stat-card"><div class="k">成功率</div><div class="v">{{ rate }}</div></div>
      <div class="stat-card"><div class="k">平均延迟</div><div class="v">{{ (S.stats.avg_latency_ms || 0) }}ms</div></div>
      <div class="stat-card"><div class="k">P95 延迟</div><div class="v">{{ (S.stats.p95_latency_ms || 0) }}ms</div></div>
      <div class="stat-card"><div class="k">Tokens 入</div><div class="v">{{ fmtNum(S.stats.tokens_in || 0) }}</div></div>
      <div class="stat-card"><div class="k">Tokens 出</div><div class="v">{{ fmtNum(S.stats.tokens_out || 0) }}</div></div>
    </div>
    <el-card shadow="never">
      <el-table :data="[...S.logs].reverse()" empty-text="暂无调用记录;用「接入」页示例发起请求后,此处显示"
        :max-height="560">
        <el-table-column prop="ts" label="时间" width="165"/>
        <el-table-column prop="key" label="密钥" width="90"/>
        <el-table-column prop="channel" label="渠道" min-width="110"/>
        <el-table-column prop="model" label="模型" min-width="130"/>
        <el-table-column label="端点" min-width="180">
          <template #default="{ row }"><span class="mono" style="font-size:11px;">{{ row.endpoint }}</span></template>
        </el-table-column>
        <el-table-column label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.status < 400 ? 'success' : 'danger'" size="small">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="延迟" width="90">
          <template #default="{ row }">{{ row.latency_ms ?? '-' }}ms</template>
        </el-table-column>
        <el-table-column label="Tokens 入/出" width="120">
          <template #default="{ row }">{{ fmtNum(row.tokens_in) }} / {{ fmtNum(row.tokens_out) }}</template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>`,
};
