// ============================== 主题皮肤(六主题:海湾蓝 / 白蓝 / 赛博朋克 / 黑金 / 白艳红 / 黑白极简) ==============================
// 暗色基座:gulf(默认)/ cyberpunk / gold;亮色基座:whiteblue / whitered / mono
import { ref, computed } from "vue";

export const THEMES = [
  { id: "gulf", label: "海湾蓝(默认)" },
  { id: "whiteblue", label: "白蓝" },
  { id: "cyberpunk", label: "赛博朋克" },
  { id: "gold", label: "黑金" },
  { id: "whitered", label: "白艳红" },
  { id: "mono", label: "黑白极简" },
];

// 亮色主题:不挂 html.dark,Element Plus 走亮色基座
const LIGHT_THEMES = new Set(["whiteblue", "whitered", "mono"]);
export const isLightTheme = (t) => LIGHT_THEMES.has(t);

// 旧主题迁移:v3 十主题 → v4 六主题(暗色系归入海湾蓝,亮色归入白蓝)
const KEY = "bench-theme-v4";
const MIGRATE = {
  dark: "gulf", arctic: "gulf", neon: "gulf", matrix: "gulf", vapor: "gulf",
  lava: "gold", sakura: "whitered", light: "whiteblue",
};
function initial() {
  const saved = localStorage.getItem(KEY);
  if (saved && THEMES.some(t => t.id === saved)) return saved;
  for (const k of [KEY, "bench-theme-v3", "bench-theme-v2"]) {
    const v = localStorage.getItem(k);
    if (!v) continue;
    if (THEMES.some(t => t.id === v)) return v;
    if (MIGRATE[v]) return MIGRATE[v];
  }
  return "gulf";
}
const theme = ref(initial());

function apply() {
  const t = theme.value;
  document.documentElement.classList.toggle("dark", !isLightTheme(t));
  document.documentElement.setAttribute("data-theme", t);
  localStorage.setItem(KEY, t);
}
apply();

export function useTheme() {
  const setTheme = (t) => { theme.value = t; apply(); };
  // 兼容旧调用方的 mode/toggle(暗↔亮互切)
  const mode = computed(() => isLightTheme(theme.value) ? "light" : "dark");
  const toggle = () => setTheme(isLightTheme(theme.value) ? "gulf" : "whiteblue");
  return { theme, themes: THEMES, setTheme, mode, toggle };
}
