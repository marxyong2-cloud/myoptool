// ============================== 动漫工坊:生成 + 专业剪辑台 ==============================
import { ref, reactive, computed, onMounted, onDeactivated, nextTick } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { S, saveSession } from "./mu-store.js";
import { api } from "./api.js";
import { fmtSize, fmtAttBytes } from "./fmt.js";

const ST_STYLES = [
  ["🌸 日系赛璐璐", "日系动画赛璐璐风格,干净的勾线与高饱和色,番剧作画质感"],
  ["🎨 吉卜力水彩", "吉卜力工作室手绘水彩风格,温暖光影,细腻背景,宫崎骏动画质感"],
  ["🐉 国漫水墨", "中国风水墨动漫风格,泼墨背景,飘逸衣袂,国漫大作质感"],
  ["🌃 赛博动漫", "赛博朋克动漫风格,霓虹光效,高科技都市夜景,冷色调"],
  ["✏️ 漫画分镜", "黑白漫画分镜风格,速度线与网点纸质感,强对比阴影"],
  ["🎮 像素动漫", "复古像素动画风格,8-bit 游戏画面质感"],
  ["🍬 Q版萌系", "Q版萌系动画风格,大头小身,圆润线条,可爱表情包质感"],
];
const ST_SHOTS = [
  ["🏞 远景建立", "远景建立镜头,展现环境全貌"],
  ["🚶 中景跟随", "中景跟随镜头,平视角色行动"],
  ["🔍 面部特写", "面部特写镜头,捕捉表情细节"],
  ["💨 快速运动", "快速运动镜头,强调速度与冲击力"],
  ["🔄 环绕运镜", "环绕运镜,围绕主体旋转"],
  ["⬆️ 俯拍升降", "俯拍升降镜头,由上而下或缓缓上升"],
];
const SEQ_COLORS = [
  "linear-gradient(135deg,#6366f1,#8b5cf6)", "linear-gradient(135deg,#0ea5e9,#6366f1)",
  "linear-gradient(135deg,#8b5cf6,#d946ef)", "linear-gradient(135deg,#f59e0b,#f43f5e)",
  "linear-gradient(135deg,#10b981,#0ea5e9)",
];
const DUR_OPTS = Array.from({ length: 12 }, (_, k) => k + 4);

function stTc(t) {
  if (!isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  return String(m).padStart(2, "0") + ":" + (t - m * 60).toFixed(1).padStart(4, "0");
}

// ---------- 单个片段卡(胶片时间轴 + 手柄 + 播放头) ----------
const ClipCard = {
  props: ["t", "i"],
  emits: ["mark", "move", "remove", "playClip", "monSeek", "stopSeq"],
  setup(props, { emit }) {
    const stripRef = ref(null);
    const drag = ref(null);
    const tip = reactive({ show: false, txt: "", frac: 0 });

    const pct = (x) => {
      const dur = props.t.duration || 0;
      return dur > 0 ? Math.max(0, Math.min(100, x / dur * 100)) : 0;
    };
    const frames = computed(() => {
      const f = S.st.frames[props.t.name];
      return Array.isArray(f) ? f : [];
    });
    const phLeft = computed(() => pct(S.st.ph[props.t.name] ?? (props.t.start || 0)));

    const pos = (e) => {
      const r = stripRef.value.getBoundingClientRect();
      const dur = props.t.duration || 0;
      return { r, dur, frac: Math.max(0, Math.min(1, (e.clientX - r.left) / Math.max(1, r.width))) };
    };
    const showTip = (txt, frac) => { tip.show = true; tip.txt = txt; tip.frac = frac; };
    const hideTip = () => { tip.show = false; };
    const applyTrim = (mode, frac) => {
      const t = props.t, dur = t.duration;
      if (mode === "in") t.start = Math.max(0, Math.min(frac * dur, (t.end ?? dur) - 0.2));
      else t.end = Math.max((t.start || 0) + 0.2, Math.min(frac * dur, dur));
    };
    function onPointerDown(e) {
      const t = props.t;
      if (!t || !t.duration || e.button !== 0) return;
      e.preventDefault();
      stripRef.value.setPointerCapture(e.pointerId);
      emit("stopSeq");
      const { r, dur, frac } = pos(e);
      const x = frac * r.width;
      const inX = (t.start / dur) * r.width;
      const outX = ((t.end ?? dur) / dur) * r.width;
      let mode = "seek";
      if (Math.abs(x - inX) <= 9) mode = "in";
      else if (Math.abs(x - outX) <= 9) mode = "out";
      drag.value = { mode, x0: e.clientX, moved: false };
      if (mode === "seek") {
        S.st.ph[t.name] = frac * dur;
        emit("monSeek", { i: props.i, time: frac * dur, play: false });
      } else applyTrim(mode, frac);
      showTip((frac * dur).toFixed(1) + "s", frac);
    }
    function onPointerMove(e) {
      if (!drag.value) return;
      const { dur, frac } = pos(e);
      if (Math.abs(e.clientX - drag.value.x0) > 3) drag.value.moved = true;
      if (drag.value.mode === "seek") {
        S.st.ph[props.t.name] = frac * dur;
        emit("monSeek", { i: props.i, time: frac * dur, play: false, seekOnly: true });
      } else applyTrim(drag.value.mode, frac);
      showTip((frac * dur).toFixed(1) + "s", frac);
    }
    function onPointerUp(e) {
      if (!drag.value) return;
      const wasClick = !drag.value.moved, mode = drag.value.mode;
      drag.value = null;
      hideTip();
      if (wasClick && mode === "seek") {
        const { dur, frac } = pos(e);
        S.st.ph[props.t.name] = frac * dur;
        emit("monSeek", { i: props.i, time: frac * dur, play: true });   // 点击时间节点 → 预览动画
      }
    }
    return { S, stripRef, drag, tip, pct, frames, phLeft, onPointerDown, onPointerMove, onPointerUp, fmtSize };
  },
  template: `
  <div class="clip-card">
    <div class="clip-head">
      <span class="idx">{{ i + 1 }}</span>
      <span class="nm" :title="t.name">{{ t.name }}</span>
      <span class="grow"></span>
      <span class="st-chip">{{ t.duration ? '全 ' + t.duration.toFixed(1) + 's · 选用 ' + Math.max(0, (t.end ?? 0) - (t.start || 0)).toFixed(1) + 's' : '读取时长中…' }}</span>
    </div>
    <div ref="stripRef" class="strip"
      @pointerdown="onPointerDown" @pointermove="onPointerMove" @pointerup="onPointerUp"
      @pointercancel="drag = null; tip.show = false" @lostpointercapture="drag = null; tip.show = false">
      <div class="frames">
        <img v-for="(f, k) in frames" :key="k" :src="f" draggable="false"/>
        <div v-if="!frames.length" class="frames-ph">{{ t.duration ? t.duration.toFixed(1) + 's' : '…' }}</div>
      </div>
      <div class="dim a" :style="{ width: pct(t.start || 0) + '%' }"></div>
      <div class="dim b" :style="{ width: (100 - pct(t.end ?? t.duration)) + '%' }"></div>
      <div class="region" :style="{ left: pct(t.start || 0) + '%', width: Math.max(0, pct(t.end ?? t.duration) - pct(t.start || 0)) + '%' }"></div>
      <div class="hnd in" :style="{ left: pct(t.start || 0) + '%' }" title="拖动调整入点"></div>
      <div class="hnd out" :style="{ left: pct(t.end ?? t.duration) + '%' }" title="拖动调整出点"></div>
      <div class="ph" :style="{ left: phLeft + '%' }"></div>
      <div v-if="tip.show" class="tip" :style="{ left: tip.frac * 100 + '%' }">{{ tip.txt }}</div>
    </div>
    <div class="clip-io">
      <span>入</span>
      <input type="number" min="0" step="0.1" :value="t.start.toFixed(1)"
        @input="e => { const v = parseFloat(e.target.value); if (isFinite(v)) t.start = Math.max(0, v); }">
      <span>出</span>
      <input type="number" step="0.1" :value="t.end != null ? t.end.toFixed(1) : ''"
        @input="e => { const v = parseFloat(e.target.value); if (isFinite(v)) t.end = v; }">
      <span class="hint">秒 · 可拖手柄,或点时间轴后按「⏮ 入点」「⏭ 出点」打点</span>
    </div>
    <div class="clip-ops">
      <button title="把入点设到当前播放头位置" @click="$emit('mark', i, 'in')">⏮ 入点</button>
      <button title="把出点设到当前播放头位置" @click="$emit('mark', i, 'out')">⏭ 出点</button>
      <button title="在监视器试播本段(入点→出点)" @click="$emit('playClip', i)">▶ 片段</button>
      <button title="与前一段交换顺序" @click="$emit('move', i, -1)">⬆ 上移</button>
      <button title="与后一段交换顺序" @click="$emit('move', i, 1)">⬇ 下移</button>
      <button class="rm" title="从时间线移除(不删除文件)" @click="$emit('remove', i)">✕ 移除</button>
    </div>
  </div>`,
};

// ---------- 工坊主视图 ----------
export default {
  components: { ClipCard },
  setup() {
    const monRef = ref(null);
    const clipsRef = ref(null);
    const genStatus = ref("");
    const composeStatus = ref("");
    const resultCard = ref(false);
    const result = reactive({ url: "", name: "", info: "" });
    const monTime = ref(0);
    const monDur = ref(0);
    // 生成面板
    const prompt = ref("");
    const styles = ref(new Set());
    const shots = ref(new Set());
    const genForm = reactive({ dur: 5, res: "768P", ratio: "16:9", api: "auto" });
    const composeForm = reactive({ res: "720p", fade: true, title: "" });

    const st = () => S.st;
    const seqTotal = computed(() => S.st.timeline.reduce((a, t) => a + Math.max(0, (t.end ?? 0) - (t.start || 0)), 0));
    const ready = computed(() => S.st.timeline.length && S.st.timeline.every(t => t.end !== null && t.end > t.start + 0.1));
    const animeCount = computed(() => S.st.lib.filter(i => i.name.startsWith("anime_")).length);
    const clipCount = computed(() => S.st.lib.length - animeCount.value);
    const monClip = computed(() => S.st.timeline.find(x => x.name === S.st.mon.name) || null);
    const monName = computed(() => {
      const t = monClip.value;
      return t ? `#${S.st.timeline.indexOf(t) + 1} ${t.name}` : "未选片段";
    });
    const monOut = computed(() => {
      const t = monClip.value;
      return t ? (t.end ?? t.duration ?? monDur.value) : 0;
    });
    const seqStep = computed(() => seqTotal.value <= 12 ? 1 : seqTotal.value <= 40 ? 5 : 10);
    const seqTicks = computed(() => {
      const out = [];
      for (let s = 0; s <= Math.ceil(seqTotal.value); s += seqStep.value) {
        out.push({ s, p: Math.min(100, s / seqTotal.value * 100) });
      }
      return out;
    });
    const seqPhPct = ref(0);
    const inTl = (name) => S.st.timeline.some(t => t.name === name);

    function seqElapsed() {
      const t = monClip.value;
      if (!t) return 0;
      let before = 0;
      for (const x of S.st.timeline) { if (x === t) break; before += Math.max(0, (x.end ?? 0) - (x.start || 0)); }
      return before + Math.max(0, monRef.value.currentTime - (t.start || 0));
    }
    // ---- 监视器 ----
    function setMon(i, time, play) {
      const t = S.st.timeline[i];
      if (!t) return;
      S.st.mon.name = t.name;
      const v = monRef.value;
      S.st.mon.want = { time, play };
      const go = () => {
        const w = S.st.mon.want || {};
        try { if (w.time != null) v.currentTime = w.time; } catch (e) {}
        if (w.play) v.play().catch(() => {});
        else if (!v.paused) v.pause();
      };
      if (S.st.mon.url !== t.url) {
        S.st.mon.url = t.url;
        v.onloadedmetadata = () => { v.onloadedmetadata = null; go(); };
        v.src = t.url;
        v.load();
      } else go();
    }
    function monReset() {
      S.st.mon.name = null; S.st.mon.url = null; S.st.mon.want = null;
      const v = monRef.value;
      v.onloadedmetadata = null;
      v.pause();
      v.removeAttribute("src"); v.load();
    }
    function stSeqClip(k) {
      const t = S.st.timeline[k];
      if (!t) { stopSeq(); return; }
      S.st.mon.seqIdx = k;
      S.st.mon.seq = true;
      setMon(k, t.start || 0, true);
    }
    function playSeq() {
      if (!S.st.timeline.length) { ElMessage.warning("时间线为空"); return; }
      if (!ready.value) { ElMessage.warning("有片段起止时间未就绪"); return; }
      S.st.mon.seq = true;
      stSeqClip(0);
    }
    function seqNext() {
      if (S.st.mon.seqIdx + 1 < S.st.timeline.length) stSeqClip(S.st.mon.seqIdx + 1);
      else { stopSeq(); ElMessage.success("整线预览完毕 ✅"); }
    }
    function stopSeq() {
      if (!S.st.mon.seq) return;
      S.st.mon.seq = false;
      monRef.value && monRef.value.pause();
      seqPhPct.value = 0;
    }
    function stopAll() { stopSeq(); try { monRef.value && monRef.value.pause(); } catch (e) {} }
    function togglePlay() {
      const t = monClip.value;
      if (!t) { ElMessage.warning("先点击某个片段的胶片时间轴选择画面"); return; }
      const v = monRef.value;
      if (v.paused) {
        if (t.end != null && v.currentTime >= t.end - 0.05) v.currentTime = t.start || 0;
        v.play().catch(() => {});
      } else v.pause();
    }
    const playing = ref(false);
    function onTimeupdate() {
      const v = monRef.value;
      const t = monClip.value;
      if (!t) return;
      const out = t.end ?? t.duration ?? v.duration;
      if (v.currentTime >= out - 0.04) {
        if (S.st.mon.seq) { seqNext(); return; }
        if (!v.paused) v.pause();
      }
      monTime.value = v.currentTime;
      if (S.st.mon.seq) seqPhPct.value = Math.min(100, seqElapsed() / Math.max(0.01, seqTotal.value) * 100);
      S.st.ph[t.name] = v.currentTime;
    }
    onMounted(() => {
      monRef.value.addEventListener("timeupdate", onTimeupdate);
      monRef.value.addEventListener("play", () => playing.value = true);
      monRef.value.addEventListener("pause", () => playing.value = false);
      monRef.value.addEventListener("loadedmetadata", () => monDur.value = monRef.value.duration || 0);
      loadLib();
    });
    onDeactivated(stopAll);

    // ---- 片段库 ----
    async function loadLib() {
      try {
        const r = await api("/api/media/list?kind=video");
        S.st.lib = r.items || [];
      } catch (e) { S.st.lib = []; ElMessage.error("片段库加载失败: " + e.message); }
    }
    async function deleteMedia(item) {
      const inTimeline = inTl(item.name);
      try {
        await ElMessageBox.confirm(
          `删除文件「${item.name}」(${fmtSize(item.size)})?\n服务端文件将一并删除${inTimeline ? ",并从时间线移除" : ""},不可恢复`,
          "删除文件", { type: "warning" });
      } catch { return; }
      try {
        await api("/api/media/" + encodeURIComponent(item.name), { method: "DELETE" });
        S.st.lib = S.st.lib.filter(x => x.name !== item.name);
        if (inTimeline) {
          S.st.timeline = S.st.timeline.filter(t => t.name !== item.name);
          if (S.st.mon.name === item.name) monReset();
        }
        delete S.st.frames[item.name];
        delete S.st.ph[item.name];
        ElMessage.success("已删除: " + item.name);
      } catch (e) { ElMessage.error("删除失败: " + e.message); }
    }
    function addToTimeline(item, auto) {
      if (S.st.timeline.some(t => t.name === item.name)) { ElMessage.warning("该片段已在时间线"); return; }
      const t = { name: item.name, url: item.url, start: 0, end: null, duration: null };
      S.st.timeline.push(t);
      const v = document.createElement("video");
      v.preload = "metadata"; v.muted = true;
      v.onloadedmetadata = () => {
        if (v.duration && isFinite(v.duration)) {
          t.duration = v.duration;
          if (t.end === null) t.end = Math.round(v.duration * 10) / 10;
          captureFrames(t);
        }
      };
      v.src = item.url;
      if (auto !== false) ElMessage.success(`已加入时间线(${S.st.timeline.length} 段)`);
    }
    function captureFrames(t) {
      if (S.st.frames[t.name]) return;
      S.st.frames[t.name] = new Promise(resolve => {
        const N = 8, out = [];
        let done = false;
        const fin = () => { if (done) return; done = true; S.st.frames[t.name] = out; resolve(out); };
        const v = document.createElement("video");
        v.muted = true; v.preload = "auto"; v.playsInline = true;
        v.onloadedmetadata = () => {
          const dur = v.duration;
          if (!isFinite(dur) || dur <= 0) return fin();
          const cv = document.createElement("canvas");
          cv.width = 128; cv.height = 72;
          const cx = cv.getContext("2d");
          let i = 0;
          const next = () => {
            if (i >= N || done) return fin();
            try { v.currentTime = Math.max(0, Math.min(dur * (i + 0.5) / N, dur - 0.05)); } catch (e) { fin(); }
          };
          v.onseeked = () => {
            try { cx.drawImage(v, 0, 0, cv.width, cv.height); out.push(cv.toDataURL("image/jpeg", 0.55)); } catch (e) {}
            i++; next();
          };
          next();
        };
        v.onerror = fin;
        setTimeout(fin, 9000);
        v.src = t.url;
      });
    }
    // ---- 时间线操作 ----
    function tlMove(i, d) {
      const j = i + d;
      if (j < 0 || j >= S.st.timeline.length) return;
      [S.st.timeline[i], S.st.timeline[j]] = [S.st.timeline[j], S.st.timeline[i]];
    }
    function tlRemove(i) {
      const t = S.st.timeline[i];
      S.st.timeline.splice(i, 1);
      if (t && S.st.mon.name === t.name) monReset();
    }
    async function clearTl() {
      if (!S.st.timeline.length) return;
      try { await ElMessageBox.confirm(`清空时间线(共 ${S.st.timeline.length} 段)?不影响已生成的片段文件`, "清空", { type: "warning" }); }
      catch { return; }
      stopAll();
      S.st.timeline = [];
      monReset();
    }
    function stMark(i, which) {
      const t = S.st.timeline[i];
      if (!t || !t.duration) { ElMessage.warning("片段时长未就绪"); return; }
      let ph = (S.st.mon.name === t.name && monRef.value && isFinite(monRef.value.currentTime) && monRef.value.currentTime > 0)
        ? monRef.value.currentTime : (S.st.ph[t.name] ?? t.start ?? 0);
      ph = Math.max(0, Math.min(ph, t.duration));
      if (which === "in") t.start = Math.min(ph, (t.end ?? t.duration) - 0.2);
      else t.end = Math.max((t.start || 0) + 0.2, ph);
      S.st.ph[t.name] = ph;
      ElMessage.success(`${which === "in" ? "入点" : "出点"}已打在 ${ph.toFixed(1)}s`);
    }
    function focusSeg(i) {
      stopSeq();
      const t = S.st.timeline[i];
      if (!t) return;
      setMon(i, t.start || 0, false);
      nextTick(() => {
        const card = clipsRef.value && clipsRef.value.querySelector(`.clip-card[data-name="${CSS.escape(t.name)}"]`);
        if (card) {
          card.scrollIntoView({ behavior: "smooth", block: "nearest" });
          card.classList.add("flash");
          setTimeout(() => card.classList.remove("flash"), 900);
        }
      });
    }
    function onMonSeek(payload) {
      if (payload.seekOnly && S.st.mon.name === S.st.timeline[payload.i]?.name) {
        try { monRef.value.currentTime = payload.time; } catch (e) {}
      } else setMon(payload.i, payload.time, payload.play);
    }
    // ---- 生成 ----
    function togglePreset(setObj, label, text) { setObj.has(label) ? setObj.delete(label) : setObj.add(label); }
    function buildGenPrompt() {
      const ss = ST_STYLES.filter(([label]) => styles.value.has(label)).map(([, text]) => text);
      const sh = ST_SHOTS.filter(([label]) => shots.value.has(label)).map(([, text]) => text);
      const parts = [];
      if (ss.length) parts.push(ss.join(";"));
      if (prompt.value.trim()) parts.push(prompt.value.trim());
      if (sh.length) parts.push(sh.join(";"));
      return parts.join("。");
    }
    async function generate() {
      if (S.st.genBusy) return;
      if (!S.apiUrl || !S.model) { ElMessage.warning("请先在「💬 对话」页选择数据来源与模型"); return; }
      const p = buildGenPrompt();
      if (!p) { ElMessage.warning("请描述这一幕的内容,或选择风格/镜头预设"); return; }
      S.st.genBusy = true;
      genStatus.value = "生成中…视频任务可能需要几分钟,可先剪辑已有片段";
      try {
        const resp = await fetch("/api/chat", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            api_url: S.apiUrl, api_key: S.apiKey, protocol: S.protocol,
            task_type: "video", model: S.model, message: p, history: [],
            video_duration: genForm.dur, video_resolution: genForm.res,
            video_ratio: genForm.ratio, video_api: genForm.api,
            system_prompt: S.systemPrompt || "", params: S.params || {},
          }),
        });
        if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${(await resp.text()).slice(0, 200)}`);
        const d = await resp.json();
        if (!d.media_url) throw new Error(d.media_error || "未取回媒体:" + (d.url || "").slice(0, 120));
        ElMessage.success(`✅ 片段已生成(${(d.latency_s || 0).toFixed(1)}s),已加入时间线`);
        await loadLib();
        addToTimeline({ name: d.media_name, url: d.media_url }, false);
      } catch (e) {
        ElMessage.error("生成失败: " + e.message);
      } finally {
        S.st.genBusy = false;
        genStatus.value = "";
      }
    }
    // ---- 合成 ----
    async function compose() {
      if (S.st.composing) return;
      if (!S.st.timeline.length) { ElMessage.warning("时间线为空"); return; }
      if (!ready.value) { ElMessage.warning("有片段起止时间未就绪/无效"); return; }
      S.st.composing = true;
      composeStatus.value = "合成中(逐段裁剪转码后拼接,取决于片段时长)…";
      try {
        const resp = await fetch("/api/studio/compose", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: composeForm.title.trim(), fade: composeForm.fade, resolution: composeForm.res,
            clips: S.st.timeline.map(t => ({ name: t.name, start: t.start, end: t.end })),
          }),
        });
        const d = await resp.json();
        if (!resp.ok) throw new Error(d.detail || `HTTP ${resp.status}`);
        resultCard.value = true;
        result.url = d.url;
        result.name = d.name;
        result.info = `${d.name} · ${d.duration}s · ${fmtSize(d.size)}`;
        ElMessage.success(`🎉 动漫成片已合成:${d.duration}s`);
        await loadLib();
      } catch (e) {
        ElMessage.error("合成失败: " + e.message);
      } finally {
        S.st.composing = false;
        composeStatus.value = "";
      }
    }

    const modelInfo = computed(() => (S.apiUrl && S.model)
      ? `当前来源:${S.srcName || "自定义"} · ${S.model}`
      : "未选数据源(到「💬 对话」页选择后回来)");

    return {
      S, ST_STYLES, ST_SHOTS, SEQ_COLORS, DUR_OPTS,
      monRef, clipsRef, genStatus, composeStatus, resultCard, result, monTime, monDur, playing,
      prompt, styles, shots, genForm, composeForm, seqPhPct,
      seqTotal, ready, animeCount, clipCount, monName, monOut, seqTicks, modelInfo, monClip,
      loadLib, deleteMedia, addToTimeline, inTl,
      tlMove, tlRemove, clearTl, stMark, focusSeg, onMonSeek, setMon, stopSeq, stopAll, togglePlay,
      togglePreset, generate, compose, stTc, fmtSize, fmtAttBytes,
    };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>🎞 动漫工坊</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">片段生成 → 右侧片段库 → 时间线剪辑 → 合成动漫成片</span>
      <span class="grow"></span>
      <span style="font-size:11.5px;color:var(--el-text-color-secondary);">{{ modelInfo }}</span>
    </div>
    <div class="stat-cards">
      <div class="stat-card"><div class="k">🎬 片段数</div><div class="v">{{ clipCount }}</div></div>
      <div class="stat-card"><div class="k">🎞 时间线</div><div class="v">{{ S.st.timeline.length }} 段</div></div>
      <div class="stat-card"><div class="k">⏱ 时间线时长</div><div class="v">{{ seqTotal.toFixed(1) }}s</div></div>
      <div class="stat-card"><div class="k">🎉 已成片</div><div class="v">{{ animeCount }}</div></div>
    </div>

    <div class="studio-grid-v2">
      <div class="studio-main">
        <el-card shadow="never">
          <template #header><b>🎬 生成动漫片段</b><span style="font-size:11px;color:var(--el-text-color-secondary);margin-left:8px;">(使用对话页选中的数据源与模型)</span></template>
          <el-input v-model="prompt" type="textarea" :rows="3"
            placeholder="描述这一幕:角色 / 场景 / 动作 / 氛围…(先选风格与镜头预设更专业)"/>
          <div style="margin-top:8px;font-size:11px;color:var(--el-text-color-secondary);">🎨 动漫风格(可多选)</div>
          <div class="preset-row">
            <span v-for="[label, text] in ST_STYLES" :key="label" class="preset-chip"
              :class="{ on: styles.has(label) }" :title="text" @click="togglePreset(styles, label)">{{ label }}</span>
          </div>
          <div style="margin-top:6px;font-size:11px;color:var(--el-text-color-secondary);">🎥 镜头语言(可多选)</div>
          <div class="preset-row">
            <span v-for="[label, text] in ST_SHOTS" :key="label" class="preset-chip"
              :class="{ on: shots.has(label) }" :title="text" @click="togglePreset(shots, label)">{{ label }}</span>
          </div>
          <div class="param-row">
            <span class="pl">⏱ 时长</span>
            <el-select v-model="genForm.dur" size="small" style="width:74px;">
              <el-option v-for="d in DUR_OPTS" :key="d" :value="d" :label="d + 's'"/>
            </el-select>
            <span class="pl">🖥 分辨率</span>
            <el-select v-model="genForm.res" size="small" style="width:88px;">
              <el-option value="480P"/><el-option value="768P"/><el-option value="2K"/>
            </el-select>
            <span class="pl">📐 比例</span>
            <el-select v-model="genForm.ratio" size="small" style="width:92px;">
              <el-option v-for="r in ['16:9','9:16','1:1','4:3','3:4','21:9']" :key="r" :value="r"/>
              <el-option value="adaptive" label="自适应"/>
            </el-select>
            <span class="pl">🔌 接口</span>
            <el-select v-model="genForm.api" size="small" style="width:104px;">
              <el-option value="auto" label="自动"/><el-option value="v2" label="MiniMax V2"/><el-option value="v1" label="V1 云"/>
            </el-select>
          </div>
          <div style="display:flex;align-items:center;gap:10px;margin-top:10px;">
            <el-button type="primary" :loading="S.st.genBusy" @click="generate">生成本片段</el-button>
            <span style="font-size:11.5px;color:var(--el-text-color-secondary);">{{ genStatus }}</span>
          </div>
        </el-card>

        <el-card shadow="never">
          <template #header>
            <b>🎞 剪辑台</b>
            <span style="font-size:11px;color:var(--el-text-color-secondary);margin-left:8px;">点击胶片时间轴任意位置 → 监视器播放预览 · 拖两端手柄裁剪</span>
          </template>
          <div class="bay-top">
            <div class="mon">
              <div class="mon-head">📺 预览监视器<span class="grow"></span><span class="st-chip">{{ monName }}</span></div>
              <div class="mon-body">
                <video ref="monRef" muted playsinline preload="metadata"/>
                <div class="mon-badge" v-show="S.st.mon.seq">🔗 序列预览 {{ S.st.mon.seqIdx + 1 }}/{{ S.st.timeline.length }}</div>
              </div>
              <div class="mon-ops">
                <span class="tc mono">{{ stTc(monTime) }} / {{ stTc(monOut) }}</span>
                <span class="grow"></span>
                <button class="mbtn" title="跳到本段入点" @click="monClip && ((monRef.currentTime = monClip.start || 0), (S.st.ph[monClip.name] = monClip.start || 0))">⏮ 入点</button>
                <button class="mbtn" @click="togglePlay">{{ playing ? '⏸ 暂停' : '▶ 播放' }}</button>
                <button class="mbtn" title="跳到本段出点" @click="monClip && ((monRef.currentTime = Math.max((monClip.start || 0) + 0.1, (monClip.end ?? monClip.duration ?? 0) - 0.05)), (S.st.ph[monClip.name] = monClip.end || 0))">⏭ 出点</button>
                <button class="mbtn stop" @click="stopAll">⏹ 停止</button>
              </div>
            </div>
            <div class="bay-side">
              <div class="side-title">⏱ 序列与操作</div>
              <div class="side-info">
                从右侧片段库「＋ 加入」,或生成新片段自动加入。<br>
                · 点击片段胶片轴上的任意时间点,监视器播放小段预览动画<br>
                · 拖动胶片轴两端手柄调整入点/出点,点时间点后「⏮ 入点」「⏭ 出点」精确打点<br>
                · 「▶ 整线预览」按时间线顺序连播全部片段
              </div>
              <div class="side-ops">
                <el-button type="primary" size="small" @click="playSeq">▶ 整线预览</el-button>
                <el-button size="small" @click="stopSeq">⏹ 停止</el-button>
                <el-button size="small" type="danger" plain @click="clearTl">清空</el-button>
              </div>
              <div style="margin-top:9px;">
                <span class="st-chip">{{ S.st.timeline.length ? S.st.timeline.length + ' 段 · 成片约 ' + seqTotal.toFixed(1) + 's' : '尚未加入片段' }}</span>
              </div>
            </div>
          </div>
          <!-- 序列时间轴标尺 -->
          <div class="seq">
            <template v-if="S.st.timeline.length && seqTotal > 0.05">
              <div class="seq-ticks">
                <template v-for="tk in seqTicks" :key="tk.s">
                  <i :style="{ left: tk.p + '%' }"></i><span :style="{ left: tk.p + '%' }">{{ tk.s }}s</span>
                </template>
              </div>
              <div class="seq-bar">
                <div v-for="(t, i) in S.st.timeline" :key="t.name" class="seq-seg"
                  :style="{ flexGrow: Math.max(0.1, (t.end ?? 0) - (t.start || 0)), background: SEQ_COLORS[i % SEQ_COLORS.length] }"
                  :title="t.name + ' · 选用 ' + Math.max(0, (t.end ?? 0) - (t.start || 0)).toFixed(1) + 's'"
                  @click="focusSeg(i)">#{{ i + 1 }} {{ Math.max(0, (t.end ?? 0) - (t.start || 0)).toFixed(1) }}s</div>
                <div class="seq-ph" :style="{ left: seqPhPct + '%' }"></div>
              </div>
            </template>
            <div v-else style="font-size:10.5px;color:var(--el-text-color-secondary);padding:1px 0;">
              序列时间轴:加入片段后在此显示整线排布与秒刻度,点击色块可定位到对应片段
            </div>
          </div>
          <!-- 片段卡列表 -->
          <div ref="clipsRef" class="clips">
            <el-empty v-if="!S.st.timeline.length" description="时间线为空:点右侧片段库「＋ 加入」,或直接生成新片段(自动加入)"
              :image-size="60"/>
            <ClipCard v-for="(t, i) in S.st.timeline" :key="t.name" :t="t" :i="i"
              @mark="stMark" @move="tlMove" @remove="tlRemove" @play-clip="i => { stopSeq(); setMon(i, S.st.timeline[i].start || 0, true); }"
              @mon-seek="onMonSeek" @stop-seq="stopSeq"/>
          </div>
          <!-- 合成栏 -->
          <div class="param-row" style="margin-top:10px;">
            <span class="pl">📦 导出</span>
            <el-select v-model="composeForm.res" size="small" style="width:120px;">
              <el-option value="orig" label="跟随第一段"/><el-option value="720p" label="720P"/>
              <el-option value="1080p" label="1080P"/><el-option value="480p" label="480P"/>
            </el-select>
            <el-checkbox v-model="composeForm.fade" label="首尾淡入淡出" size="small"/>
            <span class="pl">📝 成片名</span>
            <el-input v-model="composeForm.title" size="small" placeholder="我的动漫(可选)" style="width:140px;"/>
          </div>
          <div style="display:flex;align-items:center;gap:10px;margin-top:10px;">
            <el-button type="primary" :disabled="!ready" :loading="S.st.composing" @click="compose">合成动漫</el-button>
            <span style="font-size:11.5px;color:var(--el-text-color-secondary);">
              {{ S.st.timeline.length ? S.st.timeline.length + ' 段 · 合计 ' + seqTotal.toFixed(1) + 's' : '' }} {{ composeStatus }}</span>
          </div>
        </el-card>

        <el-card v-if="resultCard" shadow="never">
          <template #header><b>🎉 成片</b></template>
          <video :src="result.url" controls playsinline style="width:100%;max-height:360px;border-radius:12px;background:#000;"/>
          <div style="margin-top:8px;display:flex;gap:8px;align-items:center;">
            <a class="el-button el-button--primary" :href="result.url + '?download=1'" :download="result.name">下载成片</a>
            <span style="font-size:11px;color:var(--el-text-color-secondary);">{{ result.info }}</span>
          </div>
        </el-card>
      </div>

      <!-- 片段库 -->
      <el-card shadow="never" class="studio-lib">
        <template #header>
          <b>📚 片段库</b>
          <span class="grow"></span>
          <el-button size="small" @click="loadLib()"><el-icon style="margin-right:4px;"><Refresh/></el-icon>刷新</el-button>
        </template>
        <el-empty v-if="!S.st.lib.length" description="还没有已生成的视频;生成后会出现在这里" :image-size="60"/>
        <div class="lib-item" v-for="item in S.st.lib" :key="item.name">
          <video :src="item.url" muted playsinline preload="metadata"/>
          <div class="meta">
            <div class="nm" :title="item.name">{{ item.name.startsWith('anime_') ? '🎉 ' : '' }}{{ item.name }}</div>
            <div class="sub">{{ fmtSize(item.size) }} · {{ item.mtime }}</div>
          </div>
          <el-button size="small" :type="inTl(item.name) ? '' : 'primary'" :disabled="inTl(item.name)" plain
            style="flex:none;" @click="addToTimeline(item)">{{ inTl(item.name) ? '已加入' : '＋ 加入' }}</el-button>
          <button class="lib-del" title="删除此文件(服务端文件一并删除,不可恢复)" @click="deleteMedia(item)"><el-icon><Delete/></el-icon></button>
        </div>
      </el-card>
    </div>
  </div>`,
};
