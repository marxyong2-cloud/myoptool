// ============================== ModelUse 全局状态与动作 ==============================
import { reactive, computed } from "vue";
import { api } from "./api.js";
import { lsKey } from "./auth.js";

export const S = reactive({
  view: "chat",                       // chat|channels|keys|logs|prompts|skills|studio|docs
  task: "chat", visionHint: false,
  sessions: [], sid: null, history: [],
  sourceId: "custom", srcName: "",
  apiUrl: "", apiKey: "", protocol: "openai",
  models: [], model: "",
  sending: false, abort: null, attachments: [],
  systemPrompt: "", params: {},
  channels: [], keys: [], logs: [], stats: {},
  skills: [], prompts: [],
  selectMode: false, selSet: new Set(),
  mergeMode: false, mergeSet: new Set(),
  archOpen: false, sessSearch: "",
  // 视频子参数(localStorage 记忆)
  vDur: +(localStorage.getItem("mu-vdur") || 5),
  vRes: localStorage.getItem("mu-vres") || "768P",
  vRatio: localStorage.getItem("mu-vratio") || "16:9",
  vApi: localStorage.getItem("mu-vapi") || "auto",
  ttsVoice: localStorage.getItem("mu-voice") || "alloy",
  ttsFmt: localStorage.getItem("mu-ttsfmt") || "mp3",
  // 动漫工坊
  st: { lib: [], timeline: [], frames: {}, ph: {}, genBusy: false, composing: false,
        mon: { name: null, url: null, want: null, seq: false, seqIdx: 0 } },
});
window.S = S;   // 调试/自动化测试可访

export const TASK_NAMES = {
  chat: "文本对话", image: "文生图", video: "文生视频", image_video: "图生视频",
  tts: "语音合成", stt: "语音识别",
};
export const showStudioNav = () => ["video", "image_video"].includes(S.task);

// ---------- 本地配置 ----------
export function loadLocalCfg() {
  try {
    const c = JSON.parse(localStorage.getItem(lsKey("mu-cfg")) || "{}");
    if (c.apiUrl) S.apiUrl = c.apiUrl;
    if (c.apiKey !== undefined) S.apiKey = c.apiKey;
    if (c.protocol) S.protocol = c.protocol;
    if (Array.isArray(c.models)) S.models = c.models;
    if (c.model) S.model = c.model;
    let t = c.task;
    if (!["chat", "image", "video", "image_video", "tts", "stt"].includes(t)) t = "chat";
    S.task = t;
  } catch {}
}
export function saveLocalCfg() {
  localStorage.setItem(lsKey("mu-cfg"), JSON.stringify({
    apiUrl: S.apiUrl, apiKey: S.apiKey, protocol: S.protocol,
    models: S.models, model: S.model, task: S.task,
  }));
}
export function saveVideoPrefs() {
  localStorage.setItem("mu-vdur", S.vDur);
  localStorage.setItem("mu-vres", S.vRes);
  localStorage.setItem("mu-vratio", S.vRatio);
  localStorage.setItem("mu-vapi", S.vApi);
  localStorage.setItem("mu-voice", S.ttsVoice);
  localStorage.setItem("mu-ttsfmt", S.ttsFmt);
}

// ---------- 数据源 ----------
export function applySource() {
  if (S.sourceId !== "custom") {
    const ch = S.channels.find(c => c.id === S.sourceId);
    if (ch) {
      S.apiUrl = ch.base_url; S.apiKey = ch.api_key || "";
      S.protocol = ch.protocol || "openai"; S.models = ch.models || [];
      if (!S.models.includes(S.model)) S.model = S.models[0] || "";
      S.srcName = ch.name;
    }
  } else {
    S.srcName = "自定义 API" + (S.apiUrl ? "" : "(点击配置)");
  }
  saveLocalCfg();
}
export const ctxLabel = computed(() => {
  let t = TASK_NAMES[S.task] || S.task;
  if (S.task === "chat" && S.visionHint) t = "看图理解";
  return S.model ? `${t} · ${S.model}` : "请选择数据来源与模型";
});

// ---------- 会话 ----------
export async function loadSessions() {
  try { S.sessions = await api("/api/chat/sessions"); } catch { S.sessions = []; }
  const active = S.sessions.filter(s => !s.archived);
  if (!active.length) { await newSession(true); return; }
  const target = (S.sid && active.find(s => s.id === S.sid)) ? S.sid : active[active.length - 1].id;
  switchSession(target, true);
}
export function switchSession(id, silent) {
  if (S.sending && !silent) return false;
  const s = S.sessions.find(x => x.id === id);
  if (!s) return false;
  S.sid = id;
  S.history = s.messages || [];
  S.systemPrompt = s.system_prompt || "";
  S.params = s.params || {};
  if (s.data_source) S.sourceId = s.data_source;
  if (s.model) S.model = s.model;
  applySource();
  return true;
}
export async function newSession(silent) {
  const s = await api("/api/chat/sessions", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: "新对话 " + new Date().toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }) }),
  });
  S.sessions.push(s);
  S.sid = s.id; S.history = []; S.systemPrompt = ""; S.params = {};
  if (!silent) S.view = "chat";
  return s;
}
export async function saveSession() {
  const s = S.sessions.find(x => x.id === S.sid);
  if (!s) return;
  if (!s._titled) {
    const fu = S.history.find(m => m.role === "user");
    if (fu && (fu.content || "").trim()) {
      s.title = fu.content.replace(/@[\w\u4e00-\u9fa5-]+/g, "").trim().slice(0, 20) || s.title;
      s._titled = true;
    }
  }
  s.messages = S.history;
  s.system_prompt = S.systemPrompt;
  s.params = S.params;
  s.data_source = S.sourceId;
  s.model = S.model;
  try {
    await api("/api/chat/sessions/" + S.sid, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: s.title || "会话", archived: false, messages: S.history, project: "",
        system_prompt: S.systemPrompt, params: S.params, data_source: S.sourceId, model: S.model,
      }),
    });
  } catch (e) { console.error("会话保存失败", e); }
}

// ---------- 网关 / 日志 / 库 ----------
export async function loadGw() {
  try {
    const cfg = await api("/api/gateway/config");
    S.channels = cfg.channels || []; S.keys = cfg.keys || []; S.stats = cfg.stats || {};
    applySource();
  } catch (e) { console.error(e); }
}
export async function loadLogs() {
  try {
    const [logs, stats] = await Promise.all([api("/api/gateway/logs"), api("/api/gateway/stats")]);
    S.logs = logs; S.stats = stats;
  } catch {}
}
export async function loadLib() {
  try {
    const [skills, prompts] = await Promise.all([api("/api/modeluse/skills"), api("/api/modeluse/prompts")]);
    S.skills = skills; S.prompts = prompts;
  } catch (e) { console.error(e); }
}

// ---------- 技能展开 ----------
export function expandSkills(text) {
  return String(text || "").replace(/@([A-Za-z0-9_\u4e00-\u9fa5-]+)/g, (m, name) => {
    const sk = S.skills.find(s => s.name === name);
    if (!sk) return m;
    return `<skill name="${sk.name}">\n${sk.content}\n</skill>`;
  });
}
