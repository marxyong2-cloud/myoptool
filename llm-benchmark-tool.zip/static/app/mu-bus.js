// ============================== 视图间轻量通信 ==============================
// 其他视图(技能/提示词库)请求向对话输入框插入文本
let pendingText = "";
export function insertTextGlobal(text) { pendingText += text; }
export function takePendingText() {
  const t = pendingText;
  pendingText = "";
  return t;
}
