// ============================== 模型部署站视图:容器总览 / 预设命令 / 任务编排 ==============================
import { reactive, ref, computed, watch, nextTick, onMounted } from "vue";
import { isViewer } from "./auth.js";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  MS, detect, pickContainer, loadFiles, enterDir, goUp, runExec, validateCmd,
  containerOp, openContainerLogs, loadContainerLogs,
  loadPresets, savePresets, uploadPresetFile, runPresetOnce,
  loadPlans, savePlans, runPlan, cancelRun, pauseRun, resumeRun, closeRun, fmtSize,
  loadHistory, openHistory, openHistoryRun, clearHistory,
  hostGroups, ungroupedHosts, isRiskyCmd, hostById,
  copyText, fmtAge, fmtTime, fmtMem,
} from "./ms-store.js";

const FORM_LABEL = { command: "命令", script: "脚本", upload: "上传文件", yaml: "K8s YAML" };
const LANG_LABEL = { shell: "Shell", bash: "Bash", python: "Python", node: "Node", perl: "Perl", ruby: "Ruby" };

// 运行 / 步骤状态 → 标签类型与文案(方案运行面板与执行历史面板共用)
const runTag = (s) => ({ running: "primary", done: "success", failed: "danger", cancelled: "warning", partial: "warning" }[s] || "info");
const runText = (s) => ({ running: "运行中", done: "已完成", failed: "失败中止", cancelled: "已取消", pending: "等待",
                          partial: "部分成功", ok: "成功", fail: "失败", skipped: "已跳过" }[s] || s);
const stepTag = (s) => ({ pending: "info", running: "primary", ok: "success", fail: "danger", skipped: "info", partial: "warning" }[s] || "info");

// ---------- 视图 1:容器总览(检测 + 文件浏览 + 命令执行 + 容器详情) ----------
export const ContainersView = {
  setup() {
    const kw = ref("");
    const runtime = ref("docker");
    const execErr = computed(() => validateCmd(MS.exec.command));
    const list = computed(() => {
      const q = (kw.value || "").trim().toLowerCase();
      if (runtime.value === "k8s") {
        return MS.detected.pods.filter(p => !q || p.name.toLowerCase().includes(q)
          || p.namespace.toLowerCase().includes(q) || (p.images || []).join(" ").toLowerCase().includes(q));
      }
      return MS.detected.containers.filter(c => !q || c.name.toLowerCase().includes(q)
        || (c.image || "").toLowerCase().includes(q) || (c.run_cmd || "").toLowerCase().includes(q));
    });
    function setRuntime(r) {
      runtime.value = r;
      if (MS.cur.runtime !== r) { MS.cur = { runtime: r, container: "", namespace: "" }; MS.files = { path: "", entries: [], loading: false, raw: "" }; }
    }
    function openTerm() {
      MS.term.host = MS.activeHost;
      MS.term.runtime = MS.cur.runtime;
      MS.term.container = MS.cur.container;
      MS.term.namespace = MS.cur.namespace;
      MS.term.open = true;
      MS.term.connectReq = (MS.term.connectReq || 0) + 1;
    }
    const phaseCls = (p) => ({ Running: "on", Completed: "", Succeeded: "", Pending: "p", Failed: "off", CrashLoopBackOff: "off", Error: "off" }[p] || "p");
    const stateCls = (s) => (s === "running" ? "on" : s === "exited" ? "off" : "p");
    // 页头统计胶囊:运行 / 停止 / 总数
    const stats = computed(() => {
      if (runtime.value === "k8s") {
        const pods = MS.detected.pods;
        const run = pods.filter(p => p.phase === "Running").length;
        return { run, stop: pods.length - run, total: pods.length };
      }
      const cs = MS.detected.containers;
      const run = cs.filter(c => c.state === "running").length;
      return { run, stop: cs.length - run, total: cs.length };
    });
    // 当前选中容器是否在运行(决定启停按钮可用性)
    const curRunning = computed(() => {
      if (MS.cur.runtime === "k8s") return true;
      const c = MS.detected.containers.find(x => x.name === MS.cur.container);
      return !!c && c.state === "running";
    });
    // 当前选中容器 / Pod 的完整对象(detect 返回的详细信息,详情面板数据源)
    const curObj = computed(() => {
      if (!MS.cur.container) return null;
      if (MS.cur.runtime === "k8s") {
        return MS.detected.pods.find(p => p.name === MS.cur.container
          && (p.namespace || "") === (MS.cur.namespace || "")) || null;
      }
      return MS.detected.containers.find(c => c.name === MS.cur.container) || null;
    });
    const dCmd = (c) => ((c.entrypoint || []).concat(c.cmd || []).join(" ") || c.command || "");
    const ctCmd = (ct) => [(ct.command || []).join(" "), (ct.args || []).join(" ")].filter(Boolean).join(" ");
    // 创建命令 / 创建 YAML 折叠态:默认收起,切换容器后重新收起
    const showCmd = ref(false);
    const showYaml = ref(false);
    watch(() => [MS.cur.runtime, MS.cur.container, MS.cur.namespace].join("|"), () => { showCmd.value = false; showYaml.value = false; });
    return { MS, kw, runtime, list, setRuntime, execErr, stats, curRunning,
             detect, pickContainer, loadFiles, enterDir, goUp, runExec, fmtSize, openTerm, phaseCls, stateCls,
             containerOp, openContainerLogs, loadContainerLogs,
             curObj, dCmd, ctCmd, copyText, fmtAge, fmtTime, fmtMem, showCmd, showYaml, RO: isViewer() };
  },
  template: `
  <div class="ms-containers">
    <div class="ms-toolbar">
      <div class="ix-seg">
        <button :class="{ on: runtime === 'docker' }" @click="setRuntime('docker')">🐳 Docker</button>
        <button :class="{ on: runtime === 'k8s' }" @click="setRuntime('k8s')">☸️ K8s Pod</button>
      </div>
      <template v-if="list.length || MS.detected.containers.length || MS.detected.pods.length">
        <span class="ms-stat-chip"><i class="dot on"></i>运行 {{ stats.run }}</span>
        <span class="ms-stat-chip"><i class="dot off"></i>停止 {{ stats.stop }}</span>
        <span class="ms-stat-chip">共 {{ stats.total }}</span>
      </template>
      <span class="ix-note-inline" v-if="runtime === 'docker' && MS.detected.docker_error">{{ MS.detected.docker_error }}</span>
      <span class="ix-note-inline" v-if="runtime === 'k8s' && MS.detected.k8s_error">{{ MS.detected.k8s_error }}</span>
      <span class="grow"></span>
      <el-input v-model="kw" clearable placeholder="按名称 / 镜像 / 命令过滤…" style="width:210px;"/>
      <el-button v-if="!RO" :loading="MS.detecting" @click="detect()"><el-icon><Refresh/></el-icon>重新检测</el-button>
    </div>

    <div class="ms-ctable">
      <div v-if="runtime === 'docker'" class="ms-ctable-head rt-docker">
        <span class="c-st">状态</span><span class="c-nm">名称</span>
        <span class="c-im">镜像</span><span class="c-cmd">命令</span>
        <span class="c-pt">端口</span><span class="c-age">创建 / 时长</span>
      </div>
      <div v-if="runtime === 'docker'" v-for="c in list" :key="c.id + c.name" class="ms-ctable-row rt-docker"
           :class="{ on: MS.cur.container === c.name }" @click="pickContainer('docker', c.name, '')">
        <span class="c-st"><i class="dot" :class="stateCls(c.state)"></i>{{ c.state }}</span>
        <span class="c-nm mono" :title="'ID ' + c.id">{{ c.name }}</span>
        <span class="c-im mono" :title="c.image">{{ c.image }}</span>
        <span class="c-cmd mono" :title="c.command || dCmd(c)">{{ c.command || dCmd(c) }}</span>
        <span class="c-pt mono" :title="c.ports">{{ (c.ports || '').slice(0, 40) }}</span>
        <span class="c-age" :title="c.created_at">{{ c.running_for || c.created_at }}</span>
      </div>
      <div v-if="runtime === 'k8s'" class="ms-ctable-head rt-k8s">
        <span class="c-st">状态</span><span class="c-nm">名称</span>
        <span class="c-im">命名空间 / 节点</span>
        <span class="c-cmd">容器镜像</span>
        <span class="c-pt">Ready / 重启 / IP</span>
        <span class="c-age">时长</span>
      </div>
      <div v-if="runtime === 'k8s'" v-for="p in list" :key="p.namespace + '/' + p.name" class="ms-ctable-row rt-k8s"
           :class="{ on: MS.cur.container === p.name }" @click="pickContainer('k8s', p.name, p.namespace)">
        <span class="c-st"><i class="dot" :class="phaseCls(p.phase)"></i>{{ p.phase }}</span>
        <span class="c-nm mono" :title="p.owner || p.name">{{ p.name }}</span>
        <span class="c-im mono">{{ p.namespace }} / {{ p.node }}</span>
        <span class="c-cmd mono" :title="(p.images || []).join('\\n')">{{ (p.images || []).join(' · ') }}</span>
        <span class="c-pt">ready {{ p.ready }} · 重启 {{ p.restarts }}<template v-if="p.pod_ip"> · {{ p.pod_ip }}</template></span>
        <span class="c-age" :title="p.created">{{ fmtAge(p.created) }}</span>
      </div>
      <div v-if="!list.length" class="ms-empty">
        {{ MS.detecting ? "检测中…" : (!MS.activeHost ? "先在左侧选择 SSH 主机,自动检测容器" : (kw ? "无匹配条目" : "未检测到条目")) }}</div>
    </div>

    <div v-if="MS.cur.container" class="ms-detail">
      <div class="ms-detail-head">
        <b class="mono">📦 {{ MS.cur.container }}</b>
        <span class="ix-note-inline">{{ MS.cur.runtime === 'k8s' ? 'K8s · ' + (MS.cur.namespace || 'default') : 'Docker' }}</span>
        <span class="grow"></span>
        <template v-if="!RO && MS.cur.runtime === 'docker'">
          <el-button size="small" :loading="MS.cop.running && MS.cop.op === 'start'"
                     :disabled="MS.cop.running || curRunning" title="docker start"
                     @click="containerOp('start')"><el-icon><VideoPlay/></el-icon>启动</el-button>
          <el-button size="small" :loading="MS.cop.running && MS.cop.op === 'stop'"
                     :disabled="MS.cop.running || !curRunning" title="docker stop"
                     @click="containerOp('stop')"><el-icon><VideoPause/></el-icon>停止</el-button>
          <el-button size="small" :loading="MS.cop.running && MS.cop.op === 'restart'"
                     :disabled="MS.cop.running || curRunning" title="docker restart"
                     @click="containerOp('restart')"><el-icon><Refresh/></el-icon>重启</el-button>
        </template>
        <el-button v-if="!RO" size="small" @click="openContainerLogs()" title="查看容器末尾日志"><el-icon><Files/></el-icon>日志</el-button>
        <el-button v-if="!RO" size="small" type="primary" plain @click="openTerm()">⌨ 登录终端</el-button>
      </div>

      <!-- 容器 / Pod 详情:detect 采集的完整信息 + 等价创建命令 -->
      <div v-if="curObj" class="ms-panel ms-info">
        <div class="ms-files-head">
          <b>🧾 {{ MS.cur.runtime === 'k8s' ? 'Pod 详情' : '容器详情' }}</b>
          <span class="ix-note-inline">{{ MS.cur.runtime === 'k8s' ? 'kubectl get pods -o json 解析' : 'docker inspect 解析' }}</span>
        </div>

        <template v-if="MS.cur.runtime === 'docker'">
          <div class="ms-kv-grid">
            <div class="ms-kv"><span class="k">容器 ID</span><span class="v mono">{{ curObj.id }}</span></div>
            <div class="ms-kv"><span class="k">状态</span><span class="v">{{ curObj.status }}<template v-if="curObj.health"> · 健康 {{ curObj.health }}</template></span></div>
            <div class="ms-kv"><span class="k">镜像</span><span class="v mono">{{ curObj.image }}</span></div>
            <div class="ms-kv"><span class="k">命令</span><span class="v mono">{{ dCmd(curObj) }}</span></div>
            <div class="ms-kv"><span class="k">创建时间</span><span class="v mono">{{ curObj.created_at }}</span></div>
            <div class="ms-kv"><span class="k">创建至今</span><span class="v">{{ curObj.running_for }}</span></div>
            <div class="ms-kv"><span class="k">网络</span><span class="v mono">{{ (curObj.networks || []).join(', ') || '—' }}</span></div>
            <div class="ms-kv"><span class="k">容器 IP</span><span class="v mono">{{ curObj.ip || '—' }}</span></div>
            <div class="ms-kv"><span class="k">端口映射</span><span class="v mono">{{ (curObj.port_maps || []).join('   ') || curObj.ports || '—' }}</span></div>
            <div class="ms-kv"><span class="k">重启策略</span><span class="v">{{ curObj.restart || 'no' }}<template v-if="curObj.auto_remove"> · --rm</template></span></div>
            <div class="ms-kv"><span class="k">工作目录</span><span class="v mono">{{ curObj.workdir || '/' }}</span></div>
            <div class="ms-kv"><span class="k">用户 / 主机名</span><span class="v mono">{{ curObj.user || 'root' }} / {{ curObj.hostname || '—' }}</span></div>
            <div class="ms-kv" v-if="curObj.gpus"><span class="k">GPU</span><span class="v mono">{{ curObj.gpus }}</span></div>
            <div class="ms-kv" v-if="curObj.shm"><span class="k">Shm 大小</span><span class="v mono">{{ curObj.shm }}</span></div>
            <div class="ms-kv" v-if="curObj.mem_limit"><span class="k">内存限制</span><span class="v mono">{{ fmtMem(curObj.mem_limit) }}</span></div>
            <div class="ms-kv" v-if="curObj.cpus"><span class="k">CPU 限制</span><span class="v mono">{{ curObj.cpus }}</span></div>
            <div class="ms-kv"><span class="k">特权模式</span><span class="v">{{ curObj.privileged ? '是' : '否' }}</span></div>
            <div class="ms-kv" v-if="curObj.exit_code != null && curObj.state !== 'running'"><span class="k">退出码</span><span class="v mono">{{ curObj.exit_code }}</span></div>
            <div class="ms-kv" v-if="(curObj.extra_hosts || []).length"><span class="k">额外 Hosts</span><span class="v mono">{{ curObj.extra_hosts.join('   ') }}</span></div>
          </div>
          <div class="ms-kv block" v-if="(curObj.mounts || []).length">
            <span class="k">挂载</span><span class="v mono">{{ curObj.mounts.join('\\n') }}</span>
          </div>
          <div class="ms-kv block" v-if="(curObj.env || []).length">
            <span class="k">环境变量</span><span class="v mono">{{ curObj.env.join('\\n') }}</span>
          </div>
          <div class="ms-kv block" v-if="(curObj.labels || []).length">
            <span class="k">标签</span><span class="v mono">{{ curObj.labels.join('\\n') }}</span>
          </div>
          <div class="ms-runcmd" v-if="curObj.run_cmd">
            <div class="ms-files-head ms-fold-head" @click="showCmd = !showCmd">
              <i class="arrow" :class="{ open: showCmd }">▸</i>
              <b>🛠 等价创建命令</b>
              <span class="ix-note-inline">由 docker inspect 重建 · 复制后可直接重建该容器</span>
              <span class="grow"></span>
              <el-button v-if="showCmd" size="small" @click.stop="copyText(curObj.run_cmd)">📋 复制</el-button>
            </div>
            <pre v-if="showCmd" class="ms-cmd-pre mono">{{ curObj.run_cmd }}</pre>
          </div>
          <div class="ix-note" v-else>未获取到创建命令(旧数据),点击上方「重新检测」刷新详细信息</div>
        </template>

        <template v-else>
          <div class="ms-kv-grid">
            <div class="ms-kv"><span class="k">命名空间</span><span class="v mono">{{ curObj.namespace }}</span></div>
            <div class="ms-kv"><span class="k">节点</span><span class="v mono">{{ curObj.node || '—' }}</span></div>
            <div class="ms-kv"><span class="k">Pod IP</span><span class="v mono">{{ curObj.pod_ip || '—' }}</span></div>
            <div class="ms-kv"><span class="k">主机 IP</span><span class="v mono">{{ curObj.host_ip || '—' }}</span></div>
            <div class="ms-kv"><span class="k">状态 / Ready</span><span class="v">{{ curObj.phase }} · ready {{ curObj.ready }}</span></div>
            <div class="ms-kv"><span class="k">重启次数</span><span class="v mono">{{ curObj.restarts }}</span></div>
            <div class="ms-kv"><span class="k">创建时间</span><span class="v mono">{{ fmtTime(curObj.created) }}</span></div>
            <div class="ms-kv"><span class="k">运行时长</span><span class="v">{{ fmtAge(curObj.created) }}</span></div>
            <div class="ms-kv" v-if="curObj.owner"><span class="k">归属</span><span class="v mono">{{ curObj.owner }}</span></div>
            <div class="ms-kv" v-if="curObj.qos"><span class="k">QoS</span><span class="v">{{ curObj.qos }}</span></div>
            <div class="ms-kv" v-if="curObj.service_account"><span class="k">ServiceAccount</span><span class="v mono">{{ curObj.service_account }}</span></div>
          </div>
          <div class="ms-ct-list">
            <div v-for="ct in curObj.containers" :key="ct.name" class="ms-ct-card">
              <div class="ms-ct-head">
                <i class="dot" :class="ct.ready ? 'on' : 'off'"></i><b class="mono">{{ ct.name }}</b>
                <span class="mono img">{{ ct.image }}</span>
                <span class="ms-mini-badge">重启 {{ ct.restarts }}</span>
              </div>
              <div class="ms-kv block" v-if="ctCmd(ct)"><span class="k">启动命令</span><span class="v mono">{{ ctCmd(ct) }}</span></div>
              <div class="ms-kv block" v-if="(ct.ports || []).length"><span class="k">端口</span><span class="v mono">{{ ct.ports.join('   ') }}</span></div>
              <div class="ms-kv block" v-if="(ct.resources || []).length"><span class="k">资源请求/限制</span><span class="v mono">{{ ct.resources.join('   ') }}</span></div>
              <div class="ms-kv block" v-if="(ct.env || []).length"><span class="k">环境变量</span><span class="v mono">{{ ct.env.join('\\n') }}</span></div>
              <div class="ms-kv block" v-if="(ct.mounts || []).length"><span class="k">挂载</span><span class="v mono">{{ ct.mounts.join('\\n') }}</span></div>
            </div>
            <div class="ms-kv block" v-if="curObj.init_containers && curObj.init_containers.length">
              <span class="k">Init 容器</span><span class="v mono">{{ curObj.init_containers.map(c => c.name + '(' + c.image + ')').join('\\n') }}</span>
            </div>
          </div>
          <div class="ms-runcmd" v-if="curObj.run_cmd">
            <div class="ms-files-head ms-fold-head" @click="showCmd = !showCmd">
              <i class="arrow" :class="{ open: showCmd }">▸</i>
              <b>🛠 等价创建命令</b>
              <span class="ix-note-inline">独立 Pod(kubectl run 等价)</span>
              <span class="grow"></span>
              <el-button v-if="showCmd" size="small" @click.stop="copyText(curObj.run_cmd)">📋 复制</el-button>
            </div>
            <pre v-if="showCmd" class="ms-cmd-pre mono">{{ curObj.run_cmd }}</pre>
          </div>
          <div class="ms-runcmd" v-if="curObj.create_yaml">
            <div class="ms-files-head ms-fold-head" @click="showYaml = !showYaml">
              <i class="arrow" :class="{ open: showYaml }">▸</i>
              <b>📜 等价创建 YAML</b>
              <span class="ix-note-inline">由 Pod spec 生成(简化)· kubectl apply -f 可重建</span>
              <span class="grow"></span>
              <el-button v-if="showYaml" size="small" @click.stop="copyText(curObj.create_yaml)">📋 复制</el-button>
            </div>
            <pre v-if="showYaml" class="ms-cmd-pre mono ms-yaml-pre">{{ curObj.create_yaml }}</pre>
          </div>
        </template>
      </div>

      <div v-if="!RO" class="ms-detail-grid">
        <div class="ms-panel">
          <div class="ms-files-head">
            <b class="mono">📂 {{ MS.files.path || "…" }}</b>
            <span class="grow"></span>
            <el-button size="small" @click="goUp()">⬆ 上级</el-button>
            <el-button size="small" :loading="MS.files.loading" @click="loadFiles()">🔄 刷新</el-button>
          </div>
          <div class="ms-list ms-files">
            <div v-for="e in MS.files.entries" :key="e.name" class="ms-row file" :class="{ dir: e.dir }"
                 :title="e.perms + ' · ' + e.owner" @click="e.dir && enterDir(e.name)">
              <span class="fi">{{ e.dir ? "📁" : "📄" }}</span>
              <span class="t">{{ e.name }}</span>
              <span class="sub">{{ e.owner }} · {{ fmtSize(e.size) }} · {{ e.mtime }}</span>
            </div>
            <div v-if="!MS.files.entries.length && !MS.files.loading" class="ms-empty">无文件(或目录不可读)</div>
          </div>
          <div v-if="MS.files.raw" class="ms-raw mono">{{ MS.files.raw }}</div>
        </div>

        <div class="ms-panel">
          <div class="ms-files-head">
            <b>⌨ 容器内命令执行</b>
            <span class="ix-note-inline">格式实时校验 · stderr 红色 · exit code 含义</span>
          </div>
          <div class="ix-row">
            <el-input v-model="MS.exec.command" class="mono" :class="{ 'ms-input-err': execErr && MS.exec.command }"
                      :disabled="MS.exec.running" placeholder="如 ls -la /workspace 或 python3 train.py --epochs 3"
                      @keydown.enter="runExec()"/>
            <el-button type="primary" :loading="MS.exec.running" style="flex:none;" @click="runExec()">执行</el-button>
          </div>
          <div v-if="MS.exec.command && execErr" class="ms-cmd-err">✗ {{ execErr }}(修正后再执行)</div>
          <div v-else-if="MS.exec.command" class="ms-cmd-ok">✓ 命令格式正确</div>
          <div v-if="MS.exec.lastCmd || MS.exec.out || MS.exec.err" class="ms-exec-out" :class="{ fail: MS.exec.rc }">
            <div class="cmd mono">$ {{ MS.exec.lastCmd }}</div>
            <pre v-if="MS.exec.out" class="out">{{ MS.exec.out }}</pre>
            <pre v-if="MS.exec.err" class="err">{{ MS.exec.err }}</pre>
            <div v-if="MS.exec.rc != null" class="status" :class="MS.exec.rc === 0 ? 'ok' : 'bad'">
              <template v-if="MS.exec.rc === 0">✓ exit 0 · {{ MS.exec.duration }}s</template>
              <template v-else>✗ exit {{ MS.exec.rc }} · {{ MS.exec.duration }}s<template v-if="MS.exec.hint"> ── {{ MS.exec.hint }}</template></template>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 容器日志查看:末尾 N 行,可调行数 / 刷新 -->
    <el-dialog v-model="MS.clogs.visible" :title="'📄 日志 · ' + MS.clogs.container" width="760px" top="6vh">
      <div class="ix-row" style="margin-bottom:8px;flex-wrap:wrap;">
        <span class="ix-note-inline mono" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ MS.clogs.cmd }}</span>
        <span class="grow"></span>
        <el-select v-model="MS.clogs.tail" size="small" style="width:120px;" @change="loadContainerLogs()">
          <el-option :value="100" label="末尾 100 行"/>
          <el-option :value="200" label="末尾 200 行"/>
          <el-option :value="500" label="末尾 500 行"/>
          <el-option :value="1000" label="末尾 1000 行"/>
        </el-select>
        <el-button size="small" :loading="MS.clogs.loading" @click="loadContainerLogs()">刷新</el-button>
      </div>
      <pre class="ms-clog-pre">{{ MS.clogs.loading ? "读取中…" : MS.clogs.text }}</pre>
    </el-dialog>
  </div>`,
};

// ---------- 视图 2:预设命令 v2(标签 / 语言 / 命令·脚本·上传) ----------
export const PresetsView = {
  setup() {
    const form = reactive({ id: "", name: "", kind: "host", lang: "shell", form: "command", content: "", filename: "", fileLabel: "", tags: [] });
    const fileRef = ref(null);
    const uploading = ref(false);
    const isYaml = computed(() => form.form === "yaml");
    // k8s YAML 固定在主机上 kubectl apply:切到 yaml 形式时自动切回主机执行
    watch(() => form.form, v => { if (v === "yaml") form.kind = "host"; });
    const allTags = computed(() => [...new Set(MS.presets.flatMap(p => p.tags || []))]);
    const filtered = computed(() => {
      const q = (MS.presetFilter.kw || "").trim().toLowerCase();
      const tag = MS.presetFilter.tag;
      return MS.presets.filter(p =>
        (!tag || (p.tags || []).includes(tag)) &&
        (!q || (p.name || "").toLowerCase().includes(q) || (p.content || "").toLowerCase().includes(q)));
    });
    function editPreset(p) {
      Object.assign(form, { id: p.id, name: p.name, kind: p.kind, lang: p.lang || "shell", form: p.form || "command", content: p.content || "", filename: p.filename || "", fileLabel: p.filename || "", tags: [...(p.tags || [])] });
    }
    function addPreset() {
      Object.assign(form, { id: "", name: "", kind: "host", lang: "shell", form: "command", content: "", filename: "", fileLabel: "", tags: [] });
    }
    function pickFile() { if (fileRef.value) fileRef.value.value = "", fileRef.value.click(); }
    async function onFile(e) {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      uploading.value = true;
      try {
        const d = await uploadPresetFile(f);
        form.filename = d.filename;
        form.fileLabel = `${d.name}(${fmtSize(d.size)})`;
        if (!form.name) form.name = d.name.replace(/\.[^.]+$/, "");
        ElMessage.success("脚本文件已上传");
      } catch (err) {
        ElMessage.error(err.message);
      }
      uploading.value = false;
    }
    async function savePreset() {
      if (!form.name.trim()) { ElMessage.warning("请填写预设名称"); return; }
      if (form.form !== "upload" && form.form !== "yaml" && !form.content.trim()) { ElMessage.warning("请填写命令 / 脚本内容"); return; }
      if (form.form === "upload" && !form.filename) { ElMessage.warning("请先上传脚本文件"); return; }
      if (form.form === "yaml" && !form.content.trim() && !form.filename) { ElMessage.warning("请粘贴 K8s YAML 内容,或上传 .yaml 文件"); return; }
      const item = { id: form.id, name: form.name.trim(), kind: form.kind, lang: form.lang, form: form.form,
                     content: form.content, filename: form.filename, tags: form.tags.filter(Boolean) };
      const prevIds = new Set(MS.presets.map(p => p.id));
      if (form.id) {
        const p = MS.presets.find(x => x.id === form.id);
        if (p) Object.assign(p, item);
      } else {
        MS.presets.push({ ...item, id: "" });
      }
      await savePresets();
      // 保存后停留在该预设,便于直接「试运行」
      const saved = form.id
        ? MS.presets.find(p => p.id === form.id)
        : MS.presets.find(p => !prevIds.has(p.id) && p.name === item.name);
      if (saved) editPreset(saved);
      ElMessage.success("预设已保存");
    }
    async function delPreset() {
      try { await ElMessageBox.confirm(`删除预设「${form.name}」?`, "删除", { type: "warning" }); } catch { return; }
      MS.presets = MS.presets.filter(x => x.id !== form.id);
      await savePresets();
      addPreset();
    }
    function tryRun() {
      if (!form.id) { ElMessage.warning("请先保存预设再试运行"); return; }
      MS.once.presetId = form.id;
      MS.once.hostId = MS.activeHost || (MS.hosts[0] || {}).id || "";
      MS.once.container = form.kind === "container" ? MS.cur.container : "";
      MS.once.namespace = "";
      MS.once.runtime = MS.cur.runtime;
      MS.once.visible = true;
      MS.once.cmd = ""; MS.once.out = ""; MS.once.err = ""; MS.once.rc = null;
    }
    const oncePreset = computed(() => MS.presets.find(p => p.id === MS.once.presetId) || {});
    const runnerHint = computed(() => form.lang === "python" ? "python3" : form.lang === "node" ? "node" : (form.lang === "bash" ? "bash" : "sh"));
    return { MS, form, fileRef, uploading, isYaml, oncePreset, allTags, filtered, editPreset, addPreset, pickFile, onFile, savePreset, delPreset, tryRun, runPresetOnce, fmtSize, FORM_LABEL, LANG_LABEL, runnerHint, RO: isViewer() };
  },
  template: `
  <div class="ms-cols ms-presets">
    <div class="ms-panel ms-preset-list">
      <div class="aside-head">
        <span class="aside-title">预设<em>({{ MS.presets.length }})</em></span>
        <span class="grow"></span>
        <el-button v-if="!RO" size="small" @click="addPreset()"><el-icon><Plus/></el-icon>新建</el-button>
      </div>
      <div class="ms-preset-filter">
        <el-input v-model="MS.presetFilter.kw" size="small" clearable placeholder="搜索名称 / 内容…"/>
        <div v-if="allTags.length" class="ms-tag-row">
          <button class="ms-tag" :class="{ on: !MS.presetFilter.tag }" @click="MS.presetFilter.tag = ''">全部</button>
          <button v-for="t in allTags" :key="t" class="ms-tag" :class="{ on: MS.presetFilter.tag === t }" @click="MS.presetFilter.tag = t">#{{ t }}</button>
        </div>
      </div>
      <div class="ms-list ms-preset-items">
        <div v-for="p in filtered" :key="p.id" class="ms-row preset" :class="{ on: form.id === p.id }" @click="editPreset(p)">
          <div class="t">{{ p.name }}
            <span class="ms-mini-badge">{{ p.form === 'yaml' ? '☸ K8s YAML · kubectl apply · 主机' : (FORM_LABEL[p.form] || p.form) + '·' + (LANG_LABEL[p.lang] || p.lang) + '·' + (p.kind === 'container' ? '容器' : '主机') }}</span>
          </div>
          <div class="sub mono">{{ (p.form === 'upload' || (p.form === 'yaml' && p.filename)) ? '📄 ' + (p.filename || '') : (p.content || '').split('\\n')[0].slice(0, 60) }}</div>
          <div class="ms-tag-row" v-if="p.tags && p.tags.length">
            <span v-for="t in p.tags" :key="t" class="ms-tag static">#{{ t }}</span>
          </div>
        </div>
        <div v-if="!filtered.length" class="ms-empty">无预设。支持 单条命令 / 完整脚本 / 上传脚本文件 / K8s YAML(kubectl apply) 四种形式</div>
      </div>
    </div>

    <div v-if="RO" class="ms-panel ms-editor" style="display:flex;align-items:center;justify-content:center;">
      <div class="ms-empty">👁 预览模式:仅可查看预设列表,不可新建 / 编辑 / 运行</div>
    </div>
    <div v-else class="ms-panel ms-editor">
      <div class="ms-files-head"><b>{{ form.id ? '编辑预设' : '新建预设' }}</b></div>
      <div class="ms-dlg-grid">
        <el-form-item label="名称"><el-input v-model="form.name" placeholder="如:拉起 vLLM 推理容器 / 清理旧容器"/></el-form-item>
        <el-form-item label="执行位置">
          <el-select v-model="form.kind" :disabled="isYaml" style="width:100%;"
                     :title="isYaml ? 'K8s YAML 固定在主机上执行 kubectl apply' : ''">
            <el-option value="host" label="🖥 主机上执行"/>
            <el-option value="container" label="📦 容器内执行" :disabled="isYaml"/>
          </el-select>
        </el-form-item>
      </div>
      <div class="ms-dlg-grid">
        <el-form-item label="语言">
          <el-select v-model="form.lang" :disabled="isYaml" style="width:100%;"
                     :title="isYaml ? 'K8s YAML 为资源清单,无需选择语言' : ''">
            <el-option v-for="(label, v) in LANG_LABEL" :key="v" :value="v" :label="label"/>
          </el-select>
        </el-form-item>
        <el-form-item label="形式">
          <el-select v-model="form.form" style="width:100%;">
            <el-option value="command" label="⌨ 单条命令"/>
            <el-option value="script" label="📜 脚本正文"/>
            <el-option value="upload" label="📄 上传脚本文件"/>
            <el-option value="yaml" label="☸ K8s YAML(apply)"/>
          </el-select>
        </el-form-item>
      </div>
      <el-form-item label="标签">
        <el-select v-model="form.tags" multiple filterable allow-create default-first-option
                   placeholder="回车添加标签,如:部署 / 推理 / 清理 / 诊断" style="width:100%;">
          <el-option v-for="t in allTags" :key="t" :value="t" :label="'#' + t"/>
        </el-select>
      </el-form-item>

      <el-form-item v-if="form.form === 'command'" label="命令">
        <el-input type="textarea" :rows="4" v-model="form.content" class="mono" resize="vertical"
                  placeholder="单条或多行 shell 命令,按原样在目标主机/容器执行"/>
      </el-form-item>
      <el-form-item v-else-if="form.form === 'script'" label="脚本">
        <el-input type="textarea" :rows="11" v-model="form.content" class="mono" resize="vertical"
                  :placeholder="form.lang === 'python' ? '# 完整 Python 脚本\\nimport subprocess\\nprint(subprocess.run([\\'nvidia-smi\\'], capture_output=True).stdout.decode())' : '#!/bin/sh\\n# 完整脚本正文,远程以 ' + runnerHint + ' 执行'"/>
        <div class="ix-note">远程以 <b class="mono">{{ runnerHint }}</b> 从 stdin 执行脚本正文,无需在目标机落盘</div>
      </el-form-item>
      <el-form-item v-else-if="form.form === 'yaml'" label="K8s YAML 清单">
        <el-input type="textarea" :rows="12" v-model="form.content" class="mono" resize="vertical"
                  placeholder="apiVersion: apps/v1\\nkind: Deployment\\nmetadata:\\n  name: vllm-server\\nspec:\\n  replicas: 1\\n  ...\\n支持多文档 YAML(--- 分隔);执行时在目标主机运行 kubectl apply -f -"/>
        <div class="ms-upload-row" style="margin-top:6px;">
          <input type="file" ref="fileRef" style="display:none;" @change="onFile" accept=".yaml,.yml"/>
          <el-button size="small" :loading="uploading" @click="pickFile()">📄 上传 .yaml 文件(可选,优先于粘贴内容)</el-button>
          <span v-if="form.fileLabel" class="ms-upload-info mono">✓ {{ form.fileLabel }}</span>
        </div>
        <div class="ix-note">在目标主机上执行 <b class="mono">kubectl apply -f</b>(粘贴正文走 stdin;已上传文件则先 SFTP 到 /tmp 再 apply);试运行 / 编排步骤里可填命名空间(-n),YAML 内已声明 metadata.namespace 的资源以清单为准</div>
      </el-form-item>
      <el-form-item v-else label="脚本文件">
        <div class="ms-upload-row">
          <input type="file" ref="fileRef" style="display:none;" @change="onFile"/>
          <el-button size="small" :loading="uploading" @click="pickFile()">📄 选择并上传脚本文件</el-button>
          <span v-if="form.fileLabel" class="ms-upload-info mono">✓ {{ form.fileLabel }}</span>
          <span v-else class="ix-note-inline">python / shell 等本地脚本,执行时自动 SFTP 上传到目标主机 /tmp</span>
        </div>
      </el-form-item>

      <div class="ix-tools">
        <el-button type="primary" @click="savePreset()"><el-icon><DocumentChecked/></el-icon>保存预设</el-button>
        <el-button @click="tryRun()"><el-icon><VideoPlay/></el-icon>试运行</el-button>
        <el-button v-if="form.id" type="danger" plain @click="delPreset()"><el-icon><Delete/></el-icon>删除</el-button>
      </div>

      <el-dialog v-model="MS.once.visible" title="▶ 预设试运行" width="640px">
        <div class="ix-row">
          <span class="pl">主机</span>
          <el-select v-model="MS.once.hostId" size="small" style="width:170px;">
            <el-option v-for="h in MS.hosts" :key="h.id" :value="h.id" :label="h.name"/>
          </el-select>
          <template v-if="(MS.presets.find(p => p.id === MS.once.presetId) || {}).kind === 'container'">
            <span class="pl">容器</span>
            <el-input v-model="MS.once.container" size="small" style="width:170px;" placeholder="容器名 / Pod 名"/>
          </template>
          <template v-if="oncePreset.form === 'yaml'">
            <span class="pl">命名空间</span>
            <el-input v-model="MS.once.namespace" size="small" style="width:170px;"
                      placeholder="可选,传给 kubectl apply -n"/>
          </template>
        </div>
        <div class="ix-note">{{ oncePreset.form === 'yaml' ? 'K8s YAML 在所选主机上执行 kubectl apply(上传的 .yaml 文件会先 SFTP 到 /tmp)' : '上传文件形式会先 SFTP 到目标主机 /tmp 再执行' }};输出与错误码如下</div>
        <div class="ms-exec-out" :class="{ fail: MS.once.rc }" style="margin-top:8px;">
          <div v-if="MS.once.cmd" class="cmd mono">$ {{ MS.once.cmd }}</div>
          <pre v-if="MS.once.out" class="out">{{ MS.once.out }}</pre>
          <pre v-if="MS.once.err" class="err">{{ MS.once.err }}</pre>
          <div v-if="MS.once.rc != null" class="status" :class="MS.once.rc === 0 ? 'ok' : 'bad'">
            <template v-if="MS.once.rc === 0">✓ exit 0 · {{ MS.once.duration }}s</template>
            <template v-else>✗ exit {{ MS.once.rc }} · {{ MS.once.duration }}s<template v-if="MS.once.hint"> ── {{ MS.once.hint }}</template></template>
          </div>
        </div>
        <template #footer>
          <el-button @click="MS.once.visible = false">关闭</el-button>
          <el-button type="primary" :loading="MS.once.running" @click="runPresetOnce()">▶ 执行</el-button>
        </template>
      </el-dialog>
    </div>
  </div>`,
};

// ---------- 视图 3:任务编排 v2(分组 / 并行 / 错误码 / 风险提示) ----------
export const PlansView = {
  setup() {
    const form = reactive({ id: "", name: "", steps: [] });
    let stepSeq = 0;
    function editPlan(pl) {
      form.id = pl.id; form.name = pl.name;
      form.steps = (pl.steps || []).map(s => ({ ...s, _k: "s" + (++stepSeq) }));
    }
    function addPlan() {
      form.id = ""; form.name = "";
      form.steps = [];
      addStep();
    }
    function addStep() {
      form.steps.push({
        _k: "s" + (++stepSeq),
        id: "", kind: "host", host_id: MS.activeHost || (MS.hosts[0] || {}).id || "",
        host_group: "", runtime: "docker", container: "", namespace: "",
        preset_id: "", command: "", continue_on_error: false, parallel: true,
      });
    }
    function moveStep(i, d) {
      const j = i + d;
      if (j < 0 || j >= form.steps.length) return;
      const [s] = form.steps.splice(i, 1);
      form.steps.splice(j, 0, s);
    }
    function dupStep(i) {          // 复制步骤:原样插入到该步骤之后(id 清空,保存时生成新 id)
      const copy = { ...form.steps[i], _k: "s" + (++stepSeq), id: "" };
      form.steps.splice(i + 1, 0, copy);
      ElMessage.success(`已复制为第 ${i + 2} 步,记得「保存方案」`);
    }
    async function savePlan() {
      if (!form.name.trim()) { ElMessage.warning("请填写方案名称"); return; }
      if (!form.steps.length) { ElMessage.warning("至少添加一个步骤"); return; }
      const clean = form.steps.map(s => ({
        id: s.id, kind: s.kind, host_id: s.host_id, host_group: s.host_group || "",
        runtime: s.runtime, container: s.container, namespace: s.namespace,
        preset_id: s.preset_id, command: s.command,
        continue_on_error: !!s.continue_on_error, parallel: !!s.parallel,
      }));
      if (form.id) {
        const pl = MS.plans.find(x => x.id === form.id);
        if (pl) Object.assign(pl, { name: form.name.trim(), steps: clean });
      } else {
        MS.plans.push({ id: "", name: form.name.trim(), steps: clean });
      }
      await savePlans();
      ElMessage.success("方案已保存,可运行");
      const saved = MS.plans.find(x => x.name === form.name.trim());
      if (saved && !form.id) editPlan(saved);
    }
    async function delPlan() {
      try { await ElMessageBox.confirm(`删除方案「${form.name}」?`, "删除", { type: "warning" }); } catch { return; }
      MS.plans = MS.plans.filter(x => x.id !== form.id);
      await savePlans();
      form.id = ""; form.name = ""; form.steps = [];
    }
    async function dupPlan() {          // 复制当前方案为新方案(步骤原样带走,一键另存副本)
      if (!form.steps.length) { ElMessage.warning("当前方案没有步骤可复制"); return; }
      form.id = "";
      form.name = (form.name || "方案").replace(/\s*副本\d*$/, "") + " 副本";
      await savePlan();
    }
    function stepPreset(st) { return MS.presets.find(x => x.id === st.preset_id) || null; }
    function isYamlStep(st) { const p = stepPreset(st); return !!p && p.form === "yaml"; }
    // 步骤选预设时:K8s YAML 预设固定主机执行(kubectl 在主机上,与容器无关)
    function onStepPreset(st) { if (isYamlStep(st)) st.kind = "host"; }
    function presetContent(pid) {
      const p = MS.presets.find(x => x.id === pid);
      if (!p) return "";
      if (p.form === "yaml") return p.filename ? `☸ kubectl apply -f ${p.filename}` : "☸ kubectl apply <<YAML";
      return p.form === "upload" ? `📄 ${p.filename}` : p.content || "";
    }
    function stepCmd(st) { return st.preset_id ? presetContent(st.preset_id) : (st.command || ""); }
    function stepPreview(st) {
      const c = stepCmd(st);
      return (c || "(空)").split("\n")[0].slice(0, 90);
    }
    function risky(st) { return isRiskyCmd(stepCmd(st)); }
    async function onRun() {
      if (!form.id) { ElMessage.warning("请先保存方案再运行"); return; }
      // 高风险命令确认(kill / 停止 / 删除 / 重启)
      const risks = [];
      form.steps.forEach((st, i) => {
        if (risky(st)) risks.push({ i: i + 1, cmd: stepPreview(st) });
      });
      if (risks.length) {
        try {
          await ElMessageBox.confirm(
            `<div style="line-height:2">以下步骤包含 <b style="color:var(--el-color-danger)">高风险命令(kill / 停止 / 删除 / 重启)</b>,可能终止进程或破坏运行环境:<br>` +
            risks.map(r => `<div class="mono" style="color:var(--el-color-danger)">步骤 ${r.i}:$ ${r.cmd}</div>`).join("") +
            `</div><div style="margin-top:10px;font-weight:600;">确认继续执行?</div>`,
            "⚠ 高风险命令确认",
            { dangerouslyUseHTMLString: true, type: "warning", confirmButtonText: "仍要执行", cancelButtonText: "取消" },
          );
        } catch { return; }
      }
      runPlan(form.id, (e) => ElMessage.error(e.message));
      // 运行面板滚入视野,启动即可看到实时日志
      nextTick(() => { runPanelEl.value && runPanelEl.value.scrollIntoView({ behavior: "smooth", block: "nearest" }); });
    }
    const groups = () => hostGroups();
    // ---------- 运行日志自动滚动:新日志到达时贴底显示(用户上翻阅读时不打扰) ----------
    const runLogEl = ref(null);
    const runPanelEl = ref(null);
    watch(() => MS.run.logs.length, async () => {
      await nextTick();
      const el = runLogEl.value;
      if (el && el.scrollHeight - el.scrollTop - el.clientHeight < 90) el.scrollTop = el.scrollHeight;
    });
    // ---------- 执行历史:方案列表「上次运行」信息 + 底部折叠面板 ----------
    onMounted(() => { loadHistory(true); });
    const lastRunByPlan = computed(() => {
      const map = {};
      for (const r of MS.history.runs) {          // 服务端已按开始时间倒序,取每个方案最近一次
        if (r.plan_id && !(r.plan_id in map)) map[r.plan_id] = r;
      }
      return map;
    });
    const histDotCls = (s) => ({ done: "ok", partial: "p", failed: "err", cancelled: "p", running: "run" }[s] || "");
    function histDur(r) {
      const p = (s) => new Date(String(s || "").replace(" ", "T"));
      const a = p(r.started), b = p(r.finished);
      if (!r.finished || isNaN(a) || isNaN(b)) return "";
      let s = Math.max(0, Math.round((b - a) / 1000));
      if (s < 60) return s + " 秒";
      const m = Math.floor(s / 60); s %= 60;
      if (m < 60) return m + " 分" + (s ? " " + s + " 秒" : "");
      return Math.floor(m / 60) + " 时 " + (m % 60) + " 分";
    }
    // 底部折叠面板:展开时滚入视野,收起时不打扰
    const histPanelEl = ref(null);
    watch(() => MS.history.visible, async (v) => {
      if (!v) return;
      await nextTick();
      if (histPanelEl.value) histPanelEl.value.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
    return { MS, form, editPlan, addPlan, addStep, moveStep, dupStep, savePlan, delPlan, dupPlan, onRun, cancelRun, pauseRun, resumeRun, closeRun, stepPreview, stepCmd, stepPreset, isYamlStep, onStepPreset, risky,
             runTag, runText, stepTag, groups, loadHistory, openHistory, openHistoryRun, clearHistory,
             lastRunByPlan, histDotCls, histDur, runLogEl, runPanelEl, histPanelEl, RO: isViewer() };
  },
  template: `
  <div class="ms-cols ms-plans">
    <div class="ms-panel ms-preset-list">
      <div class="aside-head">
        <span class="aside-title">方案<em>({{ MS.plans.length }})</em></span>
        <span class="grow"></span>
        <el-button v-if="!RO" size="small" @click="addPlan()"><el-icon><Plus/></el-icon>新建</el-button>
      </div>
      <div class="ms-list">
        <div v-for="pl in MS.plans" :key="pl.id" class="ms-row" :class="{ on: form.id === pl.id }" @click="editPlan(pl)">
          <div class="t">{{ pl.name }}</div>
          <div class="sub">
            <i v-if="lastRunByPlan[pl.id]" class="dot" :class="histDotCls(lastRunByPlan[pl.id].status)"
               :title="'上次运行:' + runText(lastRunByPlan[pl.id].status)"></i>
            {{ pl.steps.length }} 个步骤<template v-if="lastRunByPlan[pl.id]"> · 上次 {{ runText(lastRunByPlan[pl.id].status) }} {{ (lastRunByPlan[pl.id].started || "").slice(5, 16) }}</template>
          </div>
        </div>
        <div v-if="!MS.plans.length" class="ms-empty">暂无方案。示例:分组「GPU 节点」并行创建容器 → 单机容器内启动推理脚本</div>
      </div>
    </div>

    <div v-if="RO" class="ms-panel ms-editor" style="display:flex;align-items:center;justify-content:center;">
      <div class="ms-empty">👁 预览模式:仅可查看方案列表,不可编辑 / 运行 / 执行任何操作</div>
    </div>
    <div v-else class="ms-panel ms-editor">
      <div class="ix-row ms-plan-toolbar">
        <el-input v-model="form.name" placeholder="方案名称,如:7 机并行创建容器 + 启动推理"
                  style="width:300px;max-width:46%;flex:none;" clearable/>
        <el-button style="flex:none;" @click="addPlan()"><el-icon><Plus/></el-icon>新建方案</el-button>
        <el-button style="flex:none;" @click="savePlan()"><el-icon><DocumentChecked/></el-icon>保存方案</el-button>
        <el-button v-if="form.id" style="flex:none;" title="复制当前方案为新方案" @click="dupPlan()"><el-icon><CopyDocument/></el-icon>复制</el-button>
        <el-button type="primary" style="flex:none;" :disabled="!form.id || MS.run.status === 'running'"
                   :title="MS.run.status === 'running' ? '有方案正在运行,先暂停 / 撤回 / 关闭后再运行' : '先「保存方案」再运行;含 kill/停止/删除 命令时运行前会弹出风险确认'"
                   @click="onRun()"><el-icon><VideoPlay/></el-icon>运行方案</el-button>
        <el-button v-if="form.id" type="danger" plain style="flex:none;" @click="delPlan()"><el-icon><Delete/></el-icon>删除</el-button>
      </div>
      <div class="ix-note">步骤按顺序执行;目标可选<b>单主机</b>或<b>分组</b>(分组默认组内并行,可关);失败默认中止方案,可勾选「失败继续」</div>

      <div class="ms-steps">
        <div v-for="(st, i) in form.steps" :key="st._k" class="ms-step" :class="{ risky: risky(st) }">
          <div class="ms-step-rail">
            <span class="ms-step-no">{{ i + 1 }}</span>
            <span class="ms-step-kind" :class="{ ct: st.kind === 'container' }"
                  :title="st.kind === 'container' ? '在容器内执行' : '在主机内执行'">{{ st.kind === 'container' ? '容器内' : '主机内' }}</span>
          </div>
          <div class="ms-step-main">
          <div class="ms-step-head">
            <el-tag v-if="st.host_group" size="small" type="warning">组:{{ st.host_group }}</el-tag>
            <el-tag v-if="isYamlStep(st)" size="small" type="success"
                    title="K8s YAML 预设:在目标主机上执行 kubectl apply">☸ kubectl apply</el-tag>
            <span v-if="risky(st)" class="ms-risk-badge" title="包含 kill / 停止 / 删除类命令,运行前将再次确认">⚠ 高风险</span>
            <span class="mono ms-step-cmd" :title="stepCmd(st)">{{ stepPreview(st) }}</span>
          </div>
          <div class="ms-step-body">
            <div class="ix-seg ms-target-mode">
              <button type="button" :class="{ on: !st.host_group }" @click="st.host_group = ''">单主机</button>
              <button type="button" :class="{ on: !!st.host_group }"
                      @click="!st.host_group && (st.host_group = (groups()[0] || {}).name || '')">按分组</button>
            </div>
            <template v-if="!st.host_group">
              <el-select v-model="st.host_id" placeholder="选择主机" style="width:160px;">
                <el-option v-for="h in MS.hosts" :key="h.id" :value="h.id" :label="h.name"/>
              </el-select>
            </template>
            <template v-else>
              <el-select v-model="st.host_group" placeholder="选择分组" style="width:150px;">
                <el-option v-for="g in groups()" :key="g.name" :value="g.name" :label="g.name + '(' + g.hosts.length + ')'"/>
              </el-select>
              <el-checkbox v-model="st.parallel" title="分组内多主机同时执行(线程池)">组内并行</el-checkbox>
            </template>
            <el-select v-model="st.kind" style="width:100px;" :disabled="isYamlStep(st)"
                       :title="isYamlStep(st) ? 'K8s YAML 预设固定在主机上执行 kubectl apply' : ''">
              <el-option value="host" label="主机内"/><el-option value="container" label="容器内" :disabled="isYamlStep(st)"/>
            </el-select>
            <template v-if="st.kind === 'container' && !isYamlStep(st)">
              <el-select v-model="st.runtime" style="width:96px;">
                <el-option value="docker" label="Docker"/><el-option value="k8s" label="K8s"/>
              </el-select>
              <el-input v-model="st.container" placeholder="容器名 / Pod 名" style="width:150px;"/>
              <el-input v-if="st.runtime === 'k8s'" v-model="st.namespace" placeholder="命名空间" style="width:110px;"/>
            </template>
            <el-input v-if="isYamlStep(st)" v-model="st.namespace" placeholder="命名空间(可选)" style="width:130px;"
                      title="传给 kubectl apply -n;YAML 内已声明 metadata.namespace 的资源以清单为准"/>
            <el-select v-model="st.preset_id" clearable placeholder="选预设" style="width:150px;" @change="onStepPreset(st)">
              <el-option v-for="p in MS.presets" :key="p.id" :value="p.id" :label="p.name"/>
            </el-select>
            <el-input v-model="st.command" class="mono" placeholder="或直接填命令(未选预设时生效)" style="flex:1;min-width:180px;"/>
            <el-checkbox v-model="st.continue_on_error">失败继续</el-checkbox>
            <span class="ms-step-ops">
              <el-button text @click="moveStep(i, -1)" title="上移一步"><el-icon><ArrowUp/></el-icon></el-button>
              <el-button text @click="moveStep(i, 1)" title="下移一步"><el-icon><ArrowDown/></el-icon></el-button>
              <el-button text @click="dupStep(i)" title="复制该步骤,插入到下一步"><el-icon><CopyDocument/></el-icon></el-button>
              <el-button text type="danger" @click="form.steps.splice(i, 1)" title="删除该步骤"><el-icon><Close/></el-icon></el-button>
            </span>
          </div>
          </div>
        </div>
        <el-button size="small" plain class="ms-add-step" @click="addStep()">＋ 添加步骤</el-button>
      </div>

      <!-- 运行区常驻:状态 / 暂停 / 撤回 / 执行历史固定在此,不随运行开始才出现 -->
      <div ref="runPanelEl" class="ms-run" :class="{ empty: !MS.run.id }">
        <div class="ms-run-head">
          <b>运行</b>
          <el-tag v-if="MS.run.id" size="small" :type="MS.run.paused ? 'warning' : runTag(MS.run.status)">
            {{ MS.run.paused ? "已暂停" : runText(MS.run.status) }}
          </el-tag>
          <span v-if="MS.run.started" class="ix-note-inline">{{ MS.run.started }}</span>
          <span class="grow"></span>
          <el-button v-if="MS.run.status === 'running'" size="small"
                     :type="MS.run.paused ? 'primary' : 'warning'" plain
                     @click="MS.run.paused ? resumeRun() : pauseRun()">
            <el-icon v-if="MS.run.paused"><VideoPlay/></el-icon><el-icon v-else><VideoPause/></el-icon>{{ MS.run.paused ? "继续" : "暂停" }}
          </el-button>
          <el-button v-if="MS.run.status === 'running'" size="small" type="danger" plain @click="cancelRun()"><el-icon><CircleClose/></el-icon>撤回</el-button>
          <el-button size="small" @click="openHistory()"><el-icon><Clock/></el-icon>执行历史</el-button>
          <el-button v-if="MS.run.id" size="small" @click="closeRun()">关闭</el-button>
        </div>
        <template v-if="MS.run.id">
        <div class="ms-run-steps">
          <el-tag v-for="(s, i) in MS.run.steps" :key="i" size="small" :type="stepTag(s.status)" class="ms-run-step"
                  :title="s.note || ''">
            {{ i + 1 }}. {{ s.name }} · {{ runText(s.status) }}<template v-if="s.rc != null && s.rc !== 0">(exit {{ s.rc }})</template>
          </el-tag>
        </div>
        <pre ref="runLogEl" class="ms-run-log"><template v-for="l in MS.run.logs" :key="l.i"><span :class="'l-' + l.level">[{{ l.t }}] {{ l.text }}
</span></template></pre>
        </template>
        <div v-else class="ms-empty" style="padding:10px;">保存方案后点「运行方案」;运行中可暂停 / 撤回,全部记录在「执行历史」回看</div>
      </div>

      <!-- 执行历史:随编辑器列排布的底部折叠面板,与右侧板块对齐(不凸到左侧方案列) -->
      <div ref="histPanelEl" class="ms-hist-panel">
      <div class="ms-hist-panel-head" @click="openHistory()">
        <i class="arrow" :class="{ open: MS.history.visible }">▸</i>
        <b>📜 执行历史</b>
        <span class="ix-note-inline">共 {{ MS.history.runs.length }} 条记录 · 点击条目展开步骤与日志</span>
        <span v-if="MS.history.runs.length" class="ix-note-inline">
          最近:{{ MS.history.runs[0].plan_name }} · {{ runText(MS.history.runs[0].status) }} {{ (MS.history.runs[0].started || "").slice(5, 16) }}
        </span>
        <span class="grow"></span>
        <el-button size="small" :loading="MS.history.loading" @click.stop="loadHistory()">刷新</el-button>
        <el-button size="small" type="danger" plain :disabled="!MS.history.runs.length" @click.stop="clearHistory()">清空</el-button>
      </div>
      <div v-if="MS.history.visible" class="ms-hist-list">
        <div v-for="r in MS.history.runs" :key="r.id" class="ms-hist-item" :class="{ on: MS.history.detailId === r.id }"
             @click="openHistoryRun(r)">
          <div class="ms-hist-head">
            <i class="dot" :class="histDotCls(r.status)"></i>
            <b class="t">{{ r.plan_name }}</b>
            <el-tag size="small" :type="runTag(r.status)">{{ runText(r.status) }}</el-tag>
            <span class="grow"></span>
            <span class="sub mono">{{ r.started }}</span>
          </div>
          <div class="ms-hist-sub">
            <span>{{ r.steps.length }} 步 · ✓ {{ r.counts.ok || 0 }} · ✗ {{ r.counts.fail || 0 }}<template v-if="r.counts.partial"> · ⚠ {{ r.counts.partial }}</template><template v-if="r.counts.skipped"> · ⊘ {{ r.counts.skipped }}</template></span>
            <span v-if="r.finished" class="mono">⏱ {{ histDur(r) }}</span>
            <span v-else class="mono">⏱ 进行中…</span>
            <span class="grow"></span>
            <span class="hint">{{ MS.history.detailId === r.id ? "收起 ▴" : "详情 ▾" }}</span>
          </div>
          <div v-if="MS.history.detailId === r.id" class="ms-hist-detail">
            <template v-if="MS.history.detail && MS.history.detail.id === r.id">
              <div class="ms-run-steps">
                <el-tag v-for="(s, i) in MS.history.detail.steps" :key="i" size="small" :type="stepTag(s.status)"
                        class="ms-run-step" :title="s.note || ''">
                  {{ i + 1 }}. {{ s.name }} · {{ runText(s.status) }}<template v-if="s.rc != null && s.rc !== 0">(exit {{ s.rc }})</template>
                </el-tag>
              </div>
              <pre class="ms-run-log"><template v-for="l in MS.history.detail.logs" :key="l.i"><span :class="'l-' + l.level">[{{ l.t }}] {{ l.text }}
</span></template></pre>
            </template>
            <div v-else class="ms-empty" style="padding:8px;">加载日志…</div>
          </div>
        </div>
        <div v-if="!MS.history.runs.length && !MS.history.loading" class="ms-empty">
          暂无执行记录。保存方案并「▶ 运行方案」后,这里会记录每次运行(含失败与取消)
        </div>
      </div>
      </div>
    </div>
  </div>`,
};
