// ============================== 用户管理抽屉 + 修改密码对话框 ==============================
// 账号层级(惯例五级):总管理员 > 管理员 > 子账号 > 预览用户;(待审批 = 自助注册过渡状态)
//  - 总管理员(super):管理一切;可对管理员账号降级 / 停用,可重置 admin 账号密码
//  - 管理员(admin):全部功能,与总管理员共享网关渠道/密钥与 SSH 主机池;可设立子账号 / 预览用户
//  - 子账号(sub):创建时勾选功能模块 + 分配部署站主机,数据独立
//  - 预览用户(viewer):仅查看三个页面 + 使用对话,无任何编辑 / 主机 / 操作权限
import { reactive, ref, computed } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  AUTH, isSuper, ROLE_LABEL, PERM_KEYS, PERM_LABEL,
  loadUsers, createUser, updateUser, deleteUser, approveUser,
} from "./auth.js";
import { api } from "./api.js";

// ---------- 修改自己的密码 ----------
export const PwdDialog = {
  setup() {
    const visible = ref(false);
    const form = reactive({ old: "", nw: "", loading: false });
    function open() { form.old = ""; form.nw = ""; visible.value = true; }
    async function save() {
      if (!form.old || !form.nw) { ElMessage.warning("请填写原密码和新密码"); return; }
      if (form.nw.length < 6) { ElMessage.warning("新密码至少 6 位"); return; }
      form.loading = true;
      try {
        await api("/api/auth/password", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ old_password: form.old, new_password: form.nw }) });
        ElMessage.success("密码已修改,下次登录请使用新密码");
        visible.value = false;
      } catch (e) { ElMessage.error(e.message); }
      form.loading = false;
    }
    return { visible, form, open, save };
  },
  template: `
  <el-dialog v-model="visible" title="🔑 修改密码" width="420px">
    <el-form label-width="76px">
      <el-form-item label="原密码"><el-input v-model="form.old" type="password" show-password/></el-form-item>
      <el-form-item label="新密码"><el-input v-model="form.nw" type="password" show-password placeholder="至少 6 位"/></el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="form.loading" @click="save()">保存</el-button>
    </template>
  </el-dialog>`,
};

// ---------- 用户管理(管理员):待审批 / 账号列表 / 新建 / 编辑(角色·密码·主机·权限) / 暂停 / 升降级 / 删除 ----------
export const UsersDrawer = {
  setup() {
    const visible = ref(false);
    const loading = ref(false);
    const users = ref([]);
    const hosts = ref([]);                       // SSH 主机池(分配给子账号用)
    const dlg = reactive({ visible: false, isEdit: false, name: "", password: "", role: "sub", hosts: [], perms: [...PERM_KEYS] });
    const apv = reactive({ visible: false, name: "", perms: [...PERM_KEYS], loading: false });

    // 总管理员可编辑一切(含 admin 账号,可重置其密码);普通管理员可编辑子账号 / 预览用户
    const canEditRole = (u) => isSuper() || u.role === "sub" || u.role === "viewer";
    // 暂停开关:不可停用自己 / 总管理员账号;管理员账号仅总管理员可停
    const canSuspend = (u) => u.role !== "super" && u.username !== AUTH.user?.username
      && (isSuper() || u.role !== "admin");
    const pending = computed(() => users.value.filter(u => u.status === "pending"));
    const activeUsers = computed(() => users.value.filter(u => u.status !== "pending"));

    async function open() {
      visible.value = true;
      await refresh();
    }
    async function refresh() {
      loading.value = true;
      try {
        users.value = (await loadUsers()).users || [];
        const d = await api("/api/modelstart/hosts");
        hosts.value = d.hosts || [];
      } catch (e) { ElMessage.error(e.message); }
      loading.value = false;
    }
    function openCreate() {
      Object.assign(dlg, { visible: true, isEdit: false, name: "", password: "", role: "sub", hosts: [], perms: [...PERM_KEYS] });
    }
    function openEdit(u) {
      Object.assign(dlg, { visible: true, isEdit: true, name: u.username, password: "", role: u.role,
                           hosts: [...(u.hosts || [])], perms: [...(u.perms || [])] });
    }
    async function save() {
      try {
        if (!dlg.isEdit) {
          if (!dlg.name.trim() || !dlg.password) { ElMessage.warning("请填写用户名和密码"); return; }
          await createUser({ username: dlg.name, password: dlg.password, role: dlg.role,
                             hosts: dlg.role === "sub" ? dlg.hosts : [], perms: dlg.role === "sub" ? dlg.perms : [] });
          ElMessage.success("账号已创建");
        } else {
          await updateUser(dlg.name, {
            password: dlg.password || "",
            role: dlg.role,
            ...(dlg.role === "sub" ? { hosts: dlg.hosts, perms: dlg.perms } : {}),
          });
          ElMessage.success("账号已更新");
        }
        dlg.visible = false;
        await refresh();
      } catch (e) { ElMessage.error(e.message); }
    }
    async function remove(u) {
      try {
        await ElMessageBox.confirm(`删除账号「${u.username}」?其全部数据(会话 / 压测 / 预设 / 方案)将一并删除且不可恢复`, "删除账号", { type: "warning" });
      } catch { return; }
      try {
        await deleteUser(u.username); ElMessage.success("已删除"); await refresh();
      } catch (e) { ElMessage.error(e.message); }
    }

    // ---------- 暂停 / 启用开关 ----------
    async function toggleStatus(u, on) {
      const act = on ? "启用" : "停用";
      try {
        if (!on) {
          await ElMessageBox.confirm(`停用「${u.username}」?该账号的在线会话将立即失效,且无法再登录`, "停用账号", { type: "warning" });
        }
        await updateUser(u.username, { status: on ? "active" : "suspended" });
        ElMessage.success(`已${act}「${u.username}」`);
        await refresh();
      } catch (e) { if (e !== "cancel" && e?.message) ElMessage.error(e.message); }
    }

    // ---------- 升级 / 降级开关(每行一个,切换相邻层级) ----------
    // 管理员行(仅总管理员可见):管理员 ⇄ 子账号;子账号行:子账号 ⇄ 预览用户;预览行:预览 → 子账号
    // (子账号 → 管理员的升级在「编辑」对话框的角色下拉中,仅总管理员可选)
    async function toggleRole(u, up) {
      const to = u.role === "admin" ? (up ? "admin" : "sub")
        : u.role === "sub" ? (up ? "sub" : "viewer")
        : "sub";
      const desc = {
        admin_sub: `把「${u.username}」降级为子账号?(保留全部功能模块,可再逐项收回)`,
        sub_viewer: `把「${u.username}」降级为预览用户?(仅查看 + 对话,无任何编辑与操作权限)`,
        viewer_sub: `把「${u.username}」升级为子账号?(恢复其原先被授予的功能模块与主机)`,
      };
      const key = [u.role, to].sort().join("_");
      try {
        await ElMessageBox.confirm(desc[key] || `调整「${u.username}」的角色为${ROLE_LABEL[to]}?`, "角色调整", { type: "warning" });
        await updateUser(u.username, { role: to });
        ElMessage.success(`已调整「${u.username}」为${ROLE_LABEL[to]}`);
        await refresh();
      } catch (e) { if (e !== "cancel" && e?.message) ElMessage.error(e.message); }
    }

    // ---------- 自助注册审批:通过 = 激活并授予勾选的功能权限;拒绝 = 删除申请 ----------
    function openApprove(u) {
      Object.assign(apv, { visible: true, name: u.username, perms: [...PERM_KEYS] });
    }
    async function approve() {
      apv.loading = true;
      try {
        await approveUser(apv.name, true, apv.perms);
        ElMessage.success(`已通过「${apv.name}」的注册申请`);
        apv.visible = false;
        await refresh();
      } catch (e) { ElMessage.error(e.message); }
      apv.loading = false;
    }
    async function rejectApply(u) {
      try {
        await ElMessageBox.confirm(`拒绝「${u.username}」的注册申请?该申请将被删除,对方可重新注册`, "拒绝注册", { type: "warning" });
      } catch { return; }
      try {
        await approveUser(u.username, false);
        ElMessage.success("已拒绝该申请");
        await refresh();
      } catch (e) { ElMessage.error(e.message); }
    }
    const hostLabel = (id) => { const h = hosts.value.find(x => x.id === id); return h ? h.name : id; };
    const subHostText = (u) => !u.hosts?.length ? "未分配主机" : `${u.hosts.length} 台:${u.hosts.map(hostLabel).join("、")}`;
    const permText = (u) => {
      if (u.role === "viewer") return "仅查看 + 对话";
      if (u.role !== "sub") return "全部功能(与总管理员共享)";
      return (!(u.perms || []).length ? "未分配功能" : `${u.perm_labels.length} 项:${u.perm_labels.join("、")}`);
    };
    return { AUTH, visible, loading, users, hosts, dlg, apv, canEditRole, canSuspend,
             pending, activeUsers, isSuper,
             open, refresh, openCreate, openEdit, save, remove, toggleStatus, toggleRole,
             openApprove, approve, rejectApply, subHostText, permText, ROLE_LABEL, PERM_KEYS, PERM_LABEL };
  },
  template: `
  <el-drawer v-model="visible" title="👥 用户管理" size="680px">
    <div class="ms-hist">
      <!-- 待审批注册 -->
      <div v-if="pending.length" class="usr-pending">
        <div class="ms-hist-bar">
          <span class="ix-note-inline" style="font-weight:700;">⏳ 待审批注册({{ pending.length }})</span>
        </div>
        <div v-for="u in pending" :key="u.username" class="ms-hist-item" style="cursor:default;">
          <div class="ms-hist-head">
            <span class="usr-avatar">{{ (u.username[0] || "?").toUpperCase() }}</span>
            <b class="t">{{ u.username }}</b>
            <el-tag size="small" type="warning">待审批</el-tag>
            <span class="grow"></span>
            <span class="sub mono">{{ u.created }}</span>
          </div>
          <div class="ms-hist-sub">
            <span>自助注册 · 通过后设置功能权限即可登录</span>
            <span class="grow"></span>
            <el-button size="small" text type="primary" @click="openApprove(u)">✓ 通过</el-button>
            <el-button size="small" text type="danger" @click="rejectApply(u)">✗ 拒绝</el-button>
          </div>
        </div>
      </div>

      <div class="ms-hist-bar">
        <span class="ix-note-inline">共 {{ activeUsers.length }} 个账号 · 层级:总管理员 → 管理员 → 子账号 → 预览用户;子账号数据隔离,仅可操作被分配的主机与功能</span>
        <span class="grow"></span>
        <el-button size="small" :loading="loading" @click="refresh()">刷新</el-button>
        <el-button size="small" type="primary" plain @click="openCreate()">＋ 新增账号</el-button>
      </div>
      <div class="ms-hist-list">
        <div v-for="u in activeUsers" :key="u.username" class="ms-hist-item"
             :class="{ 'usr-suspended': u.status === 'suspended' }" style="cursor:default;">
          <div class="ms-hist-head">
            <span class="usr-avatar">{{ (u.username[0] || "?").toUpperCase() }}</span>
            <b class="t">{{ u.username }}</b>
            <el-tag size="small" :type="u.role === 'super' ? 'danger' : u.role === 'admin' ? 'warning' : u.role === 'viewer' ? 'success' : 'info'">{{ u.role_label }}</el-tag>
            <el-tag v-if="u.status === 'suspended'" size="small" type="danger" effect="dark">已停用</el-tag>
            <span v-if="u.username === AUTH.user?.username" class="ms-mini-badge">当前登录</span>
            <span class="grow"></span>
            <span class="sub mono">{{ u.created }}</span>
          </div>
          <div class="ms-hist-sub">
            <span v-if="u.role === 'sub'">🖥 {{ subHostText(u) }}</span>
            <span v-else-if="u.role === 'viewer'">👁 全站只读 · 无主机 · 无操作权限</span>
            <span v-else>🖥 全部主机</span>
            <span>🧩 {{ permText(u) }}</span>
            <span class="grow"></span>
            <!-- 暂停 / 启用开关 -->
            <el-switch v-if="canSuspend(u)" size="small" :model-value="u.status !== 'suspended'"
                       inline-prompt active-text="启" inactive-text="停"
                       :title="u.status === 'suspended' ? '点击启用该账号' : '点击停用该账号(立即踢下线,不可再登录)'"
                       @change="on => toggleStatus(u, on)"/>
            <!-- 升级 / 降级开关(相邻层级):管理员⇄子账号(仅总管理员) / 子账号⇄预览用户(任何管理员) -->
            <el-switch v-if="isSuper() && u.role === 'admin'" size="small"
                       :model-value="true" inline-prompt active-text="管理员" inactive-text="降为子账号"
                       title="降级为子账号(保留全部功能模块,可再逐项收回)"
                       @change="on => toggleRole(u, on)"/>
            <el-switch v-else-if="u.role === 'sub' && u.username !== AUTH.user?.username" size="small"
                       :model-value="true" inline-prompt active-text="子账号" inactive-text="预览"
                       title="降级为预览用户(仅查看 + 对话);重新打开即恢复为子账号"
                       @change="on => toggleRole(u, on)"/>
            <el-switch v-else-if="u.role === 'viewer'" size="small"
                       :model-value="false" inline-prompt active-text="升为子账号" inactive-text="预览"
                       title="升级为子账号(恢复其原先被授予的功能模块与主机)"
                       @change="() => toggleRole(u, true)"/>
            <el-button v-if="canEditRole(u)" size="small" text type="primary" @click="openEdit(u)">编辑</el-button>
            <el-button v-if="u.role !== 'super' && u.username !== AUTH.user?.username" size="small" text type="danger" @click="remove(u)">删除</el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 新建 / 编辑账号 -->
    <el-dialog v-model="dlg.visible" :title="dlg.isEdit ? '编辑账号 · ' + dlg.name : '新增账号'" width="520px" append-to-body>
      <el-form label-width="84px">
        <el-form-item v-if="!dlg.isEdit" label="用户名">
          <el-input v-model="dlg.name" placeholder="2-24 位,可含中文/字母/数字/_/-"/>
        </el-form-item>
        <el-form-item :label="dlg.isEdit ? '重置密码' : '密码'">
          <el-input v-model="dlg.password" type="password" show-password
                    :placeholder="dlg.isEdit ? '留空表示不修改' : '至少 6 位'"/>
          <div v-if="dlg.isEdit && dlg.name === 'admin'" class="ix-note">总管理员账号:可在此重置 admin 的登录密码</div>
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="dlg.role" style="width:100%;"
                     :disabled="dlg.isEdit && dlg.name === 'admin'">
            <el-option v-if="dlg.role === 'super'" value="super" label="总管理员(内置,不可变更)"/>
            <el-option value="sub" label="子账号(按模块授权 + 分配主机,数据独立)"/>
            <el-option value="viewer" label="预览用户(仅查看 + 对话,不可编辑 / 无主机)"/>
            <el-option v-if="isSuper()" value="admin" label="管理员(全部功能,与总管理员共享网关与主机池)"/>
          </el-select>
        </el-form-item>
        <template v-if="dlg.role === 'sub'">
          <el-form-item label="功能权限">
            <el-checkbox-group v-model="dlg.perms" class="usr-perm-group">
              <el-checkbox v-for="k in PERM_KEYS" :key="k" :label="k">{{ PERM_LABEL[k] }}</el-checkbox>
            </el-checkbox-group>
            <div class="ix-note">按勾选授予功能模块;全部不勾 = 登录后无任何功能入口;后续可在「编辑」中调整</div>
          </el-form-item>
          <el-form-item label="分配主机">
            <el-select v-model="dlg.hosts" multiple style="width:100%;" placeholder="选择该子账号可操作的 SSH 主机">
              <el-option v-for="h in hosts" :key="h.id" :value="h.id" :label="h.name + '(' + h.host + ')'"/>
            </el-select>
            <div class="ix-note">子账号在部署站只能看到并操作这里分配的主机;也可在部署站「编辑主机」里分配</div>
          </el-form-item>
        </template>
        <div v-else-if="dlg.role === 'viewer'" class="ix-note" style="margin:4px 0 12px;">
          👁 预览用户登录后可查看三个工作台页面并使用对话功能(经管理员配置的网关渠道),不可编辑任何内容、未分配任何主机与操作权限
        </div>
        <div v-else-if="dlg.role === 'admin'" class="ix-note" style="margin:4px 0 12px;">
          管理员拥有全部功能,与总管理员共享网关渠道/密钥与 SSH 主机池;总管理员可随时对其降级或停用
        </div>
      </el-form>
      <template #footer>
        <el-button @click="dlg.visible = false">取消</el-button>
        <el-button type="primary" @click="save()">保存</el-button>
      </template>
    </el-dialog>

    <!-- 审批注册:通过时勾选授予的功能权限 -->
    <el-dialog v-model="apv.visible" :title="'审批注册 · ' + apv.name" width="480px" append-to-body>
      <el-form label-width="84px">
        <el-form-item label="功能权限">
          <el-checkbox-group v-model="apv.perms" class="usr-perm-group">
            <el-checkbox v-for="k in PERM_KEYS" :key="k" :label="k">{{ PERM_LABEL[k] }}</el-checkbox>
          </el-checkbox-group>
          <div class="ix-note">按勾选授予;全部不勾 = 暂不开放任何功能;后续可在「编辑」中调整</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="apv.visible = false">取消</el-button>
        <el-button type="primary" :loading="apv.loading" @click="approve()">通过并授予权限</el-button>
      </template>
    </el-dialog>
  </el-drawer>`,
};
