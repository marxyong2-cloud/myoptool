// ============================== 提示词库 + 技能库 ==============================
import { ref, reactive, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { S, loadLib } from "./mu-store.js";
import { api } from "./api.js";
import { insertTextGlobal } from "./mu-bus.js";
import { isViewer } from "./auth.js";

// {{变量}} 展示文本(mustache 内不能出现 "}}" 字面量,故用方法生成)
const varTag = (v) => "{{" + v + "}}";

// ---------- 提示词 ----------
export const PromptsView = {
  setup() {
    const dlg = ref(false);
    const form = reactive({ id: "", name: "", category: "", content: "" });
    const vars = computed(() =>
      [...new Set((String(form.content).match(/\{\{(.+?)\}\}/g) || []).map(x => x.slice(2, -2)))]);

    function openDlg(p) {
      form.id = p ? p.id : "";
      form.name = p ? p.name : "";
      form.category = p ? (p.category || "") : "";
      form.content = p ? p.content : "";
      dlg.value = true;
    }
    async function save() {
      if (!form.name.trim() || !form.content.trim()) { ElMessage.warning("名称与内容必填"); return; }
      try {
        await api("/api/modeluse/prompts", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: form.id, name: form.name.trim(), category: form.category.trim(), content: form.content.trim() }),
        });
        dlg.value = false;
        await loadLib();
        ElMessage.success("已保存");
      } catch (e) { ElMessage.error(e.message); }
    }
    async function remove(p) {
      try { await ElMessageBox.confirm(`删除提示词「${p.name}」?`, "删除", { type: "warning" }); } catch { return; }
      await api("/api/modeluse/prompts/" + p.id, { method: "DELETE" });
      await loadLib();
      ElMessage.success("已删除");
    }
    function use(p) {
      S.view = "chat";
      insertTextGlobal("/" + p.name + " ");
      ElMessage.success("已输入 /" + p.name + ",选择模板插入");
    }
    onMounted(loadLib);
    return { S, dlg, form, vars, varTag, openDlg, save, remove, use, RO: isViewer() };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>📚 提示词库</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">对话输入 / 即可快速插入;支持 <code v-pre>{{变量}}</code> 填充</span>
      <span class="grow"></span>
      <el-button v-if="!RO" type="primary" size="small" @click="openDlg(null)">＋ 新建提示词</el-button>
    </div>
    <el-empty v-if="!S.prompts.length" description="暂无提示词"/>
    <div class="lib-grid">
      <el-card v-for="p in S.prompts" :key="p.id" shadow="never" class="lib-card">
        <div class="hd"><b>{{ p.name }}</b><el-tag size="small" type="warning" style="margin-left:auto;">{{ p.category || '通用' }}</el-tag></div>
        <div class="pv">{{ p.content }}</div>
        <div v-if="(p.variables || []).length" style="margin:6px 0;">
          <el-tag v-for="v in p.variables" :key="v" size="small" type="info" style="margin-right:4px;">{{ varTag(v) }}</el-tag>
        </div>
        <div class="ops">
          <el-button size="small" type="primary" plain @click="use(p)">使用</el-button>
          <el-button v-if="!RO" size="small" @click="openDlg(p)">编辑</el-button>
          <el-button v-if="!RO" size="small" type="danger" plain @click="remove(p)">删除</el-button>
        </div>
      </el-card>
    </div>

    <el-dialog v-model="dlg" :title="form.id ? '编辑提示词' : '新建提示词'" width="540px">
      <el-form label-width="64px" label-position="left">
        <el-form-item label="名称"><el-input v-model="form.name" placeholder="如:周报生成"/></el-form-item>
        <el-form-item label="分类"><el-input v-model="form.category" placeholder="如:职场写作"/></el-form-item>
        <el-form-item label="内容">
          <el-input v-model="form.content" type="textarea" :rows="7" placeholder="支持 {{ '{{变量}}' }} 占位,使用时弹窗填充"/>
        </el-form-item>
      </el-form>
      <div style="font-size:12px;color:var(--el-text-color-secondary);">识别变量:
        <el-tag v-for="v in vars" :key="v" size="small" style="margin:2px;">{{ varTag(v) }}</el-tag>
        <span v-if="!vars.length">(无)</span>
      </div>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>`,
};

// ---------- 技能 ----------
export const SkillsView = {
  setup() {
    const dlg = ref(false);
    const form = reactive({ id: "", icon: "", name: "", description: "", content: "" });

    function openDlg(s) {
      form.id = s ? s.id : "";
      form.icon = s ? (s.icon || "") : "";
      form.name = s ? s.name : "";
      form.description = s ? (s.description || "") : "";
      form.content = s ? s.content : "";
      dlg.value = true;
    }
    async function save() {
      if (!form.name.trim() || !form.content.trim()) { ElMessage.warning("名称与内容必填"); return; }
      try {
        await api("/api/modeluse/skills", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: form.id, icon: form.icon.trim(), name: form.name.trim(),
            description: form.description.trim(), content: form.content.trim() }),
        });
        dlg.value = false;
        await loadLib();
        ElMessage.success("已保存");
      } catch (e) { ElMessage.error(e.message); }
    }
    async function remove(s) {
      try { await ElMessageBox.confirm(`删除技能「${s.name}」?`, "删除", { type: "warning" }); } catch { return; }
      await api("/api/modeluse/skills/" + s.id, { method: "DELETE" });
      await loadLib();
      ElMessage.success("已删除");
    }
    function use(s) {
      S.view = "chat";
      insertTextGlobal("@" + s.name + " ");
      ElMessage.success(`已引用 @${s.name}(发送时展开)`);
    }
    onMounted(loadLib);
    return { S, dlg, form, openDlg, save, remove, use, RO: isViewer() };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>🛠 技能库</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">对话输入 @技能名 引用,发送时自动展开为完整指令</span>
      <span class="grow"></span>
      <el-button v-if="!RO" type="primary" size="small" @click="openDlg(null)">＋ 新建技能</el-button>
    </div>
    <el-empty v-if="!S.skills.length" description="暂无技能"/>
    <div class="lib-grid">
      <el-card v-for="s in S.skills" :key="s.id" shadow="never" class="lib-card">
        <div class="hd"><span style="font-size:17px;">{{ s.icon || '🛠' }}</span><b>@{{ s.name }}</b></div>
        <div class="ds">{{ s.description }}</div>
        <div class="pv">{{ s.content }}</div>
        <div class="ops">
          <el-button size="small" type="primary" plain @click="use(s)">@引用</el-button>
          <el-button v-if="!RO" size="small" @click="openDlg(s)">编辑</el-button>
          <el-button v-if="!RO" size="small" type="danger" plain @click="remove(s)">删除</el-button>
        </div>
      </el-card>
    </div>

    <el-dialog v-model="dlg" :title="form.id ? '编辑技能' : '新建技能'" width="540px">
      <el-form label-width="64px" label-position="left">
        <el-form-item label="图标"><el-input v-model="form.icon" placeholder="如:🌐" style="width:100px;"/></el-form-item>
        <el-form-item label="名称"><el-input v-model="form.name" placeholder="调用名(英文/数字/中文),如 translate"/></el-form-item>
        <el-form-item label="描述"><el-input v-model="form.description" placeholder="一句话说明(提及下拉显示)"/></el-form-item>
        <el-form-item label="指令">
          <el-input v-model="form.content" type="textarea" :rows="7" placeholder="发送时展开的完整指令内容"/>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>`,
};
