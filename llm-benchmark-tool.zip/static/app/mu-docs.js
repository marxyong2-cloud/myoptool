// ============================== 接入示例 ==============================
import { ref, computed, onMounted } from "vue";
import { S, loadGw } from "./mu-store.js";
import { copyText } from "./api.js";

function docExamples(proto, lang, base, key, model, origin) {
  const oai = {
    curl: `curl ${base}/chat/completions \\\n  -H "Authorization: Bearer ${key}" \\\n  -H "Content-Type: application/json" \\\n  -d '{"model": "${model}", "messages": [{"role": "user", "content": "你好"}], "stream": true}'`,
    python: `from openai import OpenAI\n\nclient = OpenAI(base_url="${base}", api_key="${key}")\n\nresp = client.chat.completions.create(\n    model="${model}",\n    messages=[{"role": "user", "content": "你好"}],\n)\nprint(resp.choices[0].message.content)\n\n# 流式\n# for chunk in client.chat.completions.create(model="${model}", messages=[...], stream=True):\n#     print(chunk.choices[0].delta.content or "", end="")`,
    js: `const resp = await fetch("${base}/chat/completions", {\n  method: "POST",\n  headers: {\n    "Authorization": "Bearer ${key}",\n    "Content-Type": "application/json",\n  },\n  body: JSON.stringify({\n    model: "${model}",\n    messages: [{ role: "user", content: "你好" }],\n    stream: true,\n  }),\n});\n// resp.body 为 SSE 流`,
    go: `package main\n\nimport (\n  "bytes"\n  "fmt"\n  "io"\n  "net/http"\n)\n\nfunc main() {\n  body := bytes.NewBufferString(\`{"model": "${model}", "messages": [{"role": "user", "content": "你好"}]}\`)\n  req, _ := http.NewRequest("POST", "${base}/chat/completions", body)\n  req.Header.Set("Authorization", "Bearer ${key}")\n  req.Header.Set("Content-Type", "application/json")\n  resp, err := http.DefaultClient.Do(req)\n  if err != nil { panic(err) }\n  defer resp.Body.Close()\n  b, _ := io.ReadAll(resp.Body)\n  fmt.Println(string(b))\n}`,
    java: `import java.net.URI;\nimport java.net.http.*;\n\npublic class Main {\n  public static void main(String[] args) throws Exception {\n    HttpClient client = HttpClient.newHttpClient();\n    String json = "{\\"model\\": \\"${model}\\", \\"messages\\": [{\\"role\\": \\"user\\", \\"content\\": \\"你好\\"}]}";\n    HttpRequest req = HttpRequest.newBuilder()\n        .uri(URI.create("${base}/chat/completions"))\n        .header("Authorization", "Bearer ${key}")\n        .header("Content-Type", "application/json")\n        .POST(HttpRequest.BodyPublishers.ofString(json))\n        .build();\n    HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());\n    System.out.println(resp.body());\n  }\n}`,
    cs: `using System.Net.Http.Json;\n\nvar client = new HttpClient();\nclient.DefaultRequestHeaders.Add("Authorization", "Bearer ${key}");\nvar resp = await client.PostAsJsonAsync("${base}/chat/completions", new {\n  model = "${model}",\n  messages = new[] { new { role = "user", content = "你好" } },\n});\nConsole.WriteLine(await resp.Content.ReadAsStringAsync());`,
    php: `<?php\n$ch = curl_init("${base}/chat/completions");\ncurl_setopt_array($ch, [\n  CURLOPT_RETURNTRANSFER => true,\n  CURLOPT_HTTPHEADER => [\n    "Authorization: Bearer ${key}",\n    "Content-Type: application/json",\n  ],\n  CURLOPT_POSTFIELDS => json_encode([\n    "model" => "${model}",\n    "messages" => [["role" => "user", "content" => "你好"]],\n  ]),\n]);\necho curl_exec($ch);`,
  };
  const ant = {
    curl: `curl ${origin}/v1/messages \\\n  -H "x-api-key: ${key}" \\\n  -H "anthropic-version: 2023-06-01" \\\n  -H "Content-Type: application/json" \\\n  -d '{"model": "${model}", "max_tokens": 1024, "messages": [{"role": "user", "content": "你好"}]}'`,
    python: `from anthropic import Anthropic\n\nclient = Anthropic(base_url="${origin}", api_key="${key}")\n\nmsg = client.messages.create(\n    model="${model}",\n    max_tokens=1024,\n    messages=[{"role": "user", "content": "你好"}],\n)\nprint(msg.content[0].text)\n\n# 流式\n# with client.messages.stream(model="${model}", max_tokens=1024,\n#         messages=[{"role": "user", "content": "你好"}]) as s:\n#     for text in s.text_stream:\n#         print(text, end="")`,
    js: `const resp = await fetch("${origin}/v1/messages", {\n  method: "POST",\n  headers: {\n    "x-api-key": "${key}",\n    "anthropic-version": "2023-06-01",\n    "Content-Type": "application/json",\n  },\n  body: JSON.stringify({\n    model: "${model}",\n    max_tokens: 1024,\n    messages: [{ role: "user", content: "你好" }],\n    stream: true,\n  }),\n});`,
    go: `package main\n\nimport (\n  "bytes"\n  "fmt"\n  "io"\n  "net/http"\n)\n\nfunc main() {\n  body := bytes.NewBufferString(\`{"model": "${model}", "max_tokens": 1024, "messages": [{"role": "user", "content": "你好"}]}\`)\n  req, _ := http.NewRequest("POST", "${origin}/v1/messages", body)\n  req.Header.Set("x-api-key", "${key}")\n  req.Header.Set("anthropic-version", "2023-06-01")\n  req.Header.Set("Content-Type", "application/json")\n  resp, err := http.DefaultClient.Do(req)\n  if err != nil { panic(err) }\n  defer resp.Body.Close()\n  b, _ := io.ReadAll(resp.Body)\n  fmt.Println(string(b))\n}`,
    java: `import java.net.URI;\nimport java.net.http.*;\n\npublic class Main {\n  public static void main(String[] args) throws Exception {\n    HttpClient client = HttpClient.newHttpClient();\n    String json = "{\\"model\\": \\"${model}\\", \\"max_tokens\\": 1024, \\"messages\\": [{\\"role\\": \\"user\\", \\"content\\": \\"你好\\"}]}";\n    HttpRequest req = HttpRequest.newBuilder()\n        .uri(URI.create("${origin}/v1/messages"))\n        .header("x-api-key", "${key}")\n        .header("anthropic-version", "2023-06-01")\n        .header("Content-Type", "application/json")\n        .POST(HttpRequest.BodyPublishers.ofString(json))\n        .build();\n    HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());\n    System.out.println(resp.body());\n  }\n}`,
    cs: `using System.Net.Http.Json;\n\nvar client = new HttpClient();\nclient.DefaultRequestHeaders.Add("x-api-key", "${key}");\nclient.DefaultRequestHeaders.Add("anthropic-version", "2023-06-01");\nvar resp = await client.PostAsJsonAsync("${origin}/v1/messages", new {\n  model = "${model}",\n  max_tokens = 1024,\n  messages = new[] { new { role = "user", content = "你好" } },\n});\nConsole.WriteLine(await resp.Content.ReadAsStringAsync());`,
    php: `<?php\n$ch = curl_init("${origin}/v1/messages");\ncurl_setopt_array($ch, [\n  CURLOPT_RETURNTRANSFER => true,\n  CURLOPT_HTTPHEADER => [\n    "x-api-key: ${key}",\n    "anthropic-version": "2023-06-01",\n    "Content-Type": "application/json",\n  ],\n  CURLOPT_POSTFIELDS => json_encode([\n    "model" => "${model}",\n    "max_tokens" => 1024,\n    "messages" => [["role" => "user", "content" => "你好"]],\n  ]),\n]);\necho curl_exec($ch);`,
  };
  const mm = {
    curl: `# 1) 创建文生视频任务(MiniMax H3 V2)\ncurl ${origin}/v2/video_generation \\\n  -H "Authorization: Bearer ${key}" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "model": "${model}",\n    "content": [{"type": "text", "text": "史诗级太空歌剧院线预告"}],\n    "resolution": "2K",\n    "duration": 5,\n    "ratio": "16:9"\n  }'\n# → {"task_id": "xxx"}\n\n# 2) 轮询任务\ncurl ${origin}/v2/query/video_generation/xxx -H "Authorization: Bearer ${key}"\n# → task.status = succeeded 时,视频在 task.content.url\n\n# 3) 再生成 2K(源任务)\ncurl -X POST ${origin}/v2/video_regeneration \\\n  -H "Authorization: Bearer ${key}" -H "Content-Type: application/json" \\\n  -d '{"model": "${model}", "source_task_id": "xxx", "resolution": "2K"}'`,
    python: `import requests, time\n\nBASE = "${origin}"\nH = {"Authorization": "Bearer ${key}"}\n\n# 创建任务(图生视频:首帧图)\nr = requests.post(f"{BASE}/v2/video_generation", headers=H, json={\n    "model": "${model}",\n    "content": [\n        {"type": "text", "text": "镜头缓慢拉远"},\n        {"type": "image_url", "image_url": {"url": "https://example.com/first.png"}, "role": "first_frame"},\n    ],\n    "resolution": "768P", "duration": 5, "ratio": "adaptive",\n})\ntask_id = r.json()["task_id"]\n\n# 轮询\nwhile True:\n    t = requests.get(f"{BASE}/v2/query/video_generation/{task_id}", headers=H).json()["task"]\n    print(t["status"])\n    if t["status"] in ("succeeded", "failed"): break\n    time.sleep(5)\n\nprint(t.get("content", {}).get("url"))\n\n# 再生成 2K\nrequests.post(f"{BASE}/v2/video_regeneration", headers=H,\n              json={"model": "${model}", "source_task_id": task_id, "resolution": "2K"})`,
    js: `const BASE = "${origin}";\nconst H = { "Authorization": "Bearer ${key}", "Content-Type": "application/json" };\n\n// 创建任务(多模态参考生视频 r2va)\nconst r = await fetch(BASE + "/v2/video_generation", {\n  method: "POST", headers: H,\n  body: JSON.stringify({\n    model: "${model}",\n    content: [\n      { type: "text", text: "角色说话:你好世界" },\n      { type: "image_url", image_url: { url: "https://example.com/ref.png" }, role: "reference_image" },\n    ],\n    resolution: "2K", duration: 5, ratio: "adaptive",\n  }),\n});\nconst { task_id } = await r.json();\n\n// 轮询\nlet task;\ndo {\n  await new Promise(r => setTimeout(r, 5000));\n  task = (await (await fetch(BASE + "/v2/query/video_generation/" + task_id, { headers: H })).json()).task;\n} while (task.status === "queued" || task.status === "running");\nconsole.log(task.content.url);`,
    go: `package main\n\nimport (\n  "bytes"\n  "encoding/json"\n  "fmt"\n  "io"\n  "net/http"\n  "time"\n)\n\nfunc main() {\n  body := bytes.NewBufferString(\`{"model": "${model}", "content": [{"type": "text", "text": "一只猫在弹钢琴"}], "resolution": "2K", "duration": 5, "ratio": "16:9"}\`)\n  req, _ := http.NewRequest("POST", "${origin}/v2/video_generation", body)\n  req.Header.Set("Authorization", "Bearer ${key}")\n  req.Header.Set("Content-Type", "application/json")\n  resp, _ := http.DefaultClient.Do(req)\n  var out struct{ TaskID string \`json:"task_id"\` }\n  json.NewDecoder(resp.Body).Decode(&out)\n  resp.Body.Close()\n  fmt.Println("task:", out.TaskID)\n\n  for {\n    time.Sleep(5 * time.Second)\n    q, _ := http.NewRequest("GET", "${origin}/v2/query/video_generation/"+out.TaskID, nil)\n    q.Header.Set("Authorization", "Bearer ${key}")\n    r, _ := http.DefaultClient.Do(q)\n    b, _ := io.ReadAll(r.Body)\n    fmt.Println(string(b))\n    r.Body.Close()\n  }\n}`,
    java: `import java.net.URI;\nimport java.net.http.*;\n\npublic class Main {\n  public static void main(String[] args) throws Exception {\n    HttpClient client = HttpClient.newHttpClient();\n    String json = "{\\"model\\": \\"${model}\\", \\"content\\": [{\\"type\\": \\"text\\", \\"text\\": \\"一只猫在弹钢琴\\"}], \\"resolution\\": \\"2K\\", \\"duration\\": 5, \\"ratio\\": \\"16:9\\"}";\n    HttpRequest req = HttpRequest.newBuilder()\n        .uri(URI.create("${origin}/v2/video_generation"))\n        .header("Authorization", "Bearer ${key}")\n        .header("Content-Type", "application/json")\n        .POST(HttpRequest.BodyPublishers.ofString(json))\n        .build();\n    System.out.println(client.send(req, HttpResponse.BodyHandlers.ofString()).body());\n  }\n}`,
    cs: `using System.Net.Http.Json;\n\nvar client = new HttpClient();\nclient.DefaultRequestHeaders.Add("Authorization", "Bearer ${key}");\nvar resp = await client.PostAsJsonAsync("${origin}/v2/video_generation", new {\n  model = "${model}",\n  content = new object[] { new { type = "text", text = "一只猫在弹钢琴" } },\n  resolution = "2K",\n  duration = 5,\n  ratio = "16:9",\n});\nConsole.WriteLine(await resp.Content.ReadAsStringAsync());`,
    php: `<?php\n$ch = curl_init("${origin}/v2/video_generation");\ncurl_setopt_array($ch, [\n  CURLOPT_RETURNTRANSFER => true,\n  CURLOPT_HTTPHEADER => ["Authorization: Bearer ${key}", "Content-Type: application/json"],\n  CURLOPT_POSTFIELDS => json_encode([\n    "model" => "${model}",\n    "content" => [["type" => "text", "text" => "一只猫在弹钢琴"]],\n    "resolution" => "2K",\n    "duration" => 5,\n    "ratio" => "16:9",\n  ]),\n]);\n$resp = json_decode(curl_exec($ch), true);\n$taskId = $resp["task_id"];\n\n// 轮询\nwhile (true) {\n  curl_setopt($ch, CURLOPT_URL, "${origin}/v2/query/video_generation/{$taskId}");\n  curl_setopt($ch, CURLOPT_POSTFIELDS, null);\n  curl_setopt($ch, CURLOPT_HTTPGET, true);\n  $t = json_decode(curl_exec($ch), true)["task"];\n  if (in_array($t["status"], ["succeeded", "failed"])) { print_r($t); break; }\n  sleep(5);\n}`,
  };
  return { openai: oai, anthropic: ant, minimax: mm }[proto][lang];
}

const PROTOS = [
  { v: "openai", label: "OpenAI 协议" }, { v: "anthropic", label: "Anthropic 协议" },
  { v: "minimax", label: "MiniMax 视频 V2" },
];
const LANGS = [
  { v: "curl", label: "curl" }, { v: "python", label: "Python" }, { v: "js", label: "JavaScript" },
  { v: "go", label: "Go" }, { v: "java", label: "Java" }, { v: "cs", label: "C#" }, { v: "php", label: "PHP" },
];

export default {
  setup() {
    const proto = ref("openai");
    const lang = ref("curl");
    const keySel = ref("");

    const base = computed(() => location.origin + "/v1");
    const model = computed(() => {
      const c = S.channels.find(c => c.enabled !== false && (c.models || []).length);
      return (c && c.models[0]) || "你的模型名";
    });
    const code = computed(() => {
      const key = keySel.value || "sk-你的网关密钥";
      return docExamples(proto.value, lang.value, base.value, key, model.value, location.origin);
    });
    function copyBase() { copyText(location.origin + "/v1", "Base URL 已复制"); }
    function copyKey() {
      if (keySel.value) copyText(keySel.value, "密钥已复制");
    }
    function copyCode() { copyText(code.value, "示例已复制"); }

    onMounted(loadGw);
    return { S, proto, lang, keySel, base, code, PROTOS, LANGS, copyBase, copyKey, copyCode };
  },
  template: `
  <div>
    <div class="page-head">
      <h2>📘 接入示例</h2>
      <span style="font-size:12px;color:var(--el-text-color-secondary);">任何 OpenAI / Anthropic 兼容客户端,把 base_url 指向本网关即可</span>
    </div>
    <el-card shadow="never" style="margin-bottom:14px;">
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:13px;">对外网关 Base URL:</span>
        <code class="mono">{{ base }}</code>
        <el-button size="small" @click="copyBase">复制</el-button>
        <span style="font-size:13px;margin-left:12px;">示例密钥:</span>
        <el-select v-model="keySel" size="small" style="width:220px;" placeholder="选择密钥(示例自动替换)">
          <el-option v-for="k in S.keys" :key="k.key" :value="k.key"
            :label="k.name + '(' + k.key.slice(0, 8) + '…)'"/>
        </el-select>
        <el-button size="small" @click="copyKey">复制密钥</el-button>
      </div>
    </el-card>
    <el-tabs v-model="proto">
      <el-tab-pane v-for="p in PROTOS" :key="p.v" :name="p.v" :label="p.label"/>
    </el-tabs>
    <div style="display:flex;align-items:center;gap:6px;margin:10px 0;">
      <el-check-tag v-for="l in LANGS" :key="l.v" :checked="lang === l.v" @change="lang = l.v">{{ l.label }}</el-check-tag>
      <span class="grow"></span>
      <el-button size="small" type="primary" plain @click="copyCode">复制示例</el-button>
    </div>
    <el-card shadow="never">
      <pre class="doc-code mono">{{ code }}</pre>
    </el-card>
  </div>`,
};
