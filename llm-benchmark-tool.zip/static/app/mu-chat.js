// ============================== 对话视图:消息流 + 发送 + 数据源 ==============================
import { ref, reactive, computed, nextTick, onMounted, onActivated, onUnmounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { S, expandSkills, applySource, saveSession, saveLocalCfg, saveVideoPrefs, ctxLabel } from "./mu-store.js";
import { api, uploadFile, copyText } from "./api.js";
import { renderMarkdown, makeThumb } from "./markdown.js";
import { esc, fmtSize, fmtAttBytes } from "./fmt.js";
import { takePendingText } from "./mu-bus.js";
import { isViewer } from "./auth.js";

// ---------- 媒体消息(视频/图片/音频 + 信息行,尺寸真实读取) ----------
const MediaMsg = {
  props: ["m"],
  setup(props) {
    const dim = ref("…");
    const onVideo = (e) => { dim.value = `${e.target.videoWidth}×${e.target.videoHeight}`; };
    const onImage = (e) => { dim.value = `${e.target.naturalWidth}×${e.target.naturalHeight}`; };
    const bits = computed(() => {
      const b = [];
      if (props.m.media_size) b.push(`已取回到本地 ${fmtSize(props.m.media_size)}`);
      const dur = props.m.metrics && props.m.metrics.duration_s;
      if (dur != null) b.push(`耗时 ${dur}s`);
      return b;
    });
    return { dim, onVideo, onImage, bits, fmtSize };
  },
  computed: {
    isHttp() { return /^https?:\/\//.test(this.m.url || ""); },
  },
  template: `
  <div class="msg-media">
    <template v-if="m.type === 'video' && m.media_url">
      <video :src="m.media_url" controls preload="metadata" @loadedmetadata="onVideo"/>
      <div class="media-meta">
        {{ bits.join(' | ') }}
        <template v-if="m.media_url">  路径：<a :href="m.media_url" target="_blank" rel="noopener">{{ m.media_url }}</a></template>
        <template v-if="bits.length">  尺寸：</template><span class="mono">{{ dim }}</span>
      </div>
    </template>
    <template v-else-if="m.type === 'image' && m.media_url">
      <img :src="m.media_url" alt="生成图片" @load="onImage"/>
      <div class="media-meta">
        {{ bits.join(' | ') }}
        <template v-if="m.media_url">  路径：<a :href="m.media_url" target="_blank" rel="noopener">{{ m.media_url }}</a></template>
        <template v-if="bits.length">  尺寸：</template><span class="mono">{{ dim }}</span>
      </div>
    </template>
    <template v-else-if="m.type === 'audio' && m.media_url">
      <audio :src="m.media_url" controls/>
      <div class="media-meta">
        {{ m.media_size ? '已取回到本地 ' + fmtSize(m.media_size) : (m.url || '') }}
        <div v-if="m.text">合成文本: {{ m.text.slice(0, 120) }}</div>
      </div>
    </template>
    <template v-else>
      <div class="media-meta">
        <a v-if="m.url" :href="m.url" target="_blank" rel="noopener">{{ m.url }}</a>
        <span v-else>(无 URL)</span>
      </div>
    </template>
    <div class="media-meta">
      <span v-if="isHttp">原始输出: <a :href="m.url" target="_blank" rel="noopener">{{ m.url }}</a>
        <template v-if="m.media_size"> ({{ fmtSize(m.media_size) }})</template>
      </span>
      <div v-if="m.media_error" style="color: var(--el-color-warning);">⚠ 未能取回产物: {{ m.media_error }}</div>
    </div>
  </div>`,
};

// ---------- 单条消息 ----------
const MsgItem = {
  props: ["m"],
  emits: ["recall", "del", "truncate", "regen", "regenVideo", "toggleSel", "copy"],
  components: { MediaMsg },
  setup() { return { S }; },
  computed: {
    mdHtml() { return renderMarkdown(this.m.content); },
    metricsText() {
      const mt = this.m.metrics;
      if (!mt || ["image", "video", "audio"].includes(this.m.type)) return "";
      const p = [];
      if (mt.ttft_ms != null) p.push(`TTFT ${mt.ttft_ms}ms`);
      if (mt.duration_s != null) p.push(`耗时 ${mt.duration_s}s`);
      if (mt.output_tokens) p.push(`输出 ${mt.output_tokens} tok`);
      if (mt.decode_tps) p.push(`${mt.decode_tps} tok/s`);
      if (mt.search_ms != null) p.push(`搜索 ${mt.search_ms}ms`);
      return p.join(" · ");
    },
    audioMetrics() {
      const mt = this.m.metrics || {};
      const p = [];
      if (mt.ttft_ms != null) p.push(`TTFT ${mt.ttft_ms}ms`);
      if (mt.duration_s != null) p.push(`耗时 ${mt.duration_s}s`);
      return p.join(" · ");
    },
    userHtml() {
      return esc(this.m.content || "(附件)")
        .replace(/(@[\w\u4e00-\u9fa5-]+)/g, '<span class="skill-tag">$1</span>');
    },
  },
  methods: { fmtAttBytes },
  template: `
  <div v-if="m.role === 'notice'" class="msg-notice"><span>↩ {{ m.content || '系统消息' }}</span></div>

  <div v-else-if="m.role === 'user'" class="msg-row user"
    :class="{ selectable: S.selectMode, selected: S.selectMode && S.selSet.has(m) }"
    @click="S.selectMode && $emit('toggleSel', m)">
    <div v-if="m.attachments && m.attachments.length" class="msg-atts">
      <template v-for="a in m.attachments" :key="a.name">
        <div v-if="(a.type === 'image' || a.type === 'video') && a.thumb" class="mth"
          :title="a.name + ' (' + fmtAttBytes(a.size) + ')'">
          <img :src="a.thumb"/>
          <span v-if="a.type === 'video'" class="vtag">▶</span>
        </div>
        <div v-else class="mth doc" :title="a.name">{{ a.type === 'audio' ? '🎵 ' : '📄 ' }}{{ a.name || '附件' }}</div>
      </template>
    </div>
    <div class="msg-bubble" v-html="userHtml"/>
    <div v-if="!S.selectMode" class="msg-ops" style="justify-content: flex-end;">
      <el-button text size="small" @click.stop="$emit('recall', m)">撤回</el-button>
      <el-button text size="small" type="danger" @click.stop="$emit('del', m)">删除</el-button>
      <el-button text size="small" @click.stop="$emit('toggleSel', m, true)">多选</el-button>
    </div>
  </div>

  <div v-else class="msg-row ai"
    :class="{ selectable: S.selectMode, selected: S.selectMode && S.selSet.has(m) }"
    @click="S.selectMode && $emit('toggleSel', m)">
    <div class="msg-ava ai">AI</div>
    <div class="msg-main">
      <div class="who">🤖 {{ S.model || 'AI' }}</div>
      <div class="body">
        <details v-if="m.search && m.search.length" class="search-block">
          <summary>🌐 已联网搜索({{ m.search.length }} 条<template v-if="m.search_ms">,耗时 {{ m.search_ms }} ms</template>)</summary>
          <div class="search-body">
            <div v-for="(r, i) in m.search" :key="i" class="search-item">
              <a :href="r.url" target="_blank" rel="noopener">{{ i + 1 }}. {{ r.title || r.url }}</a>
              <div v-if="r.snippet" class="search-snippet">{{ r.snippet }}</div>
            </div>
          </div>
        </details>
        <details v-if="m.think" class="msg-think">
          <summary>🧠 思维链({{ (m.think || '').length }} 字)</summary>
          <div class="think-txt">{{ m.think }}</div>
        </details>
        <MediaMsg v-if="['image', 'video', 'audio'].includes(m.type)" :m="m"/>
        <div v-else class="md-body" v-html="mdHtml"/>
        <div v-if="m.type === 'audio' && audioMetrics" class="media-mini-metrics">{{ audioMetrics }}</div>
        <div v-if="metricsText" class="media-mini-metrics">{{ metricsText }}</div>
      </div>
      <div v-if="!S.selectMode" class="msg-ops">
        <el-button text size="small" @click.stop="$emit('copy', m)">复制</el-button>
        <el-button text size="small" @click.stop="$emit('regen', m)">重新生成</el-button>
        <el-button text size="small" @click.stop="$emit('truncate', m)">截断</el-button>
        <el-button text size="small" type="danger" @click.stop="$emit('del', m)">删除</el-button>
        <el-button text size="small" @click.stop="$emit('toggleSel', m, true)">多选</el-button>
        <el-button v-if="m.type === 'video'" text size="small" @click.stop="$emit('regenVideo', m)">再生成 2K</el-button>
        <a v-if="m.media_url" class="el-button el-button--primary is-text el-button--small"
          :href="m.media_url + '?download=1'" :download="m.media_name || ''">下载</a>
      </div>
    </div>
  </div>`,
};

// ---------- 对话视图 ----------
export default {
  components: { MsgItem },
  setup() {
    const scrollRef = ref(null);
    const inputRef = ref(null);
    const fileRef = ref(null);
    const input = ref("");
    const status = ref("");
    const webSearch = ref(false);
    const searchCount = ref(10);
    const thinking = ref(true);
    const recording = ref(false);
    const srcOpen = ref(false);
    const srcFilter = ref("");
    const apiDlg = ref(false);
    const apiForm = reactive({ url: "", key: "", protocol: "openai", model: "", detectCtx: "", detecting: false });
    const paramDlg = ref(false);
    const paramForm = reactive({ system: "", temperature: "", max_tokens: "", top_p: "", top_k: "" });
    const varDlg = ref(false);
    const varPrompt = ref(null);
    const varValues = reactive({});
    const mention = reactive({ open: false, kind: "skill", items: [], sel: 0 });
    let mediaRec = null;

    // 预览账号:全站只读,对话统一走管理员配置的网关渠道(无可编辑数据源,仅可选模型)
    const RO = isViewer();
    const viewerCfg = reactive({ configured: false, channel: "", models: [] });
    async function loadViewerCfg() {
      try {
        const d = await api("/api/viewer/chat-cfg");
        viewerCfg.configured = !!d.configured;
        viewerCfg.channel = d.channel || "";
        viewerCfg.models = d.models || [];
        if (!viewerCfg.configured) return;
        S.sourceId = "__viewer__";
        S.srcName = `网关 · ${viewerCfg.channel}`;
        S.apiUrl = "(viewer-gateway)";        // 占位:服务端会按预览账号自动注入网关渠道
        S.apiKey = "";
        S.models = viewerCfg.models;
        if (!S.model || !viewerCfg.models.includes(S.model)) S.model = d.model || viewerCfg.models[0] || "";
      } catch (e) { console.error(e); }
    }
    function pickViewerModel(m) {
      S.model = m;
      srcOpen.value = false;
      ElMessage.success(`已切换模型: ${m}`);
    }
    const segOpts = computed(() => RO ? SEG_OPTS.filter(o => ["chat", "vision"].includes(o.value)) : SEG_OPTS);

    const DUR_OPTS = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
    const VOICES = ["alloy", "echo", "fable", "onyx", "nova", "shimmer"];
    const TTS_FMTS = ["mp3", "wav", "opus", "aac", "flac"];
    const SEG_OPTS = [
      { value: "chat", label: "💬 文本" }, { value: "vision", label: "👁 看图" },
      { value: "image", label: "🎨 文生图" }, { value: "video", label: "🎬 文生视频" },
      { value: "image_video", label: "🖼 图生视频" }, { value: "audio", label: "🎤 语音" },
    ];
    const SUGGESTS = [
      { t: "帮我写一段产品介绍", d: "突出卖点与差异化,面向企业客户", icon: "✍️ 写一段产品介绍" },
      { t: "解释这段代码的作用,并指出潜在问题", d: "粘贴代码,我来分析", icon: "🧑‍💻 代码解读" },
      { t: "为我们的 API 服务制定一份压测方案", d: "并发梯度 / 指标 / 止损条件", icon: "📊 压测方案" },
      { t: "生成一段 5 秒的城市夜景航拍视频", d: "切换到「文生视频」任务后发送", icon: "🎬 视频脚本与生成" },
    ];

    const segValue = computed(() => S.task === "chat" && S.visionHint ? "vision"
      : ["tts", "stt"].includes(S.task) ? "audio" : S.task);
    const isVideoTask = computed(() => ["video", "image_video"].includes(S.task));
    const isAudioTask = computed(() => ["tts", "stt"].includes(S.task));
    const paramBadge = computed(() => (S.systemPrompt ? 1 : 0) + (S.params && Object.keys(S.params).length ? 1 : 0));
    const placeholder = computed(() => {
      const ph = {
        chat: S.visionHint ? "描述图片/视频/音频内容的问题(先点 📎 上传媒体)…" : "给模型发送消息…",
        image: "描述要生成的图片,如:一只戴宇航头盔的柴犬,赛博朋克风格…",
        video: "描述要生成的视频画面;可附参考图/视频/音频(参考生视频)…",
        image_video: "描述视频动作;📎 上传 1-2 张图作首帧/尾帧…",
        tts: "输入要合成语音的文本…",
        stt: "语言提示(可选,如 zh / en);音频请点 📎 上传或 🎙 录音",
      };
      return ph[S.task] || "给模型发送消息…";
    });
    const srcGroups = computed(() => {
      const q = srcFilter.value.trim().toLowerCase();
      const groups = [];
      for (const ch of S.channels) {
        const models = (ch.models || []).filter(m => !q || m.toLowerCase().includes(q) || (ch.name || "").toLowerCase().includes(q));
        if (q && !models.length && !(ch.name || "").toLowerCase().includes(q)) continue;
        groups.push({ ch, models });
      }
      return groups;
    });

    function scrollToBottom() {
      nextTick(() => {
        const el = scrollRef.value;
        if (el) el.scrollTop = el.scrollHeight;
      });
    }
    function autosize() {
      const ta = inputRef.value;
      if (!ta) return;
      ta.style.height = "auto";
      ta.style.height = Math.min(ta.scrollHeight, 260) + "px";
    }
    function setTask(v) {
      if (v === "audio") { S.task = S.task === "stt" ? "stt" : "tts"; }
      else if (v === "vision") { S.task = "chat"; S.visionHint = true; }
      else { S.visionHint = false; S.task = v; }
      saveLocalCfg();
    }
    function pickModel(ch, m) {
      S.sourceId = ch.id; S.model = m;
      applySource();
      srcOpen.value = false;
      ElMessage.success(`已切换: ${ch.name} · ${m}`);
    }
    // ---- 自定义 API 弹窗 ----
    function openApiDlg() {
      apiForm.url = S.apiUrl; apiForm.key = S.apiKey;
      apiForm.protocol = S.protocol; apiForm.model = S.model; apiForm.detectCtx = "";
      apiDlg.value = true;
    }
    async function detectApi() {
      const url = apiForm.url.trim();
      if (!url) { ElMessage.warning("请先填写地址"); return; }
      apiForm.detecting = true;
      try {
        const d = await api("/api/detect", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ api_url: url, api_key: apiForm.key }),
        });
        if (d.protocol && d.protocol !== "unknown") { apiForm.protocol = d.protocol; S.protocol = d.protocol; }
        if (d.models && d.models.length) {
          S.models = d.models;
          if (!d.models.includes(apiForm.model)) apiForm.model = d.models[0];
        }
        apiForm.detectCtx = `${d.framework || "未知框架"} · 协议 ${d.protocol} · ${(d.models || []).length} 模型`;
      } catch (e) { apiForm.detectCtx = "检测失败: " + e.message; }
      apiForm.detecting = false;
    }
    function saveApiDlg() {
      S.sourceId = "custom";
      S.apiUrl = apiForm.url.trim(); S.apiKey = apiForm.key;
      S.protocol = apiForm.protocol; S.model = apiForm.model.trim();
      apiDlg.value = false;
      applySource(); saveSession();
      ElMessage.success("自定义 API 已保存");
    }
    // ---- 附件 ----
    async function onFiles(ev) {
      const files = [...ev.target.files];
      ev.target.value = "";
      for (const f of files) {
        const isVideo = /\.(mp4|mov|webm|mkv|avi|m4v)$/i.test(f.name);
        const isAudio = /\.(mp3|wav|ogg|opus|flac|aac|m4a|wma|amr)$/i.test(f.name);
        const limit = isVideo ? 50 : isAudio ? 25 : 20;
        if (f.size > limit * 1048576) { ElMessage.warning(`${f.name} 超过 ${limit}MB,已跳过`); continue; }
        try {
          const d = await uploadFile(f);
          if (!d.size) d.size = f.size;
          d.thumb = await makeThumb(d);
          S.attachments.push(d);
          if (d.type === "audio" && !["stt", "chat", "tts"].includes(S.task)) { S.task = "tts"; saveLocalCfg(); }
        } catch (e) { ElMessage.error(`${f.name} 上传失败: ${e.message}`); }
      }
    }
    function rmAttachment(i) { S.attachments.splice(i, 1); }
    async function toggleRecord() {
      if (mediaRec && mediaRec.state === "recording") { mediaRec.stop(); return; }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRec = new MediaRecorder(stream);
        const chunks = [];
        mediaRec.ondataavailable = (e) => chunks.push(e.data);
        mediaRec.onstop = async () => {
          stream.getTracks().forEach(t => t.stop());
          recording.value = false;
          try {
            const blob = new Blob(chunks, { type: mediaRec.mimeType || "audio/webm" });
            const ext = (mediaRec.mimeType || "audio/webm").includes("mp4") ? "m4a" : "webm";
            const d = await uploadFile(new File([blob], "recording." + ext, { type: blob.type }));
            S.attachments.push(d);
            if (!["stt", "tts", "chat"].includes(S.task)) { S.task = "tts"; saveLocalCfg(); }
            ElMessage.success("录音已加入附件,点发送识别");
          } catch (e) { ElMessage.error("录音上传失败: " + e.message); }
        };
        mediaRec.start();
        recording.value = true;
      } catch (e) { ElMessage.error("无法访问麦克风: " + e.message); }
    }
    // ---- @技能 / /提示词 提及 ----
    function openMention(kind, filter) {
      const list = kind === "skill" ? S.skills : S.prompts;
      const kw = (filter || "").toLowerCase();
      mention.items = list.filter(x => !kw || x.name.toLowerCase().includes(kw)
        || (x.description || x.category || "").toLowerCase().includes(kw));
      if (!mention.items.length) { closeMention(); return; }
      mention.open = true; mention.kind = kind; mention.sel = 0;
    }
    function openMentionBtn(kind) {
      if (mention.open && mention.kind === kind) { closeMention(); return; }
      openMention(kind, "");
    }
    function closeMention() { mention.open = false; }
    function pickMention(i) {
      const it = mention.items[i];
      if (!it) return closeMention();
      const ta = inputRef.value;
      const caret = ta.selectionStart ?? ta.value.length;
      if (mention.kind === "skill") {
        const before = ta.value.slice(0, caret);
        const m = before.match(/@([\w\u4e00-\u9fa5-]*)$/);
        if (m) {
          const start = caret - m[0].length;
          input.value = ta.value.slice(0, start) + "@" + it.name + " " + ta.value.slice(caret);
          const pos = start + it.name.length + 2;
          nextTick(() => ta.setSelectionRange(pos, pos));
        } else input.value += " @" + it.name + " ";
        closeMention(); ta.focus(); autosize();
        ElMessage.success(`已引用技能 @${it.name}(发送时展开)`);
      } else {
        const before = ta.value.slice(0, caret);
        const mp = before.match(/\/([\w\u4e00-\u9fa5-]*)$/);
        if (mp) {
          const start = caret - mp[0].length;
          input.value = input.value.slice(0, start) + input.value.slice(caret);
        }
        closeMention(); ta.focus(); autosize();
        insertPrompt(it);
      }
    }
    function insertPrompt(p) {
      const vars = [...new Set([...(p.variables || []),
        ...(String(p.content || "").match(/\{\{(.+?)\}\}/g) || []).map(x => x.slice(2, -2))])];
      if (!vars.length) { insertText(p.content); ElMessage.success("已插入提示词"); return; }
      varPrompt.value = p;
      Object.keys(varValues).forEach(k => delete varValues[k]);
      vars.forEach(v => varValues[v] = "");
      varDlg.value = true;
    }
    function applyVarPrompt() {
      let content = varPrompt.value.content || "";
      Object.entries(varValues).forEach(([k, v]) => {
        if (v) content = content.split("{{" + k + "}}").join(v);
      });
      return content.replace(/\{\{.+?\}\}/g, "").trim();
    }
    function varInsert() {
      insertText(applyVarPrompt());
      varDlg.value = false;
      ElMessage.success("已插入提示词");
    }
    function varSetSystem() {
      S.systemPrompt = applyVarPrompt();
      varDlg.value = false;
      saveSession();
      ElMessage.success("已设为系统提示词(⚙ 参数中可查看)");
    }
    function insertText(text) {
      const ta = inputRef.value;
      const caret = ta.selectionStart ?? ta.value.length;
      input.value = ta.value.slice(0, caret) + (caret > 0 && ta.value[caret - 1] !== "\n" ? "\n" : "") + text + "\n";
      const pos = input.value.length;
      nextTick(() => { ta.setSelectionRange(pos, pos); ta.focus(); });
      autosize();
    }
    function onInput() {
      autosize();
      const ta = inputRef.value;
      const before = ta.value.slice(0, ta.selectionStart ?? ta.value.length);
      const ms = before.match(/(^|\s)@([\w\u4e00-\u9fa5-]*)$/);
      if (ms) { openMention("skill", ms[2]); return; }
      const mp = before.match(/(^|\s)\/([\w\u4e00-\u9fa5-]*)$/);
      if (mp) { openMention("prompt", mp[2]); return; }
      closeMention();
    }
    function onKeydown(e) {
      // 输入法组合中(选词/确认候选)不触发任何快捷键,避免中文按 Enter 选词误发送
      if (e.isComposing || e.keyCode === 229) return;
      if (mention.open && ["Enter", "Tab", "ArrowUp", "ArrowDown"].includes(e.key)) {
        e.preventDefault();
        if (e.key === "ArrowDown") mention.sel = Math.min(mention.sel + 1, mention.items.length - 1);
        else if (e.key === "ArrowUp") mention.sel = Math.max(mention.sel - 1, 0);
        else { pickMention(mention.sel); return; }
        return;
      }
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); }
    }
    // ---- 参数面板 ----
    function openParamDlg() {
      paramForm.system = S.systemPrompt;
      paramForm.temperature = S.params.temperature ?? "";
      paramForm.max_tokens = S.params.max_tokens ?? "";
      paramForm.top_p = S.params.top_p ?? "";
      paramForm.top_k = S.params.top_k ?? "";
      paramDlg.value = true;
    }
    function saveParamDlg() {
      S.systemPrompt = paramForm.system.trim();
      const num = (v) => (String(v).trim() === "" ? undefined : (isNaN(+v) ? v : +v));
      S.params = Object.fromEntries(Object.entries({
        temperature: num(paramForm.temperature), max_tokens: num(paramForm.max_tokens),
        top_p: num(paramForm.top_p), top_k: num(paramForm.top_k),
      }).filter(([, v]) => v !== undefined));
      paramDlg.value = false;
      saveSession();
      ElMessage.success("参数已保存(随会话)");
    }
    function clearParams() {
      S.systemPrompt = ""; S.params = {};
      paramForm.system = ""; paramForm.temperature = ""; paramForm.max_tokens = "";
      paramForm.top_p = ""; paramForm.top_k = "";
      saveSession();
    }
    // ---- 消息操作 ----
    async function recallMsg(m) {
      if (S.sending) { ElMessage.warning("正在生成,请先停止再撤回"); return; }
      const idx = S.history.indexOf(m);
      if (idx < 0) return;
      let end = idx + 1;
      if (S.history[end] && S.history[end].role === "assistant") end++;
      const n = end - idx;
      try {
        await ElMessageBox.confirm(`撤回这 ${n} 条消息(该提问${n > 1 ? "及其回复" : ""})?撤回后从数据库删除,不可恢复`, "撤回确认", { type: "warning" });
      } catch { return; }
      S.history.splice(idx, n, { role: "notice", content: "你撤回了一条消息" });
      await saveSession();
      ElMessage.success("已撤回并保存到数据库");
    }
    async function delMsg(m) {
      try { await ElMessageBox.confirm("删除这条消息?", "删除", { type: "warning" }); } catch { return; }
      S.history = S.history.filter(x => x !== m);
      await saveSession();
    }
    async function truncateFrom(m) {
      const idx = S.history.indexOf(m);
      if (idx < 0) return;
      try { await ElMessageBox.confirm("删除这条及之后的所有消息?", "截断", { type: "warning" }); } catch { return; }
      S.history.splice(idx);
      await saveSession();
    }
    function copyMsg(m) { copyText(m.content || m.text || "", "已复制"); }
    function toggleSel(m, fromOps) {
      if (fromOps) { S.selectMode = true; S.selSet = new Set([m]); }
      else if (S.selSet.has(m)) S.selSet.delete(m); else S.selSet.add(m);
    }
    async function selDelete() {
      if (!S.selSet.size) return;
      try { await ElMessageBox.confirm(`删除所选 ${S.selSet.size} 条消息?`, "批量删除", { type: "warning" }); } catch { return; }
      S.history = S.history.filter(x => !S.selSet.has(x));
      await saveSession();
      exitSelect();
    }
    function exitSelect() { S.selectMode = false; S.selSet = new Set(); }
    const selectCount = computed(() => S.history.filter(m => m.role !== "notice").length);
    function selAll() {
      const selectable = S.history.filter(m => m.role !== "notice");
      if (selectable.length && S.selSet.size === selectable.length) S.selSet = new Set();
      else S.selSet = new Set(selectable);
    }
    // ---- 发送 ----
    function buildPayload(task, text, atts) {
      return {
        api_url: S.apiUrl, api_key: S.apiKey, protocol: S.protocol,
        task_type: ["chat", "image", "video", "image_video", "video_regen", "tts", "stt"].includes(task) ? task : "chat",
        video_duration: S.vDur, video_resolution: S.vRes,
        video_ratio: S.vRatio, video_api: S.vApi,
        model: S.model, message: text,
        history: S.history.slice(0, -1).filter(x => x.role !== "notice")
          .map(m => ({ role: m.role, content: m.content })),
        enable_thinking: thinking.value,
        web_search: webSearch.value,
        search_count: searchCount.value,
        attachments: atts || [],
        system_prompt: S.systemPrompt,
        params: S.params,
        tts_voice: S.ttsVoice,
        tts_format: S.ttsFmt,
      };
    }
    async function sendChat() {
      if (S.sending) { if (S.abort) S.abort.abort(); return; }
      const rawText = input.value.trim();
      const task = S.task;
      const atts = S.attachments.slice();
      if (!rawText && !atts.length) return;
      if (!S.apiUrl || !S.model) { ElMessage.warning("请先选择数据来源与模型"); srcOpen.value = true; return; }
      if (task === "image_video" && !atts.some(a => a.type === "image")) {
        ElMessage.warning("图生视频需要先 📎 上传首帧图(可两张作首尾帧)"); return;
      }
      if (task === "stt" && !atts.some(a => a.type === "audio")) {
        ElMessage.warning("语音识别需要 📎 上传音频或 🎙 录音"); return;
      }
      if ((task === "tts" || task === "image" || task === "video") && !rawText) { ElMessage.warning("请输入内容"); return; }
      const text = expandSkills(rawText);
      const attMeta = atts.map(a => ({ name: a.name, type: a.type, size: a.size || 0, thumb: a.thumb || "" }));
      S.history.push(attMeta.length
        ? { role: "user", content: rawText, attachments: attMeta }
        : { role: "user", content: rawText });
      input.value = ""; autosize();
      S.attachments = [];
      scrollToBottom();
      await runTask(task, buildPayload(task, text, atts));
    }
    async function runTask(task, payload) {
      S.sending = true;
      S.abort = new AbortController();
      const mRecord = reactive({ role: "assistant", content: "", think: "", metrics: null });
      S.history.push(mRecord);
      scrollToBottom();
      try {
        if (task === "chat") {
          status.value = "正在生成…";
          const resp = await fetch("/api/chat", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload), signal: S.abort.signal,
          });
          if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${(await resp.text()).slice(0, 200)}`);
          const reader = resp.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "", full = "", think = "", lastRender = 0;
          while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop();
            for (const line of lines) {
              if (!line.startsWith("data:")) continue;
              const ds = line.slice(5).trim();
              if (!ds || ds === "[DONE]") continue;
              let evt;
              try { evt = JSON.parse(ds); } catch { continue; }
              if (evt.type === "content") {
                full += evt.content;
                const now = Date.now();
                if (now - lastRender > 150) {
                  mRecord.content = full; mRecord.think = think;
                  lastRender = now;
                  scrollToBottom();
                }
              } else if (evt.type === "think") {
                think += evt.content;
                mRecord.think = think;
                scrollToBottom();
              } else if (evt.type === "searching") {
                status.value = `🌐 正在联网搜索: ${evt.query || ""}`;
              } else if (evt.type === "search") {
                if (evt.results && evt.results.length) {
                  mRecord.search = evt.results; mRecord.search_ms = evt.ms;
                }
                status.value = "正在生成…";
              } else if (evt.type === "metrics") {
                mRecord.metrics = evt.data;
              } else if (evt.type === "error") {
                throw new Error(evt.message);
              }
            }
          }
          mRecord.content = full; mRecord.think = think;
        } else {
          const waiting = {
            image: "🎨 正在生成图片…", video: "🎬 正在生成视频(产物自动取回,可能需要几分钟)…",
            image_video: "🖼 正在图生视频(产物自动取回,可能需要几分钟)…",
            video_regen: "🔄 正在再生成 2K 视频…", tts: "🔉 正在合成语音…", stt: "📝 正在识别语音…",
          };
          status.value = waiting[task] || "处理中…";
          const resp = await fetch("/api/chat", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload), signal: S.abort.signal,
          });
          const d = await resp.json().catch(() => ({}));
          if (!resp.ok) throw new Error(d.detail || `HTTP ${resp.status}`);
          if (d.type === "image" || d.type === "video" || d.type === "audio") {
            mRecord.type = d.type; mRecord.url = d.url;
            mRecord.metrics = { duration_s: d.latency_s };
            mRecord.prompt = payload.message;
            if (d.job_id) mRecord.job_id = d.job_id;
            if (d.style) mRecord.style = d.style;
            if (d.media_url) { mRecord.media_url = d.media_url; mRecord.media_name = d.media_name || ""; mRecord.media_size = d.media_size || 0; }
            if (d.media_error) mRecord.media_error = d.media_error;
            if (d.type === "audio") { mRecord.text = d.text || payload.message; mRecord.content = d.text || payload.message; }
          } else if (d.type === "transcription") {
            mRecord.type = "transcription";
            mRecord.text = d.text; mRecord.content = d.text;
            mRecord.metrics = { duration_s: d.latency_s };
          }
        }
        await saveSession();
        scrollToBottom();
      } catch (e) {
        if (e.name === "AbortError") {
          if (mRecord.content) {
            mRecord.content += "\n\n[已停止]";
            await saveSession();
          } else {
            S.history = S.history.filter(x => x !== mRecord);
            ElMessage.info("已停止");
          }
        } else {
          S.history = S.history.filter(x => x !== mRecord);
          ElMessage.error("出错: " + e.message);
        }
      } finally {
        S.sending = false; S.abort = null;
        status.value = "";
        scrollToBottom();
      }
    }
    async function regenerate(m) {
      const idx = S.history.indexOf(m);
      if (idx < 0 || S.sending) return;
      let ui = idx - 1;
      while (ui >= 0 && S.history[ui].role !== "user") ui--;
      if (ui < 0) return;
      const userMsg = S.history[ui].content;
      S.history.splice(ui);
      input.value = userMsg;
      await sendChat();
    }
    async function regenVideo(m) {
      if (S.sending) { ElMessage.warning("正在生成,请先停止"); return; }
      if (!S.apiUrl || !S.model) { ElMessage.warning("请先选择数据来源与模型"); return; }
      const useTaskId = m.style === "v2" && m.job_id;
      if (!useTaskId && !m.media_url) { ElMessage.warning("该视频缺少源任务信息与本地文件,无法再生成"); return; }
      try { await ElMessageBox.confirm("以 2K 分辨率再生成这条视频?", "视频再生成", { type: "info" }); } catch { return; }
      S.history.push({ role: "user", content: "🔄 视频再生成(2K)" });
      scrollToBottom();
      const payload = {
        ...buildPayload("video_regen", m.prompt || "", []),
        task_type: "video_regen",
        history: S.history.slice(0, -1).map(x => ({ role: x.role, content: x.content })),
        attachments: [],
        regen_task_id: useTaskId ? m.job_id : "",
        regen_source: useTaskId ? "" : m.media_url,
        video_resolution: "2K",
      };
      await runTask("video_regen", payload);
    }
    function useSuggest(t) { input.value = t; inputRef.value && inputRef.value.focus(); autosize(); }

    // 点击外部关闭数据源面板/提及下拉
    const onDocClick = (e) => {
      if (srcOpen.value && !e.target.closest(".el-popover") && !e.target.closest(".src-btn")) srcOpen.value = false;
      if (mention.open && !e.target.closest(".mention-drop") && !e.target.closest(".input-toolbar")) closeMention();
    };
    onMounted(() => {
      document.addEventListener("click", onDocClick);
      consumePending();
      if (RO) loadViewerCfg();
    });
    onActivated(() => { consumePending(); if (RO) loadViewerCfg(); });
    onUnmounted(() => document.removeEventListener("click", onDocClick));
    function consumePending() {
      const t = takePendingText();
      if (t) {
        input.value += t;
        nextTick(() => { inputRef.value && inputRef.value.focus(); autosize(); });
      }
    }

    return {
      S, SEG_OPTS, DUR_OPTS, VOICES, TTS_FMTS, SUGGESTS,
      scrollRef, inputRef, fileRef, input, status, webSearch, searchCount, thinking, recording,
      srcOpen, srcFilter, apiDlg, apiForm, paramDlg, paramForm, varDlg, varPrompt, varValues, mention,
      segValue, isVideoTask, isAudioTask, paramBadge, placeholder, srcGroups, selectCount, ctxLabel,
      RO, viewerCfg, segOpts, pickViewerModel,
      setTask, pickModel, openApiDlg, detectApi, saveApiDlg,
      onFiles, rmAttachment, toggleRecord, openMentionBtn, pickMention, closeMention, onInput, onKeydown,
      insertPrompt, varInsert, varSetSystem, useSuggest,
      openParamDlg, saveParamDlg, clearParams,
      recallMsg, delMsg, truncateFrom, copyMsg, toggleSel, selDelete, exitSelect, selAll,
      sendChat, regenerate, regenVideo, saveLocalCfg, saveVideoPrefs,
      fmtSize, fmtAttBytes,
    };
  },
  template: `
  <div class="chat-view">
    <!-- 顶栏:数据源 + 任务分段 + 上下文 -->
    <div class="chat-topbar">
      <!-- 预览账号:只读网关渠道(管理员配置),仅可切换模型 -->
      <el-popover v-if="RO" :visible="srcOpen" placement="bottom-start" :width="300">
        <template #reference>
          <el-button size="small" class="src-btn" @click="srcOpen = !srcOpen">
            <b>🔌</b>&nbsp;网关 · {{ viewerCfg.channel || '未配置' }}
            <span class="mono" style="margin-left:6px;">{{ S.model || '选择模型' }}</span>
          </el-button>
        </template>
        <div style="display:flex;flex-direction:column;gap:5px;max-height:380px;overflow-y:auto;">
          <div class="src-group"><span>👁 预览模式 · 对话由管理员配置的网关渠道提供</span></div>
          <div v-if="!viewerCfg.configured" class="src-item" style="cursor:default;">
            <span>⚠️</span><span class="mn">管理员尚未在网关配置可用渠道,暂无法对话</span>
          </div>
          <div v-for="m in viewerCfg.models" :key="m" class="src-item"
               :class="{ on: S.model === m }" @click="pickViewerModel(m)">
            <span style="color:var(--el-text-color-secondary);">·</span><span class="mn mono">{{ m }}</span>
          </div>
        </div>
      </el-popover>
      <el-popover v-else :visible="srcOpen" placement="bottom-start" :width="340">
        <template #reference>
          <el-button size="small" class="src-btn" @click="srcOpen = !srcOpen">
            <b>{{ S.sourceId === 'custom' ? '🛠' : '🔌' }}</b>&nbsp;{{ S.srcName || '自定义 API' }}
            <span class="mono" style="margin-left:6px;">{{ S.model || '选择模型' }}</span>
          </el-button>
        </template>
        <div style="display:flex;flex-direction:column;gap:5px;max-height:380px;overflow-y:auto;">
          <el-input v-model="srcFilter" placeholder="搜索渠道或模型…" size="small" clearable prefix-icon="Search"/>
          <div class="src-item" @click="srcOpen = false; openApiDlg()">
            <span>🛠</span><span class="mn">自定义 API(手动填地址/密钥)</span>
          </div>
          <template v-for="g in srcGroups" :key="g.ch.id">
            <div class="src-group">
              <span>{{ g.ch.name }}</span>
              <span class="badge a">{{ g.ch.protocol || 'openai' }}</span>
              <span v-if="g.ch.enabled === false" class="badge off">停用</span>
            </div>
            <div v-for="m in g.models" :key="m" class="src-item"
              :class="{ on: S.sourceId === g.ch.id && S.model === m }" @click="pickModel(g.ch, m)">
              <span style="color:var(--el-text-color-secondary);">·</span><span class="mn mono">{{ m }}</span>
            </div>
          </template>
        </div>
      </el-popover>
      <el-segmented :model-value="segValue" :options="segOpts" @update:model-value="setTask"/>
      <span class="ctx-chip">{{ ctxLabel }}</span>
      <span class="grow"></span>
    </div>

    <!-- 视频子参数 -->
    <div v-if="isVideoTask" class="sub-params">
      <span class="pl">⏱ 时长</span>
      <el-select v-model="S.vDur" size="small" style="width:76px;" @change="saveVideoPrefs">
        <el-option v-for="d in DUR_OPTS" :key="d" :value="d" :label="d + 's'"/>
      </el-select>
      <span class="pl">🖥 分辨率</span>
      <el-select v-model="S.vRes" size="small" style="width:88px;" @change="saveVideoPrefs">
        <el-option value="480P" label="480P"/><el-option value="768P" label="768P"/><el-option value="2K" label="2K"/>
      </el-select>
      <span class="pl">📐 比例</span>
      <el-select v-model="S.vRatio" size="small" style="width:96px;" @change="saveVideoPrefs">
        <el-option v-for="r in ['adaptive','21:9','16:9','4:3','1:1','3:4','9:16']" :key="r" :value="r"
          :label="r === 'adaptive' ? '自适应' : r"/>
      </el-select>
      <span class="pl">🔌 接口</span>
      <el-select v-model="S.vApi" size="small" style="width:112px;" @change="saveVideoPrefs">
        <el-option value="auto" label="自动"/><el-option value="v2" label="MiniMax v2"/>
        <el-option value="v1" label="MiniMax v1"/><el-option value="videos" label="SGLang"/>
      </el-select>
      <span class="hint">{{ S.task === 'image_video' ? '首帧图必需,第二张作尾帧' : '附参考图/视频/音频 = 参考生视频' }}</span>
    </div>

    <!-- 语音子参数 -->
    <div v-if="isAudioTask" class="sub-params">
      <span class="pl">模式</span>
      <el-radio-group :model-value="S.task" size="small" @update:model-value="v => { S.task = v; saveLocalCfg(); }">
        <el-radio-button value="tts">🔉 合成(文字→语音)</el-radio-button>
        <el-radio-button value="stt">📝 识别(语音→文字)</el-radio-button>
      </el-radio-group>
      <template v-if="S.task === 'tts'">
        <span class="pl">🗣 音色</span>
        <el-select v-model="S.ttsVoice" size="small" style="width:104px;" @change="saveVideoPrefs">
          <el-option v-for="v in VOICES" :key="v" :value="v" :label="v"/>
        </el-select>
        <span class="pl">🎵 格式</span>
        <el-select v-model="S.ttsFmt" size="small" style="width:88px;" @change="saveVideoPrefs">
          <el-option v-for="f in TTS_FMTS" :key="f" :value="f" :label="f"/>
        </el-select>
      </template>
      <span v-else class="hint">📎 上传音频或 🎙 录音后发送</span>
    </div>

    <!-- 消息流 -->
    <div ref="scrollRef" class="chat-scroll">
      <div v-if="!S.history.length" class="chat-welcome">
        <div class="logo">⚡</div>
        <h1>你好，今天想用模型做点什么？</h1>
        <p>选好左上角数据来源与模型，直接输入；输入 <b>@</b> 引用技能、<b>/</b> 插入提示词模板</p>
        <div class="suggest-cards">
          <div v-for="sg in SUGGESTS" :key="sg.t" class="suggest-card" @click="useSuggest(sg.t)">
            <div class="t">{{ sg.icon }}</div>
            <div class="d">{{ sg.d }}</div>
          </div>
        </div>
      </div>
      <div v-else class="chat-col">
        <MsgItem v-for="(m, i) in S.history" :key="i" :m="m"
          @recall="recallMsg" @del="delMsg" @truncate="truncateFrom" @regen="regenerate"
          @regen-video="regenVideo" @toggle-sel="toggleSel" @copy="copyMsg"/>
      </div>
    </div>

    <!-- 多选操作条 -->
    <div v-if="S.selectMode" class="sel-bar">
      <el-button size="small" @click="selAll">
        {{ S.selSet.size === selectCount ? '取消全选' : '全选' }}</el-button>
      <span style="font-size:12.5px;">已选 {{ S.selSet.size }} 条 / 共 {{ selectCount }} 条</span>
      <span class="grow"></span>
      <el-button size="small" type="danger" plain :disabled="!S.selSet.size" @click="selDelete">删除所选</el-button>
      <el-button size="small" @click="exitSelect">完成</el-button>
    </div>

    <!-- 输入卡 -->
    <div class="input-card">
      <div v-if="S.attachments.length" class="att-strip">
        <template v-for="(a, i) in S.attachments" :key="i">
          <div v-if="a.type === 'image' || a.type === 'video'" class="att-item" :title="a.name + ' (' + fmtAttBytes(a.size) + ')'">
            <img v-if="a.type === 'image'" :src="a.content"/>
            <video v-else :src="a.content" muted playsinline preload="metadata"/>
            <span class="att-size">{{ fmtAttBytes(a.size) }}</span>
            <button class="att-x" title="移除" @click="rmAttachment(i)">✕</button>
          </div>
          <div v-else class="att-item doc" :title="a.name" @click="rmAttachment(i)">
            <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ a.type === 'audio' ? '🎵' : '📄' }} {{ a.name }}</span>
            <span class="att-size" style="flex:none;">{{ fmtAttBytes(a.size) }} ✕</span>
          </div>
        </template>
      </div>
      <textarea ref="inputRef" v-model="input" rows="1" :placeholder="placeholder"
        @input="onInput" @keydown="onKeydown"/>
      <div class="input-toolbar">
        <el-tooltip content="上传附件(图片/视频/音频/文档)" placement="top">
          <el-button size="small" @click="fileRef && fileRef.click()"><el-icon><Paperclip/></el-icon>附件</el-button>
        </el-tooltip>
        <input ref="fileRef" type="file" multiple hidden @change="onFiles"/>
        <el-tooltip :content="recording ? '停止录音' : '录音(语音识别)'" placement="top">
          <el-button size="small" :type="recording ? 'danger' : ''" @click="toggleRecord">
            <el-icon><Mic/></el-icon>{{ recording ? '停止' : '录音' }}</el-button>
        </el-tooltip>
        <el-tooltip content="输入 @ 引用技能(发送时展开)" placement="top">
          <el-button size="small" @click="openMentionBtn('skill')"><el-icon><MagicStick/></el-icon>技能</el-button>
        </el-tooltip>
        <el-tooltip content="输入 / 插入提示词模板" placement="top">
          <el-button size="small" @click="openMentionBtn('prompt')"><el-icon><Collection/></el-icon>提示词</el-button>
        </el-tooltip>
        <el-divider direction="vertical"/>
        <label class="toolbar-switch" title="联网搜索">
          <span>联网</span>
          <el-switch v-model="webSearch" size="small"/>
        </label>
        <el-select v-if="webSearch" v-model="searchCount" size="small" style="width:76px;">
          <el-option v-for="n in [5, 10, 15, 20]" :key="n" :value="n" :label="n + ' 条'"/>
        </el-select>
        <label class="toolbar-switch" title="思维链">
          <span>思维链</span>
          <el-switch v-model="thinking" size="small"/>
        </label>
        <el-badge :value="paramBadge" :hidden="!paramBadge">
          <el-tooltip content="系统提示词与采样参数" placement="top">
            <el-button size="small" @click="openParamDlg"><el-icon><Setting/></el-icon>参数</el-button>
          </el-tooltip>
        </el-badge>
        <span class="grow"></span>
        <span v-if="status" class="status-line">{{ status }}</span>
        <el-button :type="S.sending ? 'danger' : 'primary'" class="send-btn"
                   :title="S.sending ? '停止' : '发送(Enter)'" @click="sendChat">
          <el-icon><component :is="S.sending ? 'VideoPause' : 'Promotion'"/></el-icon>
          {{ S.sending ? '停止' : '发送' }}
        </el-button>
      </div>
      <div v-if="mention.open" class="mention-drop">
        <div v-for="(it, i) in mention.items" :key="it.id" class="mi" :class="{ on: i === mention.sel }"
          @mousedown.prevent="pickMention(i)" @mouseenter="mention.sel = i">
          <span class="ic">{{ it.icon || (mention.kind === 'skill' ? '🛠' : '📚') }}</span>
          <div class="mibox">
            <div class="nm">{{ (mention.kind === 'skill' ? '@' : '/') + it.name }}</div>
            <div class="ds">{{ it.description || it.category || '' }}</div>
          </div>
          <span v-if="mention.kind === 'prompt' && it.category" class="badge p">{{ it.category }}</span>
        </div>
      </div>
    </div>

    <!-- 自定义 API 弹窗 -->
    <el-dialog v-model="apiDlg" title="自定义 API" width="480px">
      <el-form label-width="86px" label-position="left">
        <el-form-item label="API 地址"><el-input v-model="apiForm.url" placeholder="http://127.0.0.1:8000/v1"/></el-form-item>
        <el-form-item label="API Key"><el-input v-model="apiForm.key" type="password" show-password/></el-form-item>
        <el-form-item label="协议">
          <el-select v-model="apiForm.protocol">
            <el-option value="openai" label="OpenAI"/><el-option value="anthropic" label="Anthropic"/>
            <el-option value="ollama" label="Ollama"/>
          </el-select>
        </el-form-item>
        <el-form-item label="模型">
          <div style="display:flex;gap:8px;width:100%;">
            <el-input v-model="apiForm.model" class="grow"/>
            <el-button :loading="apiForm.detecting" @click="detectApi">检测</el-button>
          </div>
        </el-form-item>
      </el-form>
      <div v-if="apiForm.detectCtx" style="font-size:12px;color:var(--el-text-color-secondary);margin:4px 0 8px;">{{ apiForm.detectCtx }}</div>
      <template #footer>
        <el-button @click="apiDlg = false">取消</el-button>
        <el-button type="primary" @click="saveApiDlg">保存</el-button>
      </template>
    </el-dialog>

    <!-- 参数弹窗 -->
    <el-dialog v-model="paramDlg" title="⚙ 参数" width="470px">
      <el-form label-width="86px" label-position="left">
        <el-form-item label="系统提示词">
          <el-input v-model="paramForm.system" type="textarea" :rows="4" placeholder="设定模型角色与规则(随会话保存)"/>
        </el-form-item>
        <el-form-item label="temperature"><el-input v-model="paramForm.temperature" placeholder="如 0.7"/></el-form-item>
        <el-form-item label="max_tokens"><el-input v-model="paramForm.max_tokens" placeholder="如 4096"/></el-form-item>
        <el-form-item label="top_p"><el-input v-model="paramForm.top_p"/></el-form-item>
        <el-form-item label="top_k"><el-input v-model="paramForm.top_k"/></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="clearParams">清空</el-button>
        <el-button @click="paramDlg = false">取消</el-button>
        <el-button type="primary" @click="saveParamDlg">保存</el-button>
      </template>
    </el-dialog>

    <!-- 提示词变量填充 -->
    <el-dialog v-model="varDlg" :title="'填充变量 · ' + (varPrompt ? varPrompt.name : '')" width="470px">
      <el-form label-position="top">
        <el-form-item v-for="(_, v) in varValues" :key="v" :label="v">
          <el-input v-model="varValues[v]" :placeholder="'{{' + v + '}}'"/>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="varDlg = false">取消</el-button>
        <el-button type="primary" @click="varInsert">插入到输入框</el-button>
        <el-button @click="varSetSystem">设为系统提示词</el-button>
      </template>
    </el-dialog>
  </div>`,
};
